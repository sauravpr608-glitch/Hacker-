import { NextRequest, NextResponse } from "next/server";
import { getConvexClient } from "@/lib/db/convex-client";
import { api } from "@/convex/_generated/api";
import { workos } from "../../../../workos";
import { requireAdminOrg } from "../../../team-auth";
import { z } from "zod";
import { stringifyRedactedError } from "@/lib/utils/error-redaction";

const memberSettingsSchema = z.object({
  monthlyLimitDollars: z.number().finite().nullable().optional(),
  disabled: z.boolean().optional(),
});

/**
 * PATCH /api/team/extra-usage/members/:userId
 * Body: { monthlyLimitDollars?: number | null, disabled?: boolean }
 * Admin-only. Updates per-member spending limit and/or disabled flag.
 */
export const PATCH = async (
  req: NextRequest,
  { params }: { params: Promise<{ userId: string }> },
) => {
  try {
    const guard = await requireAdminOrg(req);
    if (!guard.ok) return guard.response;

    const { userId: targetUserId } = await params;
    if (!targetUserId) {
      return NextResponse.json(
        { error: "Target userId is required" },
        { status: 400 },
      );
    }

    // Confirm the target user is actually a member of the admin's org —
    // prevents an admin from one org touching another org's row via path manipulation.
    const targetMemberships =
      await workos.userManagement.listOrganizationMemberships({
        userId: targetUserId,
        organizationId: guard.organizationId,
        statuses: ["active"],
      });

    if (!targetMemberships.data || targetMemberships.data.length === 0) {
      return NextResponse.json(
        { error: "User is not a member of your organization" },
        { status: 404 },
      );
    }

    let body: {
      monthlyLimitDollars?: number | null;
      disabled?: boolean;
    };
    try {
      const parsed = memberSettingsSchema.safeParse(await req.json());
      if (!parsed.success) {
        return NextResponse.json(
          { error: "Invalid member usage settings" },
          { status: 400 },
        );
      }
      body = parsed.data;
    } catch {
      return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
    }

    await getConvexClient().mutation(api.teamExtraUsage.updateTeamMemberUsage, {
      serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
      organizationId: guard.organizationId,
      userId: targetUserId,
      monthlyLimitDollars: body.monthlyLimitDollars,
      disabled: body.disabled,
    });

    return NextResponse.json({ success: true });
  } catch (error: unknown) {
    console.error(
      "Failed to update team member usage settings:",
      stringifyRedactedError(error),
    );
    return NextResponse.json(
      { error: "Unable to update member usage settings" },
      { status: 500 },
    );
  }
};
