import { NextRequest, NextResponse, after } from "next/server";
import { stripe } from "@/app/api/stripe";
import { getConvexClient } from "@/lib/db/convex-client";
import { api } from "@/convex/_generated/api";
import Stripe from "stripe";
import {
  freezeRateLimitBucketForDelinquency,
  resetRateLimitBucketAfterPayment,
  stashTierChangeBucketState,
  applyProratedTierChangeBucket,
  clearOrgRemovedUsage,
} from "@/lib/rate-limit";
import { phLogger } from "@/lib/posthog/server";
import {
  captureCheckoutPaymentAnalytics,
  isCheckoutPaymentAnalyticsEvent,
} from "@/lib/billing/checkout-payment-analytics";
import { resolveUserIdsFromCustomer as resolveStripeCustomerUsers } from "@/lib/billing/resolve-customer-users";
import { getInvoicePaidBucketResetMode } from "@/lib/billing/subscription-invoice-reset";
import {
  priceBillingInterval,
  subscriptionMrrDollars,
} from "@/lib/billing/subscription-mrr";
import type { SubscriptionTier } from "@/types";
import { getReferralRewardConfig } from "@/lib/referrals/config";
import {
  PAID_FUNNEL_EVENTS,
  billingPaymentRecoveryInsertId,
  cancellationCompletionInsertId,
  paidFunnelProperties,
  subscriptionChurnHealthProperties,
} from "@/lib/analytics/paid-funnel";
import {
  logStripeWebhookMissingSignature,
  logStripeWebhookSignatureVerificationFailed,
} from "@/lib/billing/stripe-webhook-logging";
import {
  invoicePaymentIntent,
  invoicePaymentIntentId,
  invoiceSubscriptionId,
  stripeObjectId,
  subscriptionPaymentFailureProperties,
  type BillingFailureProperties,
} from "@/lib/billing/subscription-payment-failure";
import { includedUsagePointsForStripePrice } from "@/lib/billing/included-usage";
import { subscriptionTierFromPrice } from "@/lib/billing/current-subscription";
import { recoverSubscriptionPayment } from "@/lib/billing/payment-method-recovery";
import { voidUnpaidCanceledRenewalInvoice } from "@/lib/billing/canceled-renewal-invoice";
import { requireLatePaymentReview } from "@/lib/billing/late-payment-review";
import {
  LATE_SUBSCRIPTION_PAYMENT_REFUND_REASON,
  reconcileLateSubscriptionPayment,
} from "@/lib/billing/late-subscription-payment";
import {
  PAUSE_RESUME_CHECKOUT_TYPE,
  subscriptionPauseFromMetadata,
} from "@/lib/billing/retention-offers";
import {
  proMonthlyPricingAssignmentFromMetadata,
  proMonthlyPricingExperimentProperties,
} from "@/lib/experiments/pro-monthly-pricing";
import { hasActiveSuspensionForUser } from "@/lib/suspensions";

const WEBHOOK_LOG_PREFIX = "[Subscription Webhook]";
const WEBHOOK_LOG_CONTEXT = {
  webhook: "subscription",
  route: "/api/subscription/webhook",
};
const ENTITLED_SUBSCRIPTION_STATUSES = new Set<Stripe.Subscription.Status>([
  "active",
  "trialing",
]);

// Linear ranking used to label tier transitions as upgrade/downgrade. Team is
// pinned at the top because moves between team and individual plans are rare
// and analysts can re-bucket from `from_tier`/`to_tier` if needed.
const TIER_ORDER: readonly SubscriptionTier[] = [
  "free",
  "pro",
  "pro-plus",
  "ultra",
  "team",
];

function tierDirection(
  from: SubscriptionTier | null,
  to: SubscriptionTier | null,
): "upgrade" | "downgrade" | "lateral" {
  const fi = from ? TIER_ORDER.indexOf(from) : -1;
  const ti = to ? TIER_ORDER.indexOf(to) : -1;
  if (ti > fi) return "upgrade";
  if (ti < fi) return "downgrade";
  return "lateral";
}

type PaidStartTier = Exclude<SubscriptionTier, "free">;

const centsToDollars = (amount: number | null | undefined): number =>
  (amount ?? 0) / 100;

function invoicePaidAtMs(invoice: Stripe.Invoice): number {
  const paidAt = invoice.status_transitions?.paid_at;
  if (paidAt) return paidAt * 1000;
  return (
    ((invoice as { created?: number }).created ?? Date.now() / 1000) * 1000
  );
}

function stripeEventOccurredAtMs(event: Stripe.Event): number {
  return typeof event.created === "number" &&
    Number.isFinite(event.created) &&
    event.created > 0
    ? event.created * 1000
    : Date.now();
}

/** Return every invoice line, following Stripe pagination when necessary. */
async function invoiceLineItems(
  invoice: Stripe.Invoice,
): Promise<Stripe.InvoiceLineItem[]> {
  let lines = invoice.lines?.data ?? [];
  if (invoice.lines?.has_more) {
    lines = [];
    for await (const line of stripe.invoices.listLineItems(invoice.id, {
      limit: 100,
    })) {
      lines.push(line);
    }
  }
  return lines;
}

function invoiceLineSubscriptionId(
  line: Stripe.InvoiceLineItem,
): string | undefined {
  return (
    stripeObjectId(line.subscription) ??
    line.parent?.subscription_item_details?.subscription ??
    line.parent?.invoice_item_details?.subscription ??
    undefined
  );
}

function invoiceLinePriceId(line: Stripe.InvoiceLineItem): string | undefined {
  return (
    stripeObjectId(line.pricing?.price_details?.price) ??
    stripeObjectId(
      (
        line as Stripe.InvoiceLineItem & {
          price?: string | Stripe.Price | null;
        }
      ).price,
    ) ??
    undefined
  );
}

function invoiceLineIsProration(line: Stripe.InvoiceLineItem): boolean {
  return (
    line.parent?.subscription_item_details?.proration === true ||
    line.parent?.invoice_item_details?.proration === true
  );
}

/** Return immutable billing details recorded on a subscription invoice line. */
async function invoiceSubscriptionBillingDetails(
  invoice: Stripe.Invoice,
  subscriptionId: string,
): Promise<
  | {
      priceId: string;
      quantity?: number;
      periodStart?: number;
      periodEnd?: number;
    }
  | undefined
> {
  const lines = await invoiceLineItems(invoice);
  const candidates = lines.filter(
    (line) => invoiceLineSubscriptionId(line) === subscriptionId,
  );

  const recurringLine = candidates.find(
    (line) =>
      !invoiceLineIsProration(line) &&
      line.amount > 0 &&
      invoiceLinePriceId(line),
  );
  const selectedLine =
    recurringLine ?? candidates.find((line) => invoiceLinePriceId(line));
  const priceId = selectedLine ? invoiceLinePriceId(selectedLine) : undefined;
  return priceId
    ? {
        priceId,
        ...(recurringLine?.period && {
          periodStart: recurringLine.period.start * 1000,
          periodEnd: recurringLine.period.end * 1000,
        }),
        ...(typeof selectedLine?.quantity === "number" && {
          quantity: selectedLine.quantity,
        }),
      }
    : undefined;
}

/**
 * Attribute a refund only when every positive priced line belongs to the same
 * subscription and Price. Mixed invoices need explicit line-level evidence
 * from an operator workflow before they can safely affect subscription revenue.
 */
async function subscriptionRefundPriceId(
  invoice: Stripe.Invoice,
  subscriptionId: string,
): Promise<{
  priceId?: string;
  billableLineCount: number;
  targetLineCount: number;
}> {
  const billableLines = (await invoiceLineItems(invoice)).filter(
    (line) => line.amount > 0 && invoiceLinePriceId(line),
  );
  const targetLines = billableLines.filter(
    (line) => invoiceLineSubscriptionId(line) === subscriptionId,
  );
  const targetPriceIds = new Set(
    targetLines
      .map((line) => invoiceLinePriceId(line))
      .filter((priceId): priceId is string => Boolean(priceId)),
  );
  const isUnambiguous =
    billableLines.length > 0 &&
    targetLines.length === billableLines.length &&
    targetPriceIds.size === 1;

  return {
    priceId: isUnambiguous ? [...targetPriceIds][0] : undefined,
    billableLineCount: billableLines.length,
    targetLineCount: targetLines.length,
  };
}

// =============================================================================
// Tier Resolution
// =============================================================================

/** Map Stripe price lookup key to subscription tier. */
function planLookupKeyToTier(lookupKey: string): SubscriptionTier | null {
  if (lookupKey.startsWith("ultra")) return "ultra";
  if (lookupKey.startsWith("pro-plus")) return "pro-plus";
  if (lookupKey.startsWith("team")) return "team";
  if (lookupKey.startsWith("pro")) return "pro";
  return null;
}

function toPaidStartTier(tier: SubscriptionTier): PaidStartTier | null {
  return tier === "free" ? null : tier;
}

// =============================================================================
// Helpers
// =============================================================================

const resolveUserIdsFromCustomer = (customerId: string) =>
  resolveStripeCustomerUsers(customerId, "Subscription Webhook");

const metadataString = (
  metadata: Stripe.Metadata | null | undefined,
  key: string,
): string | undefined => {
  const value = metadata?.[key];
  return typeof value === "string" && value.length > 0 ? value : undefined;
};

function subscriptionCurrentPeriodEndSeconds(
  subscription: Stripe.Subscription,
): number | undefined {
  const itemPeriodEnds = subscription.items?.data
    ?.map(
      (item) => (item as { current_period_end?: unknown }).current_period_end,
    )
    .filter(
      (periodEnd): periodEnd is number =>
        typeof periodEnd === "number" &&
        Number.isFinite(periodEnd) &&
        periodEnd > 0,
    );
  if (itemPeriodEnds?.length) return Math.max(...itemPeriodEnds);

  const periodEnd = (subscription as { current_period_end?: unknown })
    .current_period_end;
  return typeof periodEnd === "number" &&
    Number.isFinite(periodEnd) &&
    periodEnd > 0
    ? periodEnd
    : undefined;
}

function monthlyUsagePeriodEndSeconds(
  subscription: Stripe.Subscription,
): number | undefined {
  const price = subscription.items?.data[0]?.price;
  if (priceBillingInterval(price) !== "month") return undefined;
  if ((price?.recurring?.interval_count ?? 1) !== 1) return undefined;
  return subscriptionCurrentPeriodEndSeconds(subscription);
}

function monthlyTierChangeProration(
  subscription: Stripe.Subscription,
  effectiveChangeAtMs: number,
): {
  proratedRatio?: number;
  periodEndSeconds?: number;
} {
  const periodEndSeconds = monthlyUsagePeriodEndSeconds(subscription);
  if (!periodEndSeconds) return {};

  const subscriptionItem = subscription.items?.data[0] as
    { current_period_start?: number } | undefined;
  const periodStartSeconds =
    subscriptionItem?.current_period_start ??
    (subscription as { current_period_start?: number }).current_period_start;
  const effectiveChangeAtSeconds = Math.floor(effectiveChangeAtMs / 1000);
  const totalDuration = periodStartSeconds
    ? periodEndSeconds - periodStartSeconds
    : 0;
  const remainingDuration = periodEndSeconds - effectiveChangeAtSeconds;

  return {
    periodEndSeconds,
    ...(totalDuration > 0 && {
      proratedRatio: Math.max(
        0,
        Math.min(1, remainingDuration / totalDuration),
      ),
    }),
  };
}

async function applyTierChangeBuckets({
  userIds,
  tier,
  subscription,
  includedUsagePoints,
  subscriptionId,
  transitionId,
  effectiveChangeAtMs,
  source,
}: {
  userIds: string[];
  tier: SubscriptionTier;
  subscription: Stripe.Subscription;
  includedUsagePoints?: number;
  subscriptionId: string;
  transitionId: string;
  effectiveChangeAtMs: number;
  source: "invoice.paid" | "subscription.updated";
}): Promise<number> {
  const proration = monthlyTierChangeProration(
    subscription,
    effectiveChangeAtMs,
  );
  const results = await Promise.all(
    userIds.map((userId) =>
      applyProratedTierChangeBucket(userId, tier, {
        identity: { subscriptionId, targetTier: tier, transitionId },
        ...proration,
        cycleAllocationPoints: includedUsagePoints,
      }),
    ),
  );
  const appliedResults = results.filter((result) => result !== null);
  const appliedCount = appliedResults.length;
  const incrementalPoints = appliedResults.reduce(
    (total, result) => total + result.incrementalCredits,
    0,
  );

  console.log(
    appliedCount > 0
      ? `[Subscription Webhook] ${source}: applied ${tier} tier-change proration for ${appliedCount} user(s), ${incrementalPoints} incremental point(s)`
      : `[Subscription Webhook] ${source}: no tier-change state found; skipping bucket reset`,
  );
  return appliedCount;
}

async function getPaidTierChangeInvoice(
  subscription: Stripe.Subscription,
): Promise<Stripe.Invoice | null> {
  const latestInvoice = subscription.latest_invoice;
  if (!latestInvoice) return null;

  const invoice =
    typeof latestInvoice === "string"
      ? await stripe.invoices.retrieve(latestInvoice)
      : latestInvoice;
  if (invoice.status !== "paid") return null;
  return getInvoicePaidBucketResetMode(invoice).mode ===
    "subscription_update_proration"
    ? invoice
    : null;
}

type BillingFailureAnalyticsContext = {
  invoice: Stripe.Invoice;
  paymentIntent?: Stripe.PaymentIntent;
};

async function retrieveInvoiceForFailureAnalytics(
  invoiceId: string,
): Promise<BillingFailureAnalyticsContext | null> {
  let invoice: Stripe.Invoice;
  try {
    invoice = await stripe.invoices.retrieve(invoiceId, {
      expand: ["payments.data.payment.payment_intent"],
    });
  } catch (error) {
    phLogger.warn("subscription_payment_failure_invoice_retrieve_failed", {
      stripe_invoice_id: invoiceId,
      error: error instanceof Error ? error.message : String(error),
    });
    return null;
  }

  const expandedPaymentIntent = invoicePaymentIntent(invoice);
  const paymentIntentId = invoicePaymentIntentId(invoice);
  const latestCharge = expandedPaymentIntent?.latest_charge;
  if (
    !paymentIntentId ||
    latestCharge === null ||
    (latestCharge && typeof latestCharge === "object")
  ) {
    return { invoice, paymentIntent: expandedPaymentIntent };
  }

  try {
    const paymentIntent = await stripe.paymentIntents.retrieve(
      paymentIntentId,
      {
        expand: ["latest_charge"],
      },
    );
    return { invoice, paymentIntent };
  } catch (error) {
    phLogger.warn(
      "subscription_payment_failure_payment_intent_retrieve_failed",
      {
        stripe_invoice_id: invoiceId,
        stripe_payment_intent_id: paymentIntentId,
        error: error instanceof Error ? error.message : String(error),
      },
    );
    return { invoice, paymentIntent: expandedPaymentIntent };
  }
}

/** Infer subscription tier from a Stripe product name (fallback when lookup_key is missing). */
function tierFromProductName(name: string): SubscriptionTier | null {
  const lower = name.toLowerCase();
  if (lower.includes("ultra")) return "ultra";
  if (lower.includes("pro-plus") || lower.includes("pro plus"))
    return "pro-plus";
  if (lower.includes("team")) return "team";
  if (lower.includes("pro")) return "pro";
  return null;
}

type SubscriptionResolution =
  | {
      kind: "resolved";
      tier: SubscriptionTier;
      subscription: Stripe.Subscription;
    }
  | {
      kind: "legacy_pentestgpt";
      subscription: Stripe.Subscription;
    };

/** Resolve subscription tier and object from a Stripe subscription ID. */
async function resolveSubscription(
  subscriptionId: string,
  throwOnLookupFailure = false,
): Promise<SubscriptionResolution | null> {
  try {
    const subscription = await stripe.subscriptions.retrieve(subscriptionId, {
      expand: ["items.data.price", "items.data.price.product"],
    });

    const price = subscription.items?.data[0]?.price;
    const lookupKey = price?.lookup_key ?? null;

    // Fallback: infer tier from product name or metadata when lookup_key is missing
    const product = price?.product;
    const productObj =
      product && typeof product === "object" && !("deleted" in product)
        ? (product as Stripe.Product)
        : null;

    if (productObj?.name?.toLowerCase().includes("pentestgpt")) {
      console.info(
        `[Subscription Webhook] Subscription ${subscriptionId} uses legacy PentestGPT product; skipping HackerAI subscription handling`,
      );
      return { kind: "legacy_pentestgpt", subscription };
    }

    if (lookupKey) {
      const tier = planLookupKeyToTier(lookupKey);
      return tier ? { kind: "resolved", tier, subscription } : null;
    }

    const tier =
      (productObj?.metadata?.tier as SubscriptionTier | undefined) ??
      (productObj?.name ? tierFromProductName(productObj.name) : null);

    if (tier) {
      console.warn(
        `[Subscription Webhook] Subscription ${subscriptionId} missing price lookup_key, resolved tier "${tier}" from product fallback`,
      );
      return { kind: "resolved", tier, subscription };
    }

    console.error(
      `[Subscription Webhook] Subscription ${subscriptionId} has no price lookup_key and could not infer tier from product`,
    );
    return null;
  } catch (error) {
    if (throwOnLookupFailure) throw error;
    console.error(
      `[Subscription Webhook] Failed to retrieve subscription ${subscriptionId}:`,
      error,
    );
    return null;
  }
}

async function awardReferralConversion(args: {
  tier: SubscriptionTier;
  subscription: Stripe.Subscription;
  customerId: string;
  plan?: string;
  invoiceId?: string;
  checkoutSessionId?: string;
  checkoutAttemptId?: string;
}) {
  const config = getReferralRewardConfig();
  if (!config.enabled || config.referrerRewardDollars <= 0) {
    return;
  }
  if (args.tier === "free") {
    return;
  }

  const metadata = args.subscription.metadata;
  const referredUserId =
    metadataString(metadata, "userId") ??
    metadataString(metadata, "referral_referred_user_id");

  try {
    const result = await getConvexClient().mutation(
      api.referrals.awardConversionReward,
      {
        serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
        referrerRewardDollars: config.referrerRewardDollars,
        referredUserId,
        stripeCheckoutSessionId: args.checkoutSessionId,
        stripeCustomerId: args.customerId,
        stripeSubscriptionId: args.subscription.id,
        stripeInvoiceId: args.invoiceId,
        plan: args.plan,
        tier: args.tier,
      },
    );
    const referrerSubscriptionTier = (
      result as { referrerSubscriptionTier?: string }
    ).referrerSubscriptionTier;

    if (result.status === "awarded" || result.status === "already_awarded") {
      if (result.referredUserId ?? referredUserId) {
        phLogger.event("referred_user_paid_conversion", {
          userId: result.referredUserId ?? referredUserId,
          referrer_user_id: result.referrerUserId,
          referrer_subscription_tier: referrerSubscriptionTier,
          referral_code: result.referralCode,
          reward_status: result.status,
          plan: args.plan,
          tier: args.tier,
          stripe_customer_id: args.customerId,
          stripe_subscription_id: args.subscription.id,
          stripe_invoice_id: args.invoiceId,
          stripe_checkout_session_id: args.checkoutSessionId,
          checkout_attempt_id: args.checkoutAttemptId,
        });
      }

      if (result.status === "awarded" && result.referrerUserId) {
        phLogger.event("referrer_credits_awarded", {
          userId: result.referrerUserId,
          referred_user_id: result.referredUserId ?? referredUserId,
          referrer_subscription_tier: referrerSubscriptionTier,
          referral_code: result.referralCode,
          reward_dollars: config.referrerRewardDollars,
          plan: args.plan,
          tier: args.tier,
          stripe_customer_id: args.customerId,
          stripe_subscription_id: args.subscription.id,
          stripe_invoice_id: args.invoiceId,
          stripe_checkout_session_id: args.checkoutSessionId,
          checkout_attempt_id: args.checkoutAttemptId,
        });
      }
    } else if (result.status === "withheld") {
      phLogger.event("referral_reward_withheld", {
        userId: result.referredUserId ?? referredUserId,
        referrer_user_id: result.referrerUserId,
        referrer_subscription_tier: referrerSubscriptionTier,
        referral_code: result.referralCode,
        reward_type: "referrer_conversion",
        reason: result.reason,
        plan: args.plan,
        tier: args.tier,
        stripe_customer_id: args.customerId,
        stripe_subscription_id: args.subscription.id,
        stripe_invoice_id: args.invoiceId,
        stripe_checkout_session_id: args.checkoutSessionId,
        checkout_attempt_id: args.checkoutAttemptId,
      });
    }
  } catch (error) {
    phLogger.error("referral_conversion_reward_failed", {
      userId: referredUserId,
      stripe_customer_id: args.customerId,
      stripe_subscription_id: args.subscription.id,
      stripe_invoice_id: args.invoiceId,
      stripe_checkout_session_id: args.checkoutSessionId,
      checkout_attempt_id: args.checkoutAttemptId,
      error,
    });
  }
}

async function setReferralCodesPaidEligibility(args: {
  userIds: string[];
  active: boolean;
  tier?: SubscriptionTier | null;
  organizationId?: string;
}) {
  const config = getReferralRewardConfig();
  if (!config.enabled || args.userIds.length === 0) {
    return;
  }

  const subscriptionTier =
    args.tier && args.tier !== "free" ? args.tier : "free";

  try {
    await getConvexClient().mutation(
      api.referrals.setReferralCodesPaidEligibility,
      {
        serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
        userIds: args.userIds,
        active: args.active,
        ...(subscriptionTier && { subscriptionTier }),
        ...(args.organizationId && { organizationId: args.organizationId }),
      },
    );
  } catch (error) {
    phLogger.warn("referral_paid_eligibility_update_failed", {
      userId: args.userIds[0],
      user_ids: args.userIds,
      active: args.active,
      tier: args.tier,
      organization_id: args.organizationId,
      error: error instanceof Error ? error.message : String(error),
    });
  }
}

async function recordSubscriptionRevenue({
  invoice,
  invoicePrice,
  customerId,
  userIds,
  orgId,
  tier,
  subscription,
  invoiceQuantity,
  reason,
}: {
  invoice: Stripe.Invoice;
  invoicePrice: Stripe.Price;
  customerId: string;
  userIds: string[];
  orgId?: string;
  tier: SubscriptionTier;
  subscription: Stripe.Subscription;
  invoiceQuantity?: number;
  reason: string;
}) {
  const grossRevenueDollars = centsToDollars(
    (invoice as { amount_paid?: number }).amount_paid,
  );

  if (grossRevenueDollars <= 0 || userIds.length === 0) return;

  const item = subscription.items?.data[0];
  const occurredAt = invoicePaidAtMs(invoice);
  const attributedRevenueDollars = grossRevenueDollars / userIds.length;
  const attributionStrategy = userIds.length > 1 ? "split_evenly" : "direct";
  const mrrDollars =
    reason === "subscription_create" || reason === "subscription_cycle"
      ? subscriptionMrrDollars({
          price: invoicePrice,
          quantity: invoiceQuantity ?? item?.quantity ?? 1,
          fallbackTotalIntervalAmountDollars: grossRevenueDollars,
        })
      : undefined;
  const attributedMrrDollars =
    mrrDollars === undefined ? undefined : mrrDollars / userIds.length;

  await Promise.all([
    ...userIds.map((uid) =>
      getConvexClient().mutation(api.unitEconomics.recordRevenueEvent, {
        serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
        entityType: "user",
        entityId: uid,
        userId: uid,
        organizationId: orgId,
        source: "subscription",
        sourceEventId: invoice.id,
        idempotencyKey: `subscription:${invoice.id}:user:${uid}`,
        grossRevenueDollars: attributedRevenueDollars,
        mrrDollars: attributedMrrDollars,
        currency: invoice.currency ?? "usd",
        occurredAt,
        attributionStrategy,
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscription.id,
        stripeInvoiceId: invoice.id,
        stripePriceId: invoicePrice.id,
        plan: invoicePrice.lookup_key ?? tier,
        quantity: invoiceQuantity ?? item?.quantity,
        userCount: userIds.length,
        description: reason,
      }),
    ),
    ...(orgId
      ? [
          getConvexClient().mutation(api.unitEconomics.recordRevenueEvent, {
            serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
            entityType: "organization",
            entityId: orgId,
            organizationId: orgId,
            source: "subscription",
            sourceEventId: invoice.id,
            idempotencyKey: `subscription:${invoice.id}:organization:${orgId}`,
            grossRevenueDollars,
            mrrDollars,
            currency: invoice.currency ?? "usd",
            occurredAt,
            attributionStrategy: "organization_pool",
            stripeCustomerId: customerId,
            stripeSubscriptionId: subscription.id,
            stripeInvoiceId: invoice.id,
            stripePriceId: invoicePrice.id,
            plan: invoicePrice.lookup_key ?? tier,
            quantity: invoiceQuantity ?? item?.quantity,
            userCount: userIds.length,
            description: reason,
          }),
        ]
      : []),
  ]);
}

function emitInvoicePaidRevenueAnalytics({
  invoice,
  invoicePrice,
  stripeEventId,
  customerId,
  userIds,
  orgId,
  tier,
  subscription,
  invoiceQuantity,
  periodStart,
  periodEnd,
}: {
  invoice: Stripe.Invoice;
  invoicePrice: Stripe.Price;
  stripeEventId: string;
  customerId: string;
  userIds: string[];
  orgId?: string;
  tier: SubscriptionTier;
  subscription: Stripe.Subscription;
  invoiceQuantity?: number;
  periodStart?: number;
  periodEnd?: number;
}) {
  const amountPaidDollars = centsToDollars(invoice.amount_paid);
  if (amountPaidDollars <= 0 || userIds.length === 0) return;

  const pricingExperiment = proMonthlyPricingAssignmentFromMetadata(
    subscription.metadata,
    invoicePrice.lookup_key,
  );
  const attributedRevenueDollars = amountPaidDollars / userIds.length;
  const subscriptionMrr = subscriptionMrrDollars({
    price: invoicePrice,
    quantity: invoiceQuantity ?? subscription.items?.data[0]?.quantity ?? 1,
    fallbackTotalIntervalAmountDollars: amountPaidDollars,
  });
  const attributedMrrDollars =
    subscriptionMrr === undefined
      ? undefined
      : subscriptionMrr / userIds.length;

  for (const uid of userIds) {
    phLogger.event(
      PAID_FUNNEL_EVENTS.invoicePaid,
      paidFunnelProperties({
        userId: uid,
        org_id: orgId,
        subscription_tier: tier,
        plan: invoicePrice.lookup_key ?? tier,
        stripe_price_lookup_key: invoicePrice.lookup_key,
        billing_interval: priceBillingInterval(invoicePrice),
        billing_interval_count: invoicePrice.recurring?.interval_count,
        billing_reason: invoice.billing_reason,
        invoice_paid_at: invoicePaidAtMs(invoice),
        billing_period_start: periodStart,
        billing_period_end: periodEnd,
        attempt_count: invoice.attempt_count ?? undefined,
        ...(typeof invoice.attempt_count === "number" &&
          invoice.attempt_count > 1 && { recovery_result: "recovered" }),
        amount_paid_dollars: amountPaidDollars,
        attributed_revenue_dollars: attributedRevenueDollars,
        subscription_mrr_dollars: subscriptionMrr,
        attributed_mrr_dollars: attributedMrrDollars,
        retained_mrr_dollars: attributedMrrDollars,
        user_count: userIds.length,
        currency: invoice.currency,
        stripe_event_id: stripeEventId,
        stripe_event_type: "invoice.paid",
        stripe_customer_id: customerId,
        stripe_subscription_id: subscription.id,
        stripe_invoice_id: invoice.id,
        stripe_price_id: invoicePrice.id,
        charged_amount_dollars: amountPaidDollars,
        ...proMonthlyPricingExperimentProperties(pricingExperiment),
        $insert_id: `${PAID_FUNNEL_EVENTS.invoicePaid}:${stripeEventId}:${uid}`,
        $set: {
          subscription_tier: tier,
        },
      }),
    );
  }
}

async function recordPaidStartMix({
  invoice,
  invoicePrice,
  customerId,
  userIds,
  orgId,
  tier,
  subscription,
  periodEnd,
}: {
  invoice: Stripe.Invoice;
  invoicePrice: Stripe.Price;
  customerId: string;
  userIds: string[];
  orgId?: string;
  tier: SubscriptionTier;
  subscription: Stripe.Subscription;
  periodEnd?: number;
}) {
  const paidStartTier = toPaidStartTier(tier);
  if (!paidStartTier || userIds.length === 0) return;

  const item = subscription.items?.data[0];
  const occurredAt = invoicePaidAtMs(invoice);
  const entityType = orgId ? "organization" : "user";
  const entityId = orgId ?? userIds[0];
  const paidSeatCount = item?.quantity ?? userIds.length;

  await getConvexClient().mutation(api.unitEconomics.recordPaidStartEvent, {
    serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
    entityType,
    entityId,
    userId: userIds[0],
    organizationId: orgId,
    sourceEventId: invoice.id,
    idempotencyKey: `paid_start:${invoice.id}:${entityType}:${entityId}`,
    occurredAt,
    conversionType: "free_to_paid",
    tier: paidStartTier,
    plan: invoicePrice.lookup_key ?? paidStartTier,
    paidAccountStartCount: 1,
    paidUserStartCount: userIds.length,
    paidSeatCount,
    billingPeriodEnd: periodEnd,
    billingInterval: priceBillingInterval(invoicePrice),
    billingIntervalCount: invoicePrice.recurring?.interval_count,
    quantity: item?.quantity,
    userCount: userIds.length,
    stripeCustomerId: customerId,
    stripeSubscriptionId: subscription.id,
    stripeInvoiceId: invoice.id,
    stripePriceId: invoicePrice.id,
  });
}

async function emitBillingPaymentFailed(args: {
  stripeEventId: string;
  stripeEventType: "invoice.payment_failed" | "customer.subscription.deleted";
  invoice: Stripe.Invoice;
  paymentIntent?: Stripe.PaymentIntent;
  customerId: string;
  userIds: string[];
  orgId?: string;
  tier?: SubscriptionTier | null;
  price?: Stripe.Price;
  lifecycle: BillingFailureProperties["billing_failure_lifecycle"];
}) {
  if (args.userIds.length === 0) return;

  const failureProperties = subscriptionPaymentFailureProperties({
    invoice: args.invoice,
    lifecycle: args.lifecycle,
    paymentIntent: args.paymentIntent,
  });

  for (const uid of args.userIds) {
    phLogger.event(
      PAID_FUNNEL_EVENTS.billingPaymentFailed,
      paidFunnelProperties({
        userId: uid,
        org_id: args.orgId,
        subscription_tier: args.tier,
        plan: args.price?.lookup_key,
        billing_interval: priceBillingInterval(args.price),
        billing_interval_count: args.price?.recurring?.interval_count,
        stripe_customer_id: args.customerId,
        stripe_subscription_id:
          invoiceSubscriptionId(args.invoice) ??
          stripeObjectId(
            (
              args.invoice as unknown as {
                subscription?: string | { id?: string } | null;
              }
            ).subscription,
          ),
        stripe_price_id: args.price?.id,
        stripe_event_id: args.stripeEventId,
        stripe_event_type: args.stripeEventType,
        ...failureProperties,
        $insert_id: `${PAID_FUNNEL_EVENTS.billingPaymentFailed}:${args.stripeEventId}:${uid}`,
      }),
    );
  }
}

type InvoluntaryChurnStripeEventType =
  | "invoice.payment_failed"
  | "invoice.paid"
  | "customer.subscription.deleted"
  | "payment_method.attached"
  | "customer.updated"
  | "customer.subscription.updated";

async function recordInvoluntaryChurnEvent(args: {
  stripeEventId: string;
  stripeEventType: InvoluntaryChurnStripeEventType;
  occurredAt: number;
  invoice: Stripe.Invoice;
  customerId: string;
  userIds: string[];
  orgId?: string;
  stripeSubscriptionId: string;
  tier?: SubscriptionTier | null;
  price?: Stripe.Price;
  failureProperties?: BillingFailureProperties;
  invoicePaidEligible?: boolean;
  priorFailureKnown?: boolean;
}) {
  const failure = args.failureProperties;
  const results = await Promise.all(
    args.userIds.map((userId) =>
      getConvexClient().mutation(api.involuntaryChurn.recordEvent, {
        serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
        stripeEventId: args.stripeEventId,
        stripeEventType: args.stripeEventType,
        userId,
        organizationId: args.orgId,
        stripeCustomerId: args.customerId,
        stripeSubscriptionId: args.stripeSubscriptionId,
        stripeInvoiceId: args.invoice.id,
        stripePaymentIntentId: failure?.stripe_payment_intent_id,
        stripeChargeId: failure?.stripe_charge_id,
        stripePriceId: args.price?.id,
        plan: args.price?.lookup_key ?? undefined,
        subscriptionTier: args.tier ?? undefined,
        billingFailureLifecycle: failure?.billing_failure_lifecycle,
        billingFailureStage: failure?.billing_failure_stage,
        billingFailureGroup: failure?.billing_failure_group,
        billingReason:
          failure?.billing_reason ?? args.invoice.billing_reason ?? undefined,
        invoiceStatus:
          failure?.invoice_status ?? args.invoice.status ?? undefined,
        attemptCount: failure?.attempt_count ?? args.invoice.attempt_count,
        outcomeType: failure?.outcome_type ?? undefined,
        outcomeReason: failure?.outcome_reason ?? undefined,
        riskLevel: failure?.risk_level ?? undefined,
        amountDueDollars:
          failure?.amount_due_dollars ??
          centsToDollars(args.invoice.amount_due),
        amountRemainingDollars:
          failure?.amount_remaining_dollars ??
          centsToDollars(args.invoice.amount_remaining),
        currency: failure?.currency ?? args.invoice.currency,
        invoicePaidEligible: args.invoicePaidEligible,
        priorFailureKnown: args.priorFailureKnown,
        occurredAt: args.occurredAt,
      }),
    ),
  );

  return {
    priorFailureSeen: results.some((result) => result.priorFailureSeen),
    recovered: results.some((result) => result.recoveryResult === "recovered"),
    recoveredUserIds: args.userIds.filter(
      (_, index) => results[index]?.recoveryResult === "recovered",
    ),
    paymentMethodUpdatedUserIds: args.userIds.filter(
      (_, index) => results[index]?.recoveryResult === "payment_method_updated",
    ),
  };
}

// =============================================================================
// Event Handlers
// =============================================================================

/** Handle invoice.paid — reset rate limit buckets on subscription payment. */
async function handleInvoicePaid(
  invoice: Stripe.Invoice,
  stripeEventId: string,
  eventOccurredAtMs: number,
): Promise<void> {
  // In Stripe API 2026-03-25, subscription lives under invoice.parent.subscription_details
  const subDetails = invoice.parent?.subscription_details;
  const subscriptionId = subDetails
    ? typeof subDetails.subscription === "string"
      ? subDetails.subscription
      : subDetails.subscription?.id
    : null;

  // Only process subscription invoices (not one-time payments)
  if (!subscriptionId) return;

  const customerId =
    typeof invoice.customer === "string"
      ? invoice.customer
      : invoice.customer?.id;

  if (!customerId) {
    console.error(
      "[Subscription Webhook] invoice.paid missing customer ID:",
      invoice.id,
    );
    return;
  }

  const resetMode = getInvoicePaidBucketResetMode(invoice);
  const customerResult = await resolveUserIdsFromCustomer(customerId);
  const { userIds, orgId } = customerResult;
  if (customerResult.reason === "lookup_failed") {
    throw new Error("Paid invoice customer lookup failed");
  }

  if (customerResult.reason === "legacy_user_metadata") {
    console.info(
      `[Subscription Webhook] invoice.paid: skipping legacy customer invoice ${invoice.id} for customer ${customerId}`,
    );
    return;
  }

  const resolved = await resolveSubscription(subscriptionId, true);
  if (!resolved) {
    console.error(
      `[Subscription Webhook] Could not resolve subscription ${subscriptionId} for invoice ${invoice.id}`,
    );
    return;
  }
  if (resolved.kind === "legacy_pentestgpt") {
    console.info(
      `[Subscription Webhook] invoice.paid: skipping legacy PentestGPT subscription ${subscriptionId} for invoice ${invoice.id}`,
    );
    return;
  }

  const { tier, subscription } = resolved;
  const paidAfterCancellation =
    subscription.status === "canceled" &&
    !!subscription.ended_at &&
    (invoice.status_transitions?.paid_at ?? 0) > subscription.ended_at;
  if (userIds.length === 0) {
    if (paidAfterCancellation) {
      await requireLatePaymentReview(
        stripe,
        invoice,
        "paid_invoice_without_resolved_user",
      );
    }
    console.error(
      `[Subscription Webhook] Could not resolve users (${customerResult.reason ?? "unknown"}) for invoice ${invoice.id}`,
    );
    return;
  }
  const entitlementItem = subscription.items?.data[0];
  const entitlementPrice = entitlementItem?.price;
  const invoiceBillingDetails = await invoiceSubscriptionBillingDetails(
    invoice,
    subscriptionId,
  );
  if (!invoiceBillingDetails) {
    phLogger.warn("invoice_paid_historical_price_missing", {
      stripe_invoice_id: invoice.id,
      stripe_subscription_id: subscriptionId,
    });
    throw new Error("Historical subscription Price missing from paid invoice");
  }
  const { priceId: invoicePriceId, quantity: invoiceQuantity } =
    invoiceBillingDetails;

  let invoicePrice: Stripe.Price;
  if (entitlementPrice?.id === invoicePriceId) {
    invoicePrice = entitlementPrice;
  } else {
    try {
      invoicePrice = await stripe.prices.retrieve(invoicePriceId);
    } catch (error) {
      phLogger.warn("invoice_paid_historical_price_retrieve_failed", {
        stripe_invoice_id: invoice.id,
        stripe_subscription_id: subscriptionId,
        stripe_price_id: invoicePriceId,
        error: error instanceof Error ? error.message : String(error),
      });
      throw error;
    }
  }

  // A paid historical invoice does not reactivate its subscription. Only the
  // current invoice of an entitled subscription may restore paid benefits.
  const latestInvoiceId = stripeObjectId(subscription.latest_invoice);
  const isEntitledSubscription = ENTITLED_SUBSCRIPTION_STATUSES.has(
    subscription.status,
  );
  const isCurrentInvoice = latestInvoiceId === invoice.id;
  if (!isEntitledSubscription || !isCurrentInvoice) {
    await recordInvoluntaryChurnEvent({
      stripeEventId,
      stripeEventType: "invoice.paid",
      occurredAt: eventOccurredAtMs,
      invoice,
      customerId,
      userIds,
      orgId: orgId ?? undefined,
      stripeSubscriptionId: subscription.id,
      tier,
      price: invoicePrice,
      invoicePaidEligible: false,
    });
    const reconciliation = await reconcileLateSubscriptionPayment(
      stripe,
      invoice,
      subscription,
    );
    if (
      reconciliation.status === "manual_review" ||
      (reconciliation.status === "not_applicable" && paidAfterCancellation)
    ) {
      await requireLatePaymentReview(
        stripe,
        invoice,
        reconciliation.status === "manual_review"
          ? reconciliation.reason
          : "paid_invoice_without_current_entitlement",
      );
    }
    if (reconciliation.status !== "not_applicable") {
      const properties = {
        stripe_event_id: stripeEventId,
        stripe_invoice_id: invoice.id,
        stripe_subscription_id: subscription.id,
        stripe_customer_id: customerId,
        reconciliation_status: reconciliation.status,
        ...(reconciliation.status === "manual_review"
          ? { reconciliation_reason: reconciliation.reason }
          : { stripe_refund_id: reconciliation.refundId }),
        amount_paid_dollars: centsToDollars(invoice.amount_paid),
      };
      for (const userId of userIds) {
        phLogger.event("billing_late_payment_reconciled", {
          userId,
          ...properties,
          $insert_id: `billing_late_payment_reconciled:${invoice.id}:${reconciliation.status}:${userId}`,
        });
      }
      if (reconciliation.status === "manual_review") {
        phLogger.error(
          "billing_late_payment_requires_manual_reconciliation",
          properties,
        );
      } else {
        // Record the cash receipt without recovered MRR or paid access, so
        // the refund webhook's negative revenue has a matching positive entry.
        await recordSubscriptionRevenue({
          invoice,
          invoicePrice,
          customerId,
          userIds,
          orgId: orgId ?? undefined,
          tier,
          subscription,
          invoiceQuantity,
          reason: "late_payment_after_cancellation",
        });
        phLogger.info("billing_late_payment_refund", properties);
        return;
      }
    }
    phLogger.warn("billing_invoice_paid_ineligible_subscription_skipped", {
      event: "billing_invoice_paid_ineligible_subscription_skipped",
      userId: userIds[0],
      user_ids: userIds,
      org_id: orgId,
      stripe_customer_id: customerId,
      stripe_subscription_id: subscription.id,
      stripe_invoice_id: invoice.id,
      stripe_latest_invoice_id: latestInvoiceId,
      subscription_status: subscription.status,
      skip_reason: !isEntitledSubscription
        ? "subscription_not_entitled"
        : "invoice_not_current",
      billing_reason: invoice.billing_reason,
      amount_paid_dollars: centsToDollars(invoice.amount_paid),
      canceled_at: subscription.canceled_at,
      ended_at: subscription.ended_at,
      requires_manual_reconciliation: true,
    });
    return;
  }

  const includedUsagePoints = includedUsagePointsForStripePrice(
    entitlementPrice?.id,
  );

  await setReferralCodesPaidEligibility({
    userIds,
    active: true,
    tier,
    organizationId: orgId ?? undefined,
  });

  try {
    await recordSubscriptionRevenue({
      invoice,
      invoicePrice,
      customerId,
      userIds,
      orgId: orgId ?? undefined,
      tier,
      subscription,
      invoiceQuantity,
      reason: resetMode.reason,
    });
  } catch (error) {
    console.error("[Subscription Webhook] Failed to record revenue:", {
      error,
      invoiceId: invoice.id,
      customerId,
      userCount: userIds.length,
      orgId,
      tier,
      resetReason: resetMode.reason,
    });
  }

  emitInvoicePaidRevenueAnalytics({
    invoice,
    invoicePrice,
    stripeEventId,
    customerId,
    userIds,
    orgId: orgId ?? undefined,
    tier,
    subscription,
    invoiceQuantity,
    periodStart: invoiceBillingDetails.periodStart,
    periodEnd: invoiceBillingDetails.periodEnd,
  });

  if (resetMode.mode === "skip") {
    console.log(
      `[Subscription Webhook] invoice.paid (${resetMode.reason}): skipping bucket reset for invoice ${invoice.id}`,
    );
    return;
  }

  // Mid-cycle tier change: apply only a previously stashed bucket migration.
  // Missing state is intentionally a no-op so quantity/anchor changes cannot
  // mint a fresh monthly allocation.
  if (resetMode.mode === "subscription_update_proration") {
    await applyTierChangeBuckets({
      userIds,
      tier,
      subscription,
      includedUsagePoints,
      subscriptionId,
      transitionId: invoice.id,
      effectiveChangeAtMs: invoicePaidAtMs(invoice),
      source: "invoice.paid",
    });
    return;
  }

  // Regular renewal or new subscription: full credits
  console.log(
    `[Subscription Webhook] invoice.paid (${resetMode.reason}): resetting ${tier} buckets for ${userIds.length} user(s)`,
  );
  const usagePeriodEnd = monthlyUsagePeriodEndSeconds(subscription);
  const paidTransitionAtMs = invoice.status_transitions?.paid_at
    ? invoice.status_transitions.paid_at * 1000
    : eventOccurredAtMs;
  const resetResults = await Promise.all(
    userIds.map((uid) =>
      resetRateLimitBucketAfterPayment(
        uid,
        tier,
        {
          subscriptionId,
          invoiceId: invoice.id,
          occurredAtMs: paidTransitionAtMs,
        },
        usagePeriodEnd,
        includedUsagePoints,
      ),
    ),
  );
  const staleResetCount = resetResults.filter(
    (result) => result.outcome === "stale",
  ).length;
  if (staleResetCount > 0) {
    phLogger.warn("billing_paid_credit_reset_stale_ignored", {
      event: "billing_paid_credit_reset_stale_ignored",
      userId: userIds[0],
      user_ids: userIds,
      org_id: orgId,
      stripe_customer_id: customerId,
      stripe_subscription_id: subscriptionId,
      stripe_invoice_id: invoice.id,
      subscription_tier: tier,
      transition_at_ms: paidTransitionAtMs,
      stale_user_count: staleResetCount,
    });
  }

  const recoveryPrice = invoicePrice;
  const isRecoveredReset = (
    result: (typeof resetResults)[number] | undefined,
  ): boolean =>
    result?.recoveredFromPaymentFailure === true ||
    (invoice.billing_reason === "subscription_cycle" &&
      result?.outcome === "applied" &&
      typeof invoice.attempt_count === "number" &&
      invoice.attempt_count > 1);
  const recoveredUserIds = userIds.filter((_, index) =>
    isRecoveredReset(resetResults[index]),
  );
  if (recoveredUserIds.length > 0) {
    await recordInvoluntaryChurnEvent({
      stripeEventId,
      stripeEventType: "invoice.paid",
      occurredAt: eventOccurredAtMs,
      invoice,
      customerId,
      userIds: recoveredUserIds,
      orgId: orgId ?? undefined,
      stripeSubscriptionId: subscription.id,
      tier,
      price: recoveryPrice,
      invoicePaidEligible: true,
      priorFailureKnown: true,
    });
  }

  for (const [index, result] of resetResults.entries()) {
    if (!isRecoveredReset(result)) continue;

    const uid = userIds[index];
    if (!uid) continue;

    const paymentFailureAtMs = result.paymentFailureAtMs;
    phLogger.event(
      PAID_FUNNEL_EVENTS.billingPaymentRecovered,
      paidFunnelProperties({
        userId: uid,
        org_id: orgId,
        subscription_tier: tier,
        plan: recoveryPrice?.lookup_key ?? tier,
        billing_interval: priceBillingInterval(recoveryPrice),
        billing_interval_count: recoveryPrice?.recurring?.interval_count,
        recovery_type: "invoice_paid_after_payment_failure",
        recovery_detection: result.recoveredFromPaymentFailure
          ? "stored_payment_failure_transition"
          : "invoice_attempt_count",
        ...(paymentFailureAtMs && {
          payment_failure_at: new Date(paymentFailureAtMs).toISOString(),
          recovery_duration_ms: Math.max(
            0,
            paidTransitionAtMs - paymentFailureAtMs,
          ),
        }),
        attempt_count: invoice.attempt_count,
        amount_paid_dollars: centsToDollars(invoice.amount_paid),
        currency: invoice.currency,
        stripe_customer_id: customerId,
        stripe_subscription_id: subscriptionId,
        stripe_invoice_id: invoice.id,
        stripe_price_id: recoveryPrice?.id,
        stripe_event_id: stripeEventId,
        stripe_event_type: "invoice.paid",
        $insert_id: billingPaymentRecoveryInsertId(stripeEventId, uid),
      }),
    );
  }

  if (resetMode.reason === "subscription_create") {
    const item = entitlementItem;
    const checkoutAttemptId = metadataString(
      subscription.metadata,
      "checkoutAttemptId",
    );
    const checkoutSource = metadataString(
      subscription.metadata,
      "checkoutSource",
    );
    const checkoutSurface = metadataString(
      subscription.metadata,
      "checkoutSurface",
    );
    const checkoutSessionId = metadataString(
      subscription.metadata,
      "stripeCheckoutSessionId",
    );
    const invoiceAmountPaidDollars = centsToDollars(
      (invoice as { amount_paid?: number }).amount_paid,
    );
    const attributedRevenueDollars =
      userIds.length > 0 ? invoiceAmountPaidDollars / userIds.length : 0;
    const billingInterval = priceBillingInterval(invoicePrice);
    const pricingExperiment = proMonthlyPricingAssignmentFromMetadata(
      subscription.metadata,
      invoicePrice.lookup_key,
    );
    const subscriptionMrr = subscriptionMrrDollars({
      price: invoicePrice,
      quantity: item?.quantity ?? 1,
      fallbackTotalIntervalAmountDollars: invoiceAmountPaidDollars,
    });
    const attributedMrrDollars =
      subscriptionMrr === undefined
        ? undefined
        : subscriptionMrr / userIds.length;
    const paidSeatCount = item?.quantity ?? userIds.length;
    // A retention pause ending re-creates the subscription server-side. That
    // is a reactivation, not a new paid start, so keep it out of the paid
    // start mix and zero the start counters on the analytics event.
    const resumedFromPause =
      metadataString(subscription.metadata, "checkoutType") ===
      PAUSE_RESUME_CHECKOUT_TYPE;

    if (!resumedFromPause) {
      try {
        await recordPaidStartMix({
          periodEnd: invoiceBillingDetails.periodEnd,
          invoice,
          invoicePrice,
          customerId,
          userIds,
          orgId: orgId ?? undefined,
          tier,
          subscription,
        });
      } catch (error) {
        console.error(
          "[Subscription Webhook] Failed to record paid start mix:",
          {
            error,
            invoiceId: invoice.id,
            customerId,
            userCount: userIds.length,
            orgId,
            tier,
          },
        );
      }
    }

    for (const [index, uid] of userIds.entries()) {
      phLogger.event("subscription_started", {
        userId: uid,
        from_tier: "free",
        to_tier: tier,
        conversion_type: resumedFromPause ? "pause_resume" : "free_to_paid",
        resumed_from_pause: resumedFromPause,
        ...(resumedFromPause && {
          pause_id: metadataString(subscription.metadata, "hackeraiPauseId"),
          paused_stripe_subscription_id: metadataString(
            subscription.metadata,
            "hackeraiResumedFromSubscriptionId",
          ),
        }),
        org_id: orgId,
        user_count: userIds.length,
        plan: invoicePrice.lookup_key,
        stripe_price_lookup_key: invoicePrice.lookup_key,
        paid_account_start_count: resumedFromPause ? 0 : index === 0 ? 1 : 0,
        paid_user_start_count: resumedFromPause ? 0 : 1,
        paid_account_user_count: userIds.length,
        paid_seat_count: paidSeatCount,
        paid_start_plan: invoicePrice.lookup_key ?? tier,
        paid_start_tier: tier,
        billing_interval: billingInterval,
        paid_start_billing_interval: billingInterval ?? "unknown",
        billing_interval_count: invoicePrice.recurring?.interval_count,
        quantity: item?.quantity,
        checkout_attempt_id: checkoutAttemptId,
        checkout_type:
          metadataString(subscription.metadata, "checkoutType") ??
          "new_subscription",
        surface: checkoutSurface,
        source: checkoutSource,
        invoice_amount_paid_dollars: invoiceAmountPaidDollars,
        attributed_revenue_dollars: attributedRevenueDollars,
        revenue_dollars: attributedRevenueDollars,
        subscription_mrr_dollars: subscriptionMrr,
        attributed_mrr_dollars: attributedMrrDollars,
        mrr_dollars: attributedMrrDollars,
        currency: invoice.currency,
        stripe_customer_id: customerId,
        stripe_subscription_id: subscription.id,
        stripe_invoice_id: invoice.id,
        stripe_checkout_session_id: checkoutSessionId,
        stripe_price_id: invoicePrice.id,
        charged_amount_dollars: invoiceAmountPaidDollars,
        ...proMonthlyPricingExperimentProperties(pricingExperiment),
        $set: {
          subscription_tier: tier,
          last_subscription_started_at: new Date().toISOString(),
        },
        $set_once: {
          first_subscription_started_at: new Date().toISOString(),
          first_paid_tier: tier,
        },
      });
    }

    await awardReferralConversion({
      tier,
      subscription,
      customerId,
      plan: invoicePrice.lookup_key ?? undefined,
      invoiceId: invoice.id,
      checkoutSessionId,
      checkoutAttemptId,
    });
  }

  // Clear team seat rotation debt on renewal (fresh cycle)
  if (tier === "team" && orgId) {
    await clearOrgRemovedUsage(orgId);
  }
}

async function handleInvoicePaymentFailed(
  invoice: Stripe.Invoice,
  stripeEventId: string,
  eventOccurredAtMs: number,
): Promise<void> {
  const subscriptionId = invoiceSubscriptionId(invoice);
  if (!subscriptionId) return;

  const customerId =
    typeof invoice.customer === "string"
      ? invoice.customer
      : invoice.customer?.id;

  if (!customerId) {
    console.error(
      "[Subscription Webhook] invoice.payment_failed missing customer ID:",
      invoice.id,
    );
    return;
  }

  const customerResult = await resolveUserIdsFromCustomer(customerId);
  const { userIds, orgId } = customerResult;

  if (customerResult.reason === "legacy_user_metadata") {
    console.info(
      `[Subscription Webhook] invoice.payment_failed: skipping legacy customer invoice ${invoice.id} for customer ${customerId}`,
    );
    return;
  }

  if (userIds.length === 0) {
    console.error(
      `[Subscription Webhook] Could not resolve users (${customerResult.reason ?? "unknown"}) for failed invoice ${invoice.id}`,
    );
    return;
  }

  const resolved = await resolveSubscription(subscriptionId);
  if (resolved?.kind === "legacy_pentestgpt") {
    console.info(
      `[Subscription Webhook] invoice.payment_failed: skipping legacy PentestGPT subscription ${subscriptionId} for invoice ${invoice.id}`,
    );
    return;
  }

  const failureContext = await retrieveInvoiceForFailureAnalytics(invoice.id);
  const failureInvoice = failureContext?.invoice ?? invoice;
  const subscription =
    resolved?.kind === "resolved" ? resolved.subscription : undefined;
  const price = subscription?.items?.data[0]?.price;
  const failureProperties = subscriptionPaymentFailureProperties({
    invoice: failureInvoice,
    lifecycle: "invoice_payment_failed",
    paymentIntent: failureContext?.paymentIntent,
  });

  if (
    resolved?.kind === "resolved" &&
    failureInvoice.billing_reason === "subscription_cycle" &&
    failureInvoice.status !== "paid" &&
    subscription?.status === "past_due"
  ) {
    const holdResults = await Promise.all(
      userIds.map((userId) =>
        freezeRateLimitBucketForDelinquency(userId, resolved.tier, {
          subscriptionId,
          invoiceId: failureInvoice.id,
          occurredAtMs: eventOccurredAtMs,
        }),
      ),
    );
    const appliedUserCount = holdResults.filter(
      (result) => result.outcome === "applied",
    ).length;
    const alreadyAppliedUserCount = holdResults.filter(
      (result) => result.outcome === "already_applied",
    ).length;
    const staleUserCount = holdResults.filter(
      (result) => result.outcome === "stale",
    ).length;
    const remainingPoints = holdResults.reduce(
      (total, result) => total + result.remainingPoints,
      0,
    );
    const logFields = {
      event:
        staleUserCount > 0
          ? "billing_delinquency_credit_hold_stale_ignored"
          : "billing_delinquency_credit_hold_processed",
      userId: userIds[0],
      user_ids: userIds,
      org_id: orgId,
      stripe_customer_id: customerId,
      stripe_subscription_id: subscriptionId,
      stripe_invoice_id: failureInvoice.id,
      subscription_tier: resolved.tier,
      subscription_status: subscription.status,
      billing_reason: failureInvoice.billing_reason,
      transition_at_ms: eventOccurredAtMs,
      applied_user_count: appliedUserCount,
      already_applied_user_count: alreadyAppliedUserCount,
      stale_user_count: staleUserCount,
      remaining_points: remainingPoints,
    };
    if (staleUserCount > 0) {
      phLogger.warn("billing_delinquency_credit_hold_stale_ignored", logFields);
    } else {
      phLogger.info("billing_delinquency_credit_hold_processed", logFields);
    }
  }

  await recordInvoluntaryChurnEvent({
    stripeEventId,
    stripeEventType: "invoice.payment_failed",
    occurredAt: eventOccurredAtMs,
    invoice: failureInvoice,
    customerId,
    userIds,
    orgId: orgId ?? undefined,
    stripeSubscriptionId: subscriptionId,
    tier: resolved?.kind === "resolved" ? resolved.tier : undefined,
    price,
    failureProperties,
  });

  await emitBillingPaymentFailed({
    stripeEventId,
    stripeEventType: "invoice.payment_failed",
    invoice: failureInvoice,
    paymentIntent: failureContext?.paymentIntent,
    customerId,
    userIds,
    orgId: orgId ?? undefined,
    tier: resolved?.kind === "resolved" ? resolved.tier : undefined,
    price,
    lifecycle: "invoice_payment_failed",
  });
}

function customerPaymentMethodChanged(
  previousAttributes: Partial<Stripe.Customer> | undefined,
  paymentMethodId: string,
): boolean {
  if (!previousAttributes) return false;
  const previousInvoiceSettings = previousAttributes.invoice_settings;
  return (
    previousInvoiceSettings !== undefined &&
    previousInvoiceSettings !== null &&
    Object.prototype.hasOwnProperty.call(
      previousInvoiceSettings,
      "default_payment_method",
    ) &&
    stripeObjectId(previousInvoiceSettings.default_payment_method) !==
      paymentMethodId
  );
}

async function handlePaymentMethodUpdated(args: {
  customerId: string;
  stripeEventId: string;
  stripeEventType: "customer.updated" | "customer.subscription.updated";
  eventOccurredAtMs: number;
  paymentMethodId: string;
  subscriptionId?: string;
}): Promise<void> {
  // Webhooks can arrive out of order. Only act on a default that is still
  // selected, never on an attachment or an older customer-update payload.
  if (!args.subscriptionId) {
    const customer = await stripe.customers.retrieve(args.customerId);
    if (
      customer.deleted ||
      stripeObjectId(customer.invoice_settings.default_payment_method) !==
        args.paymentMethodId
    )
      return;
  }
  const customerResult = await resolveUserIdsFromCustomer(args.customerId);
  const { userIds, orgId } = customerResult;
  if (customerResult.reason === "lookup_failed") {
    throw new Error("Payment recovery customer lookup failed");
  }
  if (
    customerResult.reason === "legacy_user_metadata" ||
    userIds.length === 0
  ) {
    return;
  }

  const activeSuspensions = await Promise.all(
    userIds.map((userId) => hasActiveSuspensionForUser(userId)),
  );
  // Recovery can charge the shared Stripe customer. A hold on any resolved
  // member therefore blocks the customer-level operation, not just that
  // member's analytics or entitlement updates.
  if (activeSuspensions.some(Boolean)) {
    return;
  }

  const subscriptionIds: string[] = [];
  if (args.subscriptionId) {
    subscriptionIds.push(args.subscriptionId);
  } else {
    let startingAfter: string | undefined;
    do {
      const page = await stripe.subscriptions.list({
        customer: args.customerId,
        status: "all",
        limit: 100,
        ...(startingAfter && { starting_after: startingAfter }),
      });
      subscriptionIds.push(
        ...page.data
          .filter((s) =>
            ["active", "trialing", "past_due", "unpaid"].includes(s.status),
          )
          .map((s) => s.id),
      );
      startingAfter = page.has_more ? page.data.at(-1)?.id : undefined;
    } while (startingAfter);
  }

  for (const subscriptionId of subscriptionIds) {
    const resolved = await resolveSubscription(subscriptionId, true);
    if (!resolved || resolved.kind === "legacy_pentestgpt") continue;
    const { subscription, tier } = resolved;
    if (
      stripeObjectId(subscription.customer) !== args.customerId ||
      !["active", "trialing", "past_due", "unpaid"].includes(
        subscription.status,
      ) ||
      (args.subscriptionId &&
        stripeObjectId(subscription.default_payment_method) !==
          args.paymentMethodId)
    )
      continue;

    const invoiceId = stripeObjectId(subscription.latest_invoice);
    const price = subscription.items?.data[0]?.price;
    // This is a card-selection event, not proof of payment or restored access.
    // Emit even if invoice.paid arrived first or there is no failure-ledger row.
    for (const uid of userIds) {
      phLogger.event(
        PAID_FUNNEL_EVENTS.paymentMethodUpdated,
        paidFunnelProperties({
          userId: uid,
          org_id: orgId,
          subscription_tier: tier,
          plan: price?.lookup_key,
          stripe_event_id: args.stripeEventId,
          stripe_event_type: args.stripeEventType,
          stripe_customer_id: args.customerId,
          stripe_subscription_id: subscription.id,
          stripe_invoice_id: invoiceId,
          payment_method_scope: args.subscriptionId
            ? "subscription"
            : "customer",
          subscription_status: subscription.status,
          recovery_result: "payment_method_updated",
          $insert_id: `${PAID_FUNNEL_EVENTS.paymentMethodUpdated}:${args.stripeEventId}:${subscription.id}:${uid}`,
        }),
      );
    }

    if (!invoiceId) continue;
    const failureContext = await retrieveInvoiceForFailureAnalytics(invoiceId);
    if (!failureContext)
      throw new Error("Payment recovery invoice lookup failed");
    const failureProperties = subscriptionPaymentFailureProperties({
      invoice: failureContext.invoice,
      lifecycle: "invoice_payment_failed",
      paymentIntent: failureContext.paymentIntent,
    });
    await recordInvoluntaryChurnEvent({
      stripeEventId: args.stripeEventId,
      stripeEventType: args.stripeEventType,
      occurredAt: args.eventOccurredAtMs,
      invoice: failureContext.invoice,
      customerId: args.customerId,
      userIds,
      orgId: orgId ?? undefined,
      stripeSubscriptionId: subscription.id,
      tier,
      price,
      failureProperties,
    });
    await recoverSubscriptionPayment({
      stripe,
      subscription,
      invoice: failureContext.invoice,
      paymentMethodId: args.paymentMethodId,
      paymentIntent: failureContext.paymentIntent,
      selectionEventId: args.stripeEventId,
      customerEventCreated: args.subscriptionId
        ? undefined
        : Math.floor(args.eventOccurredAtMs / 1000),
    });
  }
}

async function handleSubscriptionRefund(
  refund: Stripe.Refund,
  stripeEventId: string,
  stripeEventType: "refund.created" | "refund.updated",
): Promise<void> {
  if (refund.status !== "succeeded") {
    if (
      refund.metadata?.hackeraiReason ===
        LATE_SUBSCRIPTION_PAYMENT_REFUND_REASON &&
      ["failed", "canceled", "requires_action"].includes(refund.status ?? "")
    ) {
      phLogger.error("billing_late_payment_requires_manual_reconciliation", {
        stripe_event_id: stripeEventId,
        stripe_refund_id: refund.id,
        stripe_invoice_id: refund.metadata?.stripeInvoiceId,
        stripe_subscription_id: refund.metadata?.stripeSubscriptionId,
        reconciliation_status: "manual_review",
        reconciliation_reason: `refund_${refund.status}`,
      });
    }
    return;
  }

  const chargeId = stripeObjectId(refund.charge);
  if (!chargeId || refund.amount <= 0) return;

  const charge = await stripe.charges.retrieve(chargeId);
  const chargeInvoiceId = stripeObjectId(
    (charge as Stripe.Charge & { invoice?: string | Stripe.Invoice | null })
      .invoice,
  );
  // Newer Stripe versions link invoices through Invoice Payments instead of
  // Charge.invoice. Our late-payment refunds retain that verified allocation.
  const managedLateRefund =
    refund.metadata?.hackeraiReason === LATE_SUBSCRIPTION_PAYMENT_REFUND_REASON;
  const invoiceId =
    chargeInvoiceId ||
    (managedLateRefund ? refund.metadata?.stripeInvoiceId : undefined);
  if (!invoiceId) return;

  const invoice = await stripe.invoices.retrieve(invoiceId);
  const subscriptionId = invoiceSubscriptionId(invoice);
  if (!subscriptionId) return;
  if (
    !chargeInvoiceId &&
    (subscriptionId !== refund.metadata?.stripeSubscriptionId ||
      !stripeObjectId(invoice.customer) ||
      stripeObjectId(invoice.customer) !== stripeObjectId(charge.customer))
  ) {
    phLogger.error("billing_late_payment_requires_manual_reconciliation", {
      stripe_event_id: stripeEventId,
      stripe_refund_id: refund.id,
      stripe_invoice_id: invoice.id,
      stripe_subscription_id: subscriptionId,
      reconciliation_status: "manual_review",
      reconciliation_reason: "refund_attribution_mismatch",
    });
    return;
  }

  const resolved = await resolveSubscription(subscriptionId, true);
  if (!resolved || resolved.kind === "legacy_pentestgpt") return;

  const customerId =
    stripeObjectId(invoice.customer) ?? stripeObjectId(charge.customer);
  if (!customerId) return;

  const customerResult = await resolveUserIdsFromCustomer(customerId);
  if (customerResult.reason === "lookup_failed") {
    throw new Error("Refund customer lookup failed");
  }
  const { userIds, orgId } = customerResult;
  if (userIds.length === 0) return;

  const refundAttribution = await subscriptionRefundPriceId(
    invoice,
    subscriptionId,
  );
  const invoicePriceId = refundAttribution.priceId;
  if (!invoicePriceId) {
    phLogger.warn("subscription_refund_attribution_unavailable", {
      stripe_refund_id: refund.id,
      stripe_invoice_id: invoiceId,
      stripe_subscription_id: subscriptionId,
      refund_amount_dollars: centsToDollars(refund.amount),
      billable_line_count: refundAttribution.billableLineCount,
      target_subscription_line_count: refundAttribution.targetLineCount,
      requires_manual_reconciliation: true,
    });
    return;
  }
  let price: Stripe.Price;
  try {
    price = await stripe.prices.retrieve(invoicePriceId);
  } catch (error) {
    phLogger.warn("subscription_refund_invoice_price_retrieve_failed", {
      stripe_invoice_id: invoiceId,
      stripe_price_id: invoicePriceId,
      error: error instanceof Error ? error.message : String(error),
    });
    throw error;
  }
  const refundedTier = price?.lookup_key
    ? (planLookupKeyToTier(price.lookup_key) ?? resolved.tier)
    : resolved.tier;
  const pricingExperiment = proMonthlyPricingAssignmentFromMetadata(
    resolved.subscription.metadata,
    price?.lookup_key,
  );
  const refundAmountDollars = centsToDollars(refund.amount);
  const attributedRefundDollars = refundAmountDollars / userIds.length;
  const occurredAt = refund.created ? refund.created * 1000 : Date.now();

  await Promise.all([
    ...userIds.map((userId) =>
      getConvexClient().mutation(api.unitEconomics.recordRevenueEvent, {
        serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
        entityType: "user",
        entityId: userId,
        userId,
        organizationId: orgId ?? undefined,
        source: "subscription",
        sourceEventId: refund.id,
        idempotencyKey: `subscription_refund:${refund.id}:user:${userId}`,
        grossRevenueDollars: -attributedRefundDollars,
        netRevenueDollars: -attributedRefundDollars,
        currency: refund.currency,
        occurredAt,
        attributionStrategy: userIds.length > 1 ? "split_evenly" : "direct",
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscriptionId,
        stripeInvoiceId: invoiceId,
        stripePaymentIntentId: stripeObjectId(refund.payment_intent),
        stripePriceId: price?.id,
        plan: price?.lookup_key ?? resolved.tier,
        userCount: userIds.length,
        description: "refund",
      }),
    ),
    ...(orgId
      ? [
          getConvexClient().mutation(api.unitEconomics.recordRevenueEvent, {
            serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
            entityType: "organization",
            entityId: orgId,
            organizationId: orgId,
            source: "subscription",
            sourceEventId: refund.id,
            idempotencyKey: `subscription_refund:${refund.id}:organization:${orgId}`,
            grossRevenueDollars: -refundAmountDollars,
            netRevenueDollars: -refundAmountDollars,
            currency: refund.currency,
            occurredAt,
            attributionStrategy: "organization_pool",
            stripeCustomerId: customerId,
            stripeSubscriptionId: subscriptionId,
            stripeInvoiceId: invoiceId,
            stripePaymentIntentId: stripeObjectId(refund.payment_intent),
            stripePriceId: price?.id,
            plan: price?.lookup_key ?? resolved.tier,
            userCount: userIds.length,
            description: "refund",
          }),
        ]
      : []),
  ]);

  for (const userId of userIds) {
    phLogger.event(
      PAID_FUNNEL_EVENTS.subscriptionRefunded,
      paidFunnelProperties({
        userId,
        org_id: orgId,
        subscription_tier: refundedTier,
        plan: price?.lookup_key,
        stripe_price_lookup_key: price?.lookup_key,
        billing_interval: priceBillingInterval(price),
        billing_interval_count: price?.recurring?.interval_count,
        refund_amount_dollars: refundAmountDollars,
        attributed_refund_dollars: attributedRefundDollars,
        charged_amount_dollars: -attributedRefundDollars,
        currency: refund.currency,
        stripe_event_id: stripeEventId,
        stripe_event_type: stripeEventType,
        stripe_customer_id: customerId,
        stripe_subscription_id: subscriptionId,
        stripe_invoice_id: invoiceId,
        stripe_payment_intent_id: stripeObjectId(refund.payment_intent),
        stripe_charge_id: chargeId,
        stripe_refund_id: refund.id,
        stripe_price_id: price?.id,
        ...proMonthlyPricingExperimentProperties(pricingExperiment),
        $insert_id: `${PAID_FUNNEL_EVENTS.subscriptionRefunded}:${refund.id}:${userId}`,
      }),
    );
  }
}

/** Handle checkout.session.completed — attach Checkout Session IDs to saved referral attribution. */
async function handleCheckoutSessionCompleted(
  session: Stripe.Checkout.Session,
): Promise<void> {
  if (session.mode !== "subscription") return;

  const customerId =
    typeof session.customer === "string"
      ? session.customer
      : session.customer?.id;
  const subscriptionId =
    typeof session.subscription === "string"
      ? session.subscription
      : session.subscription?.id;

  if (!customerId) return;

  const referredUserId =
    metadataString(session.metadata, "userId") ??
    metadataString(session.metadata, "referral_referred_user_id");
  const checkoutAttemptId = metadataString(
    session.metadata,
    "checkoutAttemptId",
  );
  const checkoutSource = metadataString(session.metadata, "checkoutSource");
  const checkoutSurface = metadataString(session.metadata, "checkoutSurface");
  const checkoutType =
    metadataString(session.metadata, "checkoutType") ?? "new_subscription";
  const organizationId = metadataString(
    session.metadata,
    "workOSOrganizationId",
  );

  if (referredUserId) {
    try {
      await getConvexClient().mutation(
        api.referrals.recordReferralCheckoutSession,
        {
          serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
          referredUserId,
          stripeCustomerId: customerId,
          stripeCheckoutSessionId: session.id,
          stripeSubscriptionId: subscriptionId,
          requestedPlan:
            metadataString(session.metadata, "requestedPlan") ?? "unknown",
        },
      );
    } catch (error) {
      phLogger.warn("referral_checkout_session_record_failed", {
        userId: referredUserId,
        stripe_customer_id: customerId,
        stripe_checkout_session_id: session.id,
        stripe_subscription_id: subscriptionId,
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  if (!subscriptionId || session.payment_status !== "paid") return;

  const resolved = await resolveSubscription(subscriptionId);
  if (!resolved) return;
  if (resolved.kind === "legacy_pentestgpt") {
    console.info(
      `[Subscription Webhook] checkout.session.completed: skipping legacy PentestGPT subscription ${subscriptionId}`,
    );
    return;
  }

  const price = resolved.subscription.items?.data[0]?.price;
  const existingMetadata = resolved.subscription.metadata ?? {};
  const pricingExperiment =
    proMonthlyPricingAssignmentFromMetadata(
      existingMetadata,
      price?.lookup_key,
    ) ??
    proMonthlyPricingAssignmentFromMetadata(
      session.metadata,
      price?.lookup_key,
    );
  if (checkoutAttemptId || checkoutSource || checkoutSurface) {
    try {
      await stripe.subscriptions.update(subscriptionId, {
        metadata: {
          ...existingMetadata,
          ...(checkoutAttemptId && { checkoutAttemptId }),
          ...(checkoutSource && { checkoutSource }),
          ...(checkoutSurface && { checkoutSurface }),
          checkoutType,
          stripeCheckoutSessionId: session.id,
        },
      });
    } catch (error) {
      phLogger.warn("subscription_checkout_metadata_update_failed", {
        userId: referredUserId,
        stripe_subscription_id: subscriptionId,
        stripe_checkout_session_id: session.id,
        checkout_attempt_id: checkoutAttemptId,
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }

  if (referredUserId) {
    phLogger.event(
      PAID_FUNNEL_EVENTS.checkoutSucceeded,
      paidFunnelProperties({
        userId: referredUserId,
        org_id: organizationId,
        checkout_attempt_id: checkoutAttemptId,
        checkout_type: checkoutType,
        from_tier: "free",
        to_tier: resolved.tier,
        plan: price?.lookup_key,
        requested_plan: metadataString(session.metadata, "requestedPlan"),
        stripe_price_lookup_key: price?.lookup_key,
        billing_interval: priceBillingInterval(price),
        billing_interval_count: price?.recurring?.interval_count,
        quantity: resolved.subscription.items?.data[0]?.quantity,
        surface: checkoutSurface,
        source: checkoutSource,
        checkout_amount_dollars: centsToDollars(session.amount_total),
        currency: session.currency,
        stripe_customer_id: customerId,
        stripe_subscription_id: subscriptionId,
        stripe_checkout_session_id: session.id,
        stripe_price_id: price?.id,
        charged_amount_dollars: centsToDollars(session.amount_total),
        payment_status: session.payment_status,
        ...proMonthlyPricingExperimentProperties(pricingExperiment),
        $insert_id: `${PAID_FUNNEL_EVENTS.checkoutSucceeded}:${session.id}`,
        $set: {
          last_checkout_succeeded_at: new Date().toISOString(),
        },
      }),
    );
  }

  await awardReferralConversion({
    tier: resolved.tier,
    subscription: resolved.subscription,
    customerId,
    plan: price?.lookup_key ?? undefined,
    checkoutSessionId: session.id,
    checkoutAttemptId,
  });
}

/** Handle customer.subscription.updated — reset old tier's buckets on plan change. */
async function handleSubscriptionUpdated(
  subscription: Stripe.Subscription,
  previousAttributes: Partial<Stripe.Subscription> | undefined,
  eventOccurredAtMs: number,
): Promise<void> {
  if (
    subscription.cancel_at_period_end === false &&
    previousAttributes?.cancel_at_period_end === true
  ) {
    const customerId = stripeObjectId(subscription.customer);
    if (customerId) {
      await getConvexClient().mutation(
        api.cancellationReasons.markCancellationReversed,
        {
          serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
          stripeSubscriptionId: subscription.id,
          stripeCustomerId: customerId,
          cancellationReasonId:
            subscription.metadata?.hackerai_cancellation_reason_id,
          reversedAt: eventOccurredAtMs,
        },
      );
    }
  }
  const cancellationJustScheduled =
    subscription.cancel_at_period_end === true &&
    Boolean(previousAttributes) &&
    Object.prototype.hasOwnProperty.call(
      previousAttributes,
      "cancel_at_period_end",
    ) &&
    (previousAttributes as { cancel_at_period_end?: boolean })
      .cancel_at_period_end !== true;

  if (cancellationJustScheduled) {
    const customerId =
      typeof subscription.customer === "string"
        ? subscription.customer
        : subscription.customer?.id;

    if (customerId) {
      const currentPrice = subscription.items?.data[0]?.price;
      const lookupKey = currentPrice?.lookup_key ?? null;
      const tier = subscriptionTierFromPrice(currentPrice) ?? null;
      const { userIds, orgId } = await resolveUserIdsFromCustomer(customerId);

      if (userIds.length === 0) {
        console.error(
          `[Subscription Webhook] subscription.updated cancellation: could not resolve users for customer ${customerId}`,
        );
      } else {
        await recordCancellationCompleted({
          subscription,
          customerId,
          userIds,
          orgId: orgId ?? undefined,
          tier,
          price: currentPrice,
          completionType: "scheduled",
          eventOccurredAtMs,
        });
      }
    }
  }

  // Only act if the subscription items actually changed (plan change)
  const previousItems = (previousAttributes as any)?.items;
  if (!previousItems) return;

  const currentPrice = subscription.items?.data[0]?.price;
  const currentLookupKey = currentPrice?.lookup_key ?? null;
  let currentTier = subscriptionTierFromPrice(currentPrice) ?? null;

  // Fallback: infer current tier from product when lookup_key is missing
  if (!currentTier && currentPrice?.product) {
    const product = currentPrice.product;
    const productObj =
      product && typeof product === "object" && !("deleted" in product)
        ? (product as Stripe.Product)
        : null;
    currentTier =
      (productObj?.metadata?.tier as SubscriptionTier | undefined) ??
      (productObj?.name ? tierFromProductName(productObj.name) : null) ??
      null;
  }

  const previousPriceId = previousItems?.data?.[0]?.price?.id;
  const previousTier =
    subscriptionTierFromPrice(
      previousItems?.data?.[0]?.price as Stripe.Price | undefined,
    ) ?? null;

  // If tiers are the same, invoice.paid will handle the reset
  if (currentTier === previousTier) return;

  const customerId =
    typeof subscription.customer === "string"
      ? subscription.customer
      : subscription.customer?.id;

  if (!customerId) return;

  const { userIds, orgId } = await resolveUserIdsFromCustomer(customerId);
  if (userIds.length === 0) {
    console.error(
      `[Subscription Webhook] subscription.updated: could not resolve users for customer ${customerId}`,
    );
    return;
  }

  console.log(
    `[Subscription Webhook] subscription.updated: tier change ${previousTier} → ${currentTier} for ${userIds.length} user(s)`,
  );

  const direction = tierDirection(previousTier, currentTier);
  const checkoutAttemptId = metadataString(
    subscription.metadata,
    "checkoutAttemptId",
  );
  const checkoutSource = metadataString(
    subscription.metadata,
    "checkoutSource",
  );
  const checkoutSurface = metadataString(
    subscription.metadata,
    "checkoutSurface",
  );
  for (const uid of userIds) {
    phLogger.event("subscription_changed", {
      userId: uid,
      from_tier: previousTier,
      to_tier: currentTier,
      direction,
      org_id: orgId,
      checkout_attempt_id: checkoutAttemptId,
      surface: checkoutSurface,
      source: checkoutSource,
      plan: currentLookupKey,
      billing_interval: priceBillingInterval(currentPrice),
      // Only update the person property when we resolved the new tier. A null
      // currentTier means Stripe's lookup_key + product fallbacks both failed,
      // and coercing to "free" would silently move possibly-paid users out of
      // the paid cohort.
      ...(currentTier && { $set: { subscription_tier: currentTier } }),
    });
  }

  // Preserve the old cycle before removing its tier-specific key. Usually the
  // following invoice.paid event applies the new bucket. If Stripe delivered
  // invoice.paid first, apply it here from the already-paid latest invoice.
  if (previousTier && currentTier) {
    const latestInvoiceId = stripeObjectId(subscription.latest_invoice);
    const transitionId =
      latestInvoiceId ??
      `subscription:${subscription.id}:${currentTier}:${subscriptionCurrentPeriodEndSeconds(subscription) ?? "unknown"}`;
    const previousIncludedUsagePoints = includedUsagePointsForStripePrice(
      typeof previousPriceId === "string" ? previousPriceId : undefined,
    );
    await Promise.all(
      userIds.map((uid) =>
        stashTierChangeBucketState(uid, previousTier, {
          identity: {
            subscriptionId: subscription.id,
            targetTier: currentTier,
            transitionId,
          },
          oldCycleAllocationPoints: previousIncludedUsagePoints,
        }),
      ),
    );

    const paidTierChangeInvoice = await getPaidTierChangeInvoice(subscription);
    if (paidTierChangeInvoice) {
      await applyTierChangeBuckets({
        userIds,
        tier: currentTier,
        subscription,
        includedUsagePoints: includedUsagePointsForStripePrice(
          currentPrice?.id,
        ),
        subscriptionId: subscription.id,
        transitionId: paidTierChangeInvoice.id,
        effectiveChangeAtMs: invoicePaidAtMs(paidTierChangeInvoice),
        source: "subscription.updated",
      });
    }
  }
}

/** Use the event's attempt and occurrence time so delayed delivery cannot complete a later decision. */
async function recordCancellationCompleted(args: {
  subscription: Stripe.Subscription;
  customerId: string;
  userIds: string[];
  orgId?: string;
  tier: SubscriptionTier | null;
  price?: Stripe.Price;
  completionType: "scheduled" | "deleted";
  eventOccurredAtMs: number;
}) {
  const stripeCancellationReason =
    args.subscription.cancellation_details?.reason ?? undefined;
  const canceledAt = args.subscription.canceled_at
    ? args.subscription.canceled_at * 1000
    : undefined;
  const completedAt = canceledAt ?? args.eventOccurredAtMs;
  const pricingExperiment = proMonthlyPricingAssignmentFromMetadata(
    args.subscription.metadata,
    args.price?.lookup_key,
  );
  const subscriptionMrr = subscriptionMrrDollars({
    price: args.price,
    quantity: args.subscription.items?.data[0]?.quantity ?? 1,
  });
  const attributedMrrDollars =
    subscriptionMrr === undefined
      ? undefined
      : subscriptionMrr / args.userIds.length;
  const pauseProperties = retentionPauseProperties(args.subscription);

  let updatedCount = 0;
  let cancellationReasonId: string | undefined;
  try {
    const result = await getConvexClient().mutation(
      api.cancellationReasons.markCancellationCompleted,
      {
        serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
        cancellationReasonId:
          args.subscription.metadata?.hackerai_cancellation_reason_id,
        stripeSubscriptionId: args.subscription.id,
        stripeCustomerId: args.customerId,
        userIds: args.userIds,
        organizationId: args.orgId,
        subscriptionTier: args.tier ?? undefined,
        stripeCancellationReason,
        cancelAtPeriodEnd: args.subscription.cancel_at_period_end,
        completedAt,
      },
    );
    updatedCount = result.updatedCount;
    cancellationReasonId = result.cancellationReasonId;
  } catch (error) {
    phLogger.warn("cancellation_reason_completion_update_failed", {
      stripe_customer_id: args.customerId,
      stripe_subscription_id: args.subscription.id,
      org_id: args.orgId,
      error,
    });
    // Let Stripe retry a failed write instead of acknowledging lost feedback.
    throw error;
  }

  if (updatedCount === 0) {
    return;
  }

  for (const uid of args.userIds) {
    phLogger.event(
      PAID_FUNNEL_EVENTS.cancellationCompleted,
      paidFunnelProperties({
        userId: uid,
        subscription_tier: args.tier,
        org_id: args.orgId,
        plan: args.price?.lookup_key,
        stripe_price_lookup_key: args.price?.lookup_key,
        billing_interval: priceBillingInterval(args.price),
        billing_interval_count: args.price?.recurring?.interval_count,
        cancellation_reason: stripeCancellationReason,
        churn_type: "voluntary",
        voluntary_churn: true,
        involuntary_churn: false,
        subscription_mrr_dollars: subscriptionMrr,
        attributed_mrr_dollars: attributedMrrDollars,
        at_risk_mrr_dollars: attributedMrrDollars,
        cancellation_completion_type: args.completionType,
        cancel_at_period_end: args.subscription.cancel_at_period_end,
        ...pauseProperties,
        stripe_customer_id: args.customerId,
        stripe_subscription_id: args.subscription.id,
        stripe_price_id: args.price?.id,
        ...proMonthlyPricingExperimentProperties(pricingExperiment),
        $insert_id: cancellationCompletionInsertId(
          args.subscription.id,
          cancellationReasonId,
        ),
      }),
    );
  }
}

/**
 * Analytics properties that mark a cancellation as a retention pause so churn
 * dashboards can separate "paused, resumes later" from a plain cancellation.
 */
function retentionPauseProperties(subscription: Stripe.Subscription) {
  const pause = subscriptionPauseFromMetadata(subscription.metadata);
  if (!pause) return { retention_pause: false };
  return {
    retention_pause: true,
    retention_offer_accepted: "pause",
    pause_months: pause.months,
    pause_resume_at: new Date(pause.resumeAtMs).toISOString(),
    pause_id: pause.pauseId,
  };
}

/** Move the Convex pause record to "paused" once Stripe ends the subscription. */
async function markRetentionPauseEffective(
  subscription: Stripe.Subscription,
  occurredAtMs: number,
): Promise<void> {
  const pause = subscriptionPauseFromMetadata(subscription.metadata);
  if (!pause) return;

  try {
    const result = await getConvexClient().mutation(
      api.subscriptionPauses.markPauseEffective,
      {
        serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
        stripeSubscriptionId: subscription.id,
        pausedAt: occurredAtMs,
      },
    );
    if (result.updatedCount === 0) {
      phLogger.warn("subscription_pause_effective_record_missing", {
        stripe_subscription_id: subscription.id,
        pause_id: pause.pauseId,
      });
    }
  } catch (error) {
    phLogger.error("subscription_pause_effective_update_failed", {
      stripe_subscription_id: subscription.id,
      pause_id: pause.pauseId,
      error,
    });
  }
}

/** Handle customer.subscription.deleted — emit churn analytics for the lapsed paid users. */
async function handleSubscriptionDeleted(
  subscription: Stripe.Subscription,
  stripeEventId: string,
  eventOccurredAtMs: number,
): Promise<void> {
  const customerId =
    typeof subscription.customer === "string"
      ? subscription.customer
      : subscription.customer?.id;
  if (!customerId) return;

  // Cleanup is Stripe-only and validates its own plan/invoice eligibility. Run
  // it before plan or user hydration can return early and acknowledge deletion.
  if (
    ["payment_failed", "cancellation_requested"].includes(
      subscription.cancellation_details?.reason ?? "",
    )
  ) {
    const renewalResult = await voidUnpaidCanceledRenewalInvoice(
      stripe,
      subscription,
      { requireIndividualPlan: true },
    );
    phLogger.info("billing_canceled_renewal_cleanup", {
      stripe_event_id: stripeEventId,
      stripe_subscription_id: subscription.id,
      stripe_invoice_id: stripeObjectId(subscription.latest_invoice),
      result: renewalResult,
    });
  }

  let price = subscription.items?.data[0]?.price;
  const lookupKey = price?.lookup_key ?? null;
  let tier: SubscriptionTier | null = null;

  if (!lookupKey) {
    const resolved = await resolveSubscription(subscription.id);
    if (!resolved) {
      console.info(
        `[Subscription Webhook] subscription.deleted: skipping subscription ${subscription.id} without HackerAI price lookup_key or product fallback for customer ${customerId}`,
      );
      return;
    }

    if (resolved.kind === "legacy_pentestgpt") {
      console.info(
        `[Subscription Webhook] subscription.deleted: skipping legacy PentestGPT subscription ${subscription.id} for customer ${customerId}`,
      );
      return;
    }

    tier = resolved.tier;
    price = resolved.subscription.items?.data[0]?.price ?? price;
  } else {
    tier = planLookupKeyToTier(lookupKey);
    if (!tier) {
      console.error(
        `[Subscription Webhook] subscription.deleted: unknown price lookup_key "${lookupKey}" for subscription ${subscription.id}`,
      );
      return;
    }
  }

  const { userIds, orgId, reason } =
    await resolveUserIdsFromCustomer(customerId);
  if (userIds.length === 0) {
    const message = `[Subscription Webhook] subscription.deleted: could not resolve users for customer ${customerId} (${reason ?? "unknown"})`;
    if (reason === "customer_deleted") {
      console.info(`${message}; likely account deletion cleanup`);
    } else {
      console.error(message);
    }
    return;
  }

  const cancellationReason = subscription.cancellation_details?.reason ?? null;
  const subscriptionMrr = subscriptionMrrDollars({
    price,
    quantity: subscription.items?.data[0]?.quantity ?? 1,
  });
  const attributedMrrDollars =
    subscriptionMrr === undefined
      ? undefined
      : subscriptionMrr / userIds.length;
  console.log(
    `[Subscription Webhook] subscription.deleted: tier ${tier ?? "unknown"} cancelled for ${userIds.length} user(s) (reason: ${cancellationReason ?? "none"})`,
  );

  await recordCancellationCompleted({
    subscription,
    customerId,
    userIds,
    orgId: orgId ?? undefined,
    tier,
    price,
    completionType: "deleted",
    eventOccurredAtMs,
  });
  await markRetentionPauseEffective(subscription, eventOccurredAtMs);
  const pauseProperties = retentionPauseProperties(subscription);

  for (const uid of userIds) {
    phLogger.event("subscription_cancelled", {
      userId: uid,
      tier,
      org_id: orgId,
      cancellation_reason: cancellationReason,
      ...subscriptionChurnHealthProperties(cancellationReason),
      ...pauseProperties,
      subscription_mrr_dollars: subscriptionMrr,
      attributed_mrr_dollars: attributedMrrDollars,
      lost_mrr_dollars: attributedMrrDollars,
      stripe_event_id: stripeEventId,
      stripe_event_type: "customer.subscription.deleted",
      $insert_id: `subscription_cancelled:${stripeEventId}:${uid}`,
      $set: { subscription_tier: "free" },
    });
  }

  await setReferralCodesPaidEligibility({
    userIds,
    active: false,
  });

  if (cancellationReason !== "payment_failed") return;

  const latestInvoiceId = stripeObjectId(subscription.latest_invoice);
  if (!latestInvoiceId) {
    throw new Error(
      `Payment-failed subscription ${subscription.id} is missing its latest invoice`,
    );
  }
  const failureContext =
    await retrieveInvoiceForFailureAnalytics(latestInvoiceId);
  if (!failureContext) {
    // Terminal cancellation state above is durable. Preserve the Stripe event
    // for retry until its stable invoice/attempt identity is also recorded.
    throw new Error(
      `Failed to hydrate payment-failed invoice ${latestInvoiceId}`,
    );
  }
  const failureProperties = subscriptionPaymentFailureProperties({
    invoice: failureContext.invoice,
    lifecycle: "subscription_deleted",
    paymentIntent: failureContext.paymentIntent,
  });

  await recordInvoluntaryChurnEvent({
    stripeEventId,
    stripeEventType: "customer.subscription.deleted",
    occurredAt: eventOccurredAtMs,
    invoice: failureContext.invoice,
    customerId,
    userIds,
    orgId: orgId ?? undefined,
    stripeSubscriptionId: subscription.id,
    tier,
    price,
    failureProperties,
  });

  await emitBillingPaymentFailed({
    stripeEventId,
    stripeEventType: "customer.subscription.deleted",
    invoice: failureContext.invoice,
    paymentIntent: failureContext.paymentIntent,
    customerId,
    userIds,
    orgId: orgId ?? undefined,
    tier,
    price,
    lifecycle: "subscription_deleted",
  });
}

// =============================================================================
// Webhook Endpoint
// =============================================================================

/**
 * POST /api/subscription/webhook
 * Handles Stripe subscription lifecycle events to reset rate limit buckets.
 *
 * Configure in Stripe Dashboard:
 * - Endpoint URL: https://your-domain.com/api/subscription/webhook
 * - Events: checkout.session.completed, invoice.paid,
 *   invoice.payment_failed, customer.subscription.updated,
 *   customer.subscription.deleted, customer.updated,
 *   refund.created, refund.updated, checkout.session.expired,
 *   payment_intent.payment_failed, payment_intent.requires_action,
 *   payment_intent.canceled, payment_intent.succeeded
 */
export async function POST(req: NextRequest) {
  const body = await req.text();
  const signature = req.headers.get("stripe-signature");

  if (!signature) {
    logStripeWebhookMissingSignature({
      logPrefix: WEBHOOK_LOG_PREFIX,
      ...WEBHOOK_LOG_CONTEXT,
      requestHeaders: req.headers,
      body,
      signature,
    });
    return NextResponse.json(
      { error: "Missing stripe-signature header" },
      { status: 400 },
    );
  }

  const webhookSecret = process.env.STRIPE_SUBSCRIPTION_WEBHOOK_SECRET;
  if (!webhookSecret) {
    console.error(
      "[Subscription Webhook] STRIPE_SUBSCRIPTION_WEBHOOK_SECRET is not configured",
    );
    return NextResponse.json(
      { error: "Webhook secret not configured" },
      { status: 500 },
    );
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
  } catch (err) {
    logStripeWebhookSignatureVerificationFailed({
      logPrefix: WEBHOOK_LOG_PREFIX,
      ...WEBHOOK_LOG_CONTEXT,
      requestHeaders: req.headers,
      body,
      signature,
      error: err,
    });
    return NextResponse.json(
      { error: "Webhook signature verification failed" },
      { status: 400 },
    );
  }

  // Analytics-only events must not consume the shared fulfillment idempotency
  // record: other webhook endpoints may handle the same PaymentIntent event.
  if (isCheckoutPaymentAnalyticsEvent(event.type)) {
    try {
      await captureCheckoutPaymentAnalytics(stripe, event);
      after(() => phLogger.flush());
      return NextResponse.json({ received: true });
    } catch {
      // Avoid logging Stripe objects or raw errors containing payment details.
      phLogger.warn("checkout_payment_analytics_lookup_failed", {
        stripe_event_id: event.id,
        stripe_event_type: event.type,
      });
      after(() => phLogger.flush());
      return NextResponse.json(
        { error: "Checkout analytics lookup failed" },
        { status: 500 },
      );
    }
  }

  // Payment-mode Checkout Sessions are fulfilled by their own webhook routes.
  // Do not consume those event ids into the shared webhook idempotency table.
  if (
    event.type === "checkout.session.completed" &&
    (event.data.object as Stripe.Checkout.Session).mode !== "subscription"
  ) {
    return NextResponse.json({ received: true });
  }

  // Idempotency check (check only — mark after successful processing)
  try {
    const result = await getConvexClient().mutation(
      api.extraUsage.checkAndMarkWebhook,
      {
        serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
        eventId: event.id,
        checkOnly: true,
      },
    );

    if (result.alreadyProcessed) {
      console.log(
        `[Subscription Webhook] Event ${event.id} already processed, skipping`,
      );
      return NextResponse.json({ received: true });
    }
  } catch (error) {
    console.error("[Subscription Webhook] Idempotency check failed:", error);
    // Return 500 so Stripe retries
    return NextResponse.json(
      { error: "Failed to check idempotency" },
      { status: 500 },
    );
  }

  // Handle events
  switch (event.type) {
    case "checkout.session.completed": {
      await handleCheckoutSessionCompleted(
        event.data.object as Stripe.Checkout.Session,
      );
      break;
    }
    case "invoice.paid": {
      await handleInvoicePaid(
        event.data.object as Stripe.Invoice,
        event.id,
        stripeEventOccurredAtMs(event),
      );
      break;
    }
    case "invoice.payment_failed": {
      await handleInvoicePaymentFailed(
        event.data.object as Stripe.Invoice,
        event.id,
        stripeEventOccurredAtMs(event),
      );
      break;
    }
    case "customer.subscription.updated": {
      const updated = event.data.object as Stripe.Subscription;
      const previous = event.data.previous_attributes as
        Partial<Stripe.Subscription> | undefined;
      const paymentMethodId = stripeObjectId(updated.default_payment_method);
      const customerId = stripeObjectId(updated.customer);
      if (
        customerId &&
        paymentMethodId &&
        previous &&
        Object.prototype.hasOwnProperty.call(
          previous,
          "default_payment_method",
        ) &&
        stripeObjectId(previous.default_payment_method) !== paymentMethodId
      ) {
        await handlePaymentMethodUpdated({
          customerId,
          subscriptionId: updated.id,
          paymentMethodId,
          stripeEventId: event.id,
          stripeEventType: "customer.subscription.updated",
          eventOccurredAtMs: stripeEventOccurredAtMs(event),
        });
      }
      await handleSubscriptionUpdated(
        event.data.object as Stripe.Subscription,
        event.data.previous_attributes as
          Partial<Stripe.Subscription> | undefined,
        stripeEventOccurredAtMs(event),
      );
      break;
    }
    case "customer.subscription.deleted": {
      await handleSubscriptionDeleted(
        event.data.object as Stripe.Subscription,
        event.id,
        stripeEventOccurredAtMs(event),
      );
      break;
    }
    case "customer.updated": {
      const updated = event.data.object as Stripe.Customer;
      const paymentMethodId = stripeObjectId(
        updated.invoice_settings?.default_payment_method,
      );
      if (
        paymentMethodId &&
        customerPaymentMethodChanged(
          event.data.previous_attributes as
            Partial<Stripe.Customer> | undefined,
          paymentMethodId,
        )
      ) {
        await handlePaymentMethodUpdated({
          customerId: updated.id,
          paymentMethodId,
          stripeEventId: event.id,
          stripeEventType: "customer.updated",
          eventOccurredAtMs: stripeEventOccurredAtMs(event),
        });
      }
      break;
    }
    case "refund.created":
    case "refund.updated": {
      await handleSubscriptionRefund(
        event.data.object as Stripe.Refund,
        event.id,
        event.type,
      );
      break;
    }
  }

  // Flush queued PostHog events after the response is sent. Webhook handlers
  // terminate quickly enough that buffered events would otherwise be dropped.
  after(() => phLogger.flush());

  // Mark as processed after successful handling
  try {
    await getConvexClient().mutation(api.extraUsage.checkAndMarkWebhook, {
      serviceKey: process.env.CONVEX_SERVICE_ROLE_KEY!,
      eventId: event.id,
    });
  } catch (error) {
    // Log but don't fail — the event was already handled successfully
    console.error(
      `[Subscription Webhook] Failed to mark event ${event.id} as processed:`,
      error,
    );
  }

  return NextResponse.json({ received: true });
}
