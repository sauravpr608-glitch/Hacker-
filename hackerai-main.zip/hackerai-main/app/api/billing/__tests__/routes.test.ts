import { describe, expect, it, jest, beforeEach } from "@jest/globals";
import { BILLING_ERRORS } from "@/lib/billing/billing-errors";

const mockRedirectToBillingPortal = jest.fn();
const mockOpenRenewalInvoice = jest.fn();
jest.mock("@/lib/actions/renewal-invoice", () => ({
  __esModule: true,
  default: mockOpenRenewalInvoice,
}));
const mockGetSubscriptionCancellationStatus = jest.fn();
const mockKeepSubscription = jest.fn();
const mockCancelSubscription = jest.fn();

jest.mock("@/lib/actions/billing-portal", () => ({
  __esModule: true,
  default: mockRedirectToBillingPortal,
}));

jest.mock("@/lib/actions/subscription-status", () => ({
  __esModule: true,
  default: mockGetSubscriptionCancellationStatus,
}));

jest.mock("@/lib/actions/keep-subscription", () => ({
  __esModule: true,
  default: mockKeepSubscription,
}));

jest.mock("@/lib/actions/cancel-subscription", () => ({
  __esModule: true,
  default: mockCancelSubscription,
}));

jest.mock("next/server", () => ({
  NextResponse: {
    json: (body: unknown, init?: ResponseInit) => ({
      status: init?.status ?? 200,
      json: async () => body,
    }),
  },
}));

function request(body: unknown) {
  return {
    json: async () => body,
  };
}

function unreadableJsonRequest() {
  return {
    json: async () => {
      throw new SyntaxError("Invalid JSON");
    },
  };
}

describe("billing API routes", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("returns a retryable conflict instead of reporting success for an overlapping keep", async () => {
    mockKeepSubscription.mockRejectedValue(
      new Error(BILLING_ERRORS.subscriptionChangeInProgress) as never,
    );
    const { POST } = await import("../keep/route");
    const response = await POST();
    expect(response.status).toBe(409);
    await expect(response.json()).resolves.toEqual({
      error: BILLING_ERRORS.subscriptionChangeInProgress,
    });
  });

  it("returns the server-selected invoice payment page", async () => {
    mockOpenRenewalInvoice.mockResolvedValue(
      "https://invoice.stripe.com/i/current" as never,
    );
    const { POST } = await import("../renewal-invoice/route");
    const response = await POST();
    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toEqual({
      url: "https://invoice.stripe.com/i/current",
    });
  });

  it.each([
    ["Only admins or owners can manage billing", 403],
    ["User not authenticated", 401],
    ["No payable renewal invoice found. Check your billing status.", 409],
  ])(
    "preserves invoice authorization and eligibility errors",
    async (message, status) => {
      mockOpenRenewalInvoice.mockRejectedValue(new Error(message) as never);
      const { POST } = await import("../renewal-invoice/route");
      expect((await POST()).status).toBe(status);
    },
  );

  it("accepts pricing as an authorized portal recovery surface", async () => {
    mockRedirectToBillingPortal.mockResolvedValue(
      "https://billing.stripe.com/session" as never,
    );
    const { POST } = await import("../portal/route");
    expect(
      (
        await POST(
          request({
            flow: "payment_method",
            surface: "pricing_dialog",
            returnPath: "/c/test",
          }) as never,
        )
      ).status,
    ).toBe(200);
    expect(mockRedirectToBillingPortal).toHaveBeenCalledWith("payment_method", {
      surface: "pricing_dialog",
      returnPath: "/c/test",
    });
  });

  it("returns a billing portal URL", async () => {
    mockRedirectToBillingPortal.mockResolvedValue(
      "https://billing.stripe.com/session" as never,
    );
    const { POST } = await import("../portal/route");

    const response = await POST(request(null) as never);

    await expect(response.json()).resolves.toEqual({
      url: "https://billing.stripe.com/session",
    });
    expect(response.status).toBe(200);
  });

  it("maps expected billing errors to JSON responses", async () => {
    mockRedirectToBillingPortal.mockRejectedValue(
      new Error("Only admins or owners can manage billing") as never,
    );
    const { POST } = await import("../portal/route");

    const response = await POST(request(null) as never);

    expect(response.status).toBe(403);
    await expect(response.json()).resolves.toEqual({
      error: "Only admins or owners can manage billing",
    });
  });

  it("passes payment method update mode to the billing portal action", async () => {
    mockRedirectToBillingPortal.mockResolvedValue(
      "https://billing.stripe.com/payment-method" as never,
    );
    const { POST } = await import("../portal/route");

    const response = await POST(request({ flow: "payment_method" }) as never);

    expect(response.status).toBe(200);
    expect(mockRedirectToBillingPortal).toHaveBeenCalledWith(
      "payment_method",
      {},
    );
  });

  it("rejects unsupported billing portal flows", async () => {
    const { POST } = await import("../portal/route");

    const response = await POST(request({ flow: "cancel" }) as never);

    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toEqual({
      error: "Invalid billing portal flow",
    });
    expect(mockRedirectToBillingPortal).not.toHaveBeenCalled();
  });

  it("returns subscription cancellation status", async () => {
    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: true,
      currentPeriodEnd: 1_782_444_800_000,
    } as never);
    const { GET } = await import("../subscription-status/route");

    const response = await GET();

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toEqual({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: true,
      currentPeriodEnd: 1_782_444_800_000,
    });
  });

  it("keeps a subscription through a stable POST endpoint", async () => {
    mockKeepSubscription.mockResolvedValue({
      kept: true,
      cancelAtPeriodEnd: false,
      alreadyKept: false,
    } as never);
    const { POST } = await import("../keep/route");

    const response = await POST();

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toEqual({
      kept: true,
      cancelAtPeriodEnd: false,
      alreadyKept: false,
    });
  });

  it("passes cancellation reason input to the cancellation action", async () => {
    mockCancelSubscription.mockResolvedValue({
      canceled: true,
      cancelAtPeriodEnd: true,
      alreadyScheduled: false,
    } as never);
    const { POST } = await import("../cancel/route");

    const response = await POST(
      request({
        cancellationReason: {
          reasonCategory: "too_expensive",
          reasonSubcategory: "too_expensive_low_frequency",
          reasonDetails: "Budget changed",
        },
      }) as never,
    );

    expect(response.status).toBe(200);
    expect(mockCancelSubscription).toHaveBeenCalledWith({
      cancellationReason: {
        reasonCategory: "too_expensive",
        reasonSubcategory: "too_expensive_low_frequency",
        reasonDetails: "Budget changed",
      },
    });
  });

  it("returns a validation error for malformed cancellation bodies", async () => {
    const { POST } = await import("../cancel/route");
    const malformedBodies = [
      null,
      {},
      { cancellationReason: null },
      { cancellationReason: [] },
    ];

    for (const body of malformedBodies) {
      const response = await POST(request(body) as never);

      expect(response.status).toBe(400);
      await expect(response.json()).resolves.toEqual({
        error: "Please select the main cancellation reason",
      });
    }

    const unreadableResponse = await POST(unreadableJsonRequest() as never);

    expect(unreadableResponse.status).toBe(400);
    await expect(unreadableResponse.json()).resolves.toEqual({
      error: "Please select the main cancellation reason",
    });
    expect(mockCancelSubscription).not.toHaveBeenCalled();
  });
});

describe("billing portal recovery options", () => {
  beforeEach(() => jest.clearAllMocks());
  it("forwards a blocked-chat return path", async () => {
    mockRedirectToBillingPortal.mockResolvedValue(
      "https://billing.stripe.com/test" as never,
    );
    const { POST } = await import("../portal/route");
    expect(
      (
        await POST(
          request({
            flow: "payment_method",
            surface: "blocked_chat",
            returnPath: "/c/test",
          }) as never,
        )
      ).status,
    ).toBe(200);
    expect(mockRedirectToBillingPortal).toHaveBeenCalledWith("payment_method", {
      surface: "blocked_chat",
      returnPath: "/c/test",
    });
  });
  it.each([
    { surface: "arbitrary" },
    { returnPath: "https://evil.example" },
    { returnPath: "//evil.example" },
    { returnPath: 123 },
    { returnPath: "/" + "a".repeat(401) },
  ])("rejects invalid options %j", async (body) => {
    const { POST } = await import("../portal/route");
    expect((await POST(request(body) as never)).status).toBe(400);
    expect(mockRedirectToBillingPortal).not.toHaveBeenCalled();
  });
});
