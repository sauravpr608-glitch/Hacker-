import { after, NextRequest, NextResponse } from "next/server";
import { stripe } from "../stripe";
import { workos } from "../workos";
import { getUserIDWithFreshLoginContext } from "@/lib/auth/get-user-id";
import { deleteUserRateLimitKeys } from "@/lib/rate-limit/token-bucket";
import { ChatSDKError } from "@/lib/errors";
import { getConvexClient } from "@/lib/db/convex-client";
import { api } from "@/convex/_generated/api";
import { logger } from "@/lib/logger";
import { phLogger } from "@/lib/posthog/server";
import { fenceAndGetActiveAgentResourcesForUser } from "@/lib/db/actions";
import { closeAndCancelAgentResources } from "@/lib/api/agent-deletion-cleanup";
import { cancelSubagentsForUserDeletion } from "@/lib/db/subagents";
import { terminateCloudSandboxesForUser } from "@/lib/ai/tools/utils/cloud-sandbox";
import { ACCOUNT_CLEANUP_IN_PROGRESS_CODE } from "@/lib/account-deletion";
import {
  acquireTeamInvitationLock,
  TeamInvitationLockUnavailableError,
  type TeamInvitationLock,
} from "@/lib/billing/team-invitation-lock";

type OrganizationMembership = Awaited<
  ReturnType<typeof workos.userManagement.listOrganizationMemberships>
>["data"][number];

type MembershipDeletionPlan = {
  membership: OrganizationMembership;
  deleteOrganization: boolean;
  blockReason?: string;
};

import { waitForDeletion } from "@/lib/utils/wait-for-deletion";

const MAX_CONVEX_ACCOUNT_CLEANUP_BATCHES = 50;
const MAX_CONVEX_ORGANIZATION_CLEANUP_BATCHES = 50;

type ConvexCleanupProgress = {
  deletedDocuments: number;
  anonymizedDocuments: number;
  s3ObjectsQueued: number;
};

type ParsedConvexCleanupResult = {
  hasMore: boolean;
  progress?: ConvexCleanupProgress;
};

function isMissingWorkosUserError(error: unknown, userId: string): boolean {
  return (
    error instanceof Error &&
    error.name === "NotFoundException" &&
    error.message === `User not found: '${userId}'.`
  );
}

async function deleteWorkosUserAfterOrganizationCleanup(
  userId: string,
  deletedOrganizationIds: Set<string>,
  requestId: string,
) {
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      await workos.userManagement.deleteUser(userId);
      return;
    } catch (error) {
      if (isMissingWorkosUserError(error, userId)) return;
      const missingOrganization =
        error instanceof Error && error.name === "NotFoundException"
          ? /^Organization not found: '([^']+)'\.$/.exec(error.message)?.[1]
          : undefined;
      // Retry only the provider consistency failure for an organization this
      // request already deleted. Unrelated 404s must remain failures.
      if (
        !missingOrganization ||
        !deletedOrganizationIds.has(missingOrganization)
      )
        throw error;
      try {
        await workos.userManagement.getUser(userId);
      } catch (readError) {
        if (isMissingWorkosUserError(readError, userId)) return;
        throw readError;
      }
      logger.warn("account_identity_deletion_recovery", {
        user_id: userId,
        request_id: requestId,
        organization_id: missingOrganization,
        attempt,
        user_still_exists: true,
        reason:
          attempt === 3
            ? "reconciliation_required"
            : "organization_propagation",
      });
      if (attempt === 3) {
        throw new Error(
          "Account deletion needs identity-provider reconciliation. Please contact support so we can finish deleting your account.",
          { cause: error },
        );
      }
      await new Promise((resolve) => setTimeout(resolve, attempt * 1000));
    }
  }
}

function sumCleanupCounts(value: unknown): number | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return undefined;
  }

  let total = 0;
  for (const count of Object.values(value)) {
    if (typeof count !== "number" || !Number.isFinite(count) || count < 0) {
      return undefined;
    }
    total += count;
  }
  return total;
}

function parseConvexCleanupResult(result: unknown): ParsedConvexCleanupResult {
  if (
    result &&
    typeof result === "object" &&
    typeof (result as { hasMore?: unknown }).hasMore === "boolean"
  ) {
    const cleanupResult = result as Record<string, unknown> & {
      hasMore: boolean;
    };
    const deletedDocuments = sumCleanupCounts(cleanupResult.deleted);
    const anonymizedDocuments = sumCleanupCounts(cleanupResult.anonymized);
    const s3ObjectsQueued = cleanupResult.s3ObjectsQueued;
    const progress =
      deletedDocuments !== undefined &&
      anonymizedDocuments !== undefined &&
      typeof s3ObjectsQueued === "number" &&
      Number.isFinite(s3ObjectsQueued) &&
      s3ObjectsQueued >= 0
        ? { deletedDocuments, anonymizedDocuments, s3ObjectsQueued }
        : undefined;

    return { hasMore: cleanupResult.hasMore, progress };
  }

  throw new Error(
    "Account cleanup returned an unexpected response. Please contact support so we can finish deleting this account.",
  );
}

async function removeMembership(membership: OrganizationMembership) {
  await workos.userManagement.deleteOrganizationMembership(membership.id);
}

async function getMembershipDeletionPlan(
  membership: OrganizationMembership,
): Promise<MembershipDeletionPlan> {
  try {
    // Read invitations first. If one is accepted between these two reads, it
    // remains represented either as pending here or as active below. The
    // shared organization lock prevents a new invitation from being sent
    // after this snapshot begins.
    const invitationsPage = await workos.userManagement.listInvitations({
      organizationId: membership.organizationId,
      limit: 100,
    });
    const activeMembershipsPage =
      await workos.userManagement.listOrganizationMemberships({
        organizationId: membership.organizationId,
        statuses: ["active"],
        limit: 100,
      });
    const hasPendingInvitation = invitationsPage.data.some(
      (invitation) => invitation.state === "pending",
    );
    const activeMemberships = activeMembershipsPage.data;
    const activeCallerMembership = activeMemberships.find(
      (activeMembership) => activeMembership.id === membership.id,
    );
    const isSoleActiveMember =
      activeMemberships.length === 1 &&
      activeCallerMembership?.id === membership.id;
    const isAdmin =
      membership.role?.slug === "admin" ||
      activeCallerMembership?.role?.slug === "admin";
    const activeAdminCount = activeMemberships.filter(
      (activeMembership) => activeMembership.role?.slug === "admin",
    ).length;

    if (
      isAdmin &&
      activeAdminCount <= 1 &&
      (!isSoleActiveMember || hasPendingInvitation)
    ) {
      return {
        membership,
        deleteOrganization: false,
        blockReason:
          "Cannot delete account while you are the last admin of a shared organization. Promote another admin or leave the team first.",
      };
    }

    return {
      membership,
      deleteOrganization:
        isSoleActiveMember && isAdmin && !hasPendingInvitation,
    };
  } catch (e) {
    throw new Error(
      "Could not verify organization membership. Please try again.",
      { cause: e },
    );
  }
}

function getConvexServiceKey(): string {
  const serviceKey = process.env.CONVEX_SERVICE_ROLE_KEY;
  if (!serviceKey) {
    throw new Error("CONVEX_SERVICE_ROLE_KEY is not set");
  }
  return serviceKey;
}

async function markAccountIdentityDeleted(
  userId: string,
  freeQuotaSubject: string | undefined,
  serviceKey: string,
) {
  if (!freeQuotaSubject) return;

  await getConvexClient().mutation(api.accountIdentities.markDeleted, {
    serviceKey,
    identityHash: freeQuotaSubject,
    userId,
  });
}

async function deleteConvexUserData(
  userId: string,
  serviceKey: string,
  requestId: string,
  preservedOrganizationIds: string[],
  assertMembershipLocksOwned: () => Promise<void>,
): Promise<boolean> {
  const convex = getConvexClient();
  let progressStatsBatches = 0;
  let batchesWithProgress = 0;
  let deletedDocuments = 0;
  let anonymizedDocuments = 0;
  let s3ObjectsQueued = 0;
  let lastProgress: ConvexCleanupProgress | undefined;

  for (let batch = 0; batch < MAX_CONVEX_ACCOUNT_CLEANUP_BATCHES; batch++) {
    await assertMembershipLocksOwned();
    const result = await convex.mutation(
      api.userDeletion.deleteAllUserDataByService,
      {
        serviceKey,
        userId,
        preservedOrganizationIds,
      },
    );

    const parsedResult = parseConvexCleanupResult(result);
    if (parsedResult.progress) {
      progressStatsBatches += 1;
      deletedDocuments += parsedResult.progress.deletedDocuments;
      anonymizedDocuments += parsedResult.progress.anonymizedDocuments;
      s3ObjectsQueued += parsedResult.progress.s3ObjectsQueued;
      if (
        parsedResult.progress.deletedDocuments > 0 ||
        parsedResult.progress.anonymizedDocuments > 0
      ) {
        batchesWithProgress += 1;
      }
      lastProgress = parsedResult.progress;
    }

    if (!parsedResult.hasMore) {
      await waitForDeletion(
        () =>
          convex.query(api.deletions.getStatusForBackend, {
            serviceKey,
            userId,
          }),
        20_000,
      );
      return true;
    }
  }

  logger.warn("account_cleanup_continuation_required", {
    event: "account_cleanup_continuation_required",
    service: "hackerai-web",
    environment: process.env.VERCEL_ENV ?? process.env.NODE_ENV,
    request_id: requestId,
    user_id: userId,
    reason: "cleanup_batch_limit_exhausted",
    batch_limit: MAX_CONVEX_ACCOUNT_CLEANUP_BATCHES,
    progress_stats_batches: progressStatsBatches,
    batches_with_progress: batchesWithProgress,
    deleted_documents: deletedDocuments,
    anonymized_documents: anonymizedDocuments,
    s3_objects_queued: s3ObjectsQueued,
    last_batch_deleted_documents: lastProgress?.deletedDocuments,
    last_batch_anonymized_documents: lastProgress?.anonymizedDocuments,
    last_batch_s3_objects_queued: lastProgress?.s3ObjectsQueued,
  });

  return false;
}

async function deleteDeletedOrganizationPauseRows(
  organizationId: string,
  serviceKey: string,
  assertMembershipLocksOwned: () => Promise<void>,
) {
  for (
    let batch = 0;
    batch < MAX_CONVEX_ORGANIZATION_CLEANUP_BATCHES;
    batch++
  ) {
    await assertMembershipLocksOwned();
    const result = await getConvexClient().mutation(
      api.subscriptionPauses.deleteForDeletedOrganization,
      { serviceKey, organizationId },
    );
    if (!result.hasMore) return;
  }

  throw new Error(
    "Organization cleanup exceeded its safety bound. Please retry account deletion.",
  );
}

export const POST = async (req: NextRequest) => {
  let stage = "authenticate";
  let userIdForLog: string | undefined;
  let membershipCount: number | undefined;
  let freeQuotaSubjectPresent: boolean | undefined;
  const requestId = req.headers.get("x-vercel-id") ?? "unknown";
  const membershipLocks: TeamInvitationLock[] = [];
  const deletedOrganizationIds = new Set<string>();

  const assertMembershipLocksOwned = async () => {
    for (const lock of membershipLocks) {
      await lock.assertOwned();
    }
  };

  try {
    // Enforce recent login (10-minute window) before any destructive action
    const { userId, freeQuotaSubject } =
      await getUserIDWithFreshLoginContext(req);
    userIdForLog = userId;
    freeQuotaSubjectPresent = Boolean(freeQuotaSubject);

    // List all org memberships for this user
    // NOTE: Pagination not required - users can only have one organization (max 2 if something goes wrong)
    stage = "list_memberships";
    const memberships = await workos.userManagement.listOrganizationMemberships(
      {
        userId,
      },
    );
    membershipCount = memberships.data.length;

    stage = "coordinate_membership_deletions";
    const organizationIds = [
      ...new Set(
        memberships.data.map((membership) => membership.organizationId),
      ),
    ].sort();
    for (const organizationId of organizationIds) {
      const lock = await acquireTeamInvitationLock(organizationId);
      if (!lock) {
        return NextResponse.json(
          { code: ACCOUNT_CLEANUP_IN_PROGRESS_CODE },
          { status: 409 },
        );
      }
      membershipLocks.push(lock);
    }

    stage = "plan_membership_deletions";
    const membershipDeletionPlans = await Promise.all(
      memberships.data.map(getMembershipDeletionPlan),
    );
    const blockedPlan = membershipDeletionPlans.find(
      (plan) => plan.blockReason,
    );

    if (blockedPlan?.blockReason) {
      return NextResponse.json(
        { error: blockedPlan.blockReason },
        { status: 400 },
      );
    }
    // Keep all organization-owned pause rows until the organization has been
    // deleted. This makes cleanup continuation safe even if team membership
    // changes between requests; solo-organization rows are purged below while
    // the same membership snapshot and lock are still authoritative.
    const preservedOrganizationIds = membershipDeletionPlans.map(
      (plan) => plan.membership.organizationId,
    );

    const serviceKey = getConvexServiceKey();
    stage = "begin_user_data_deletion";
    await assertMembershipLocksOwned();
    const deletionFenceStarted = await getConvexClient().mutation(
      api.userDeletion.beginUserDataDeletionByService,
      {
        serviceKey,
        userId,
      },
    );
    // A resume that has already crossed its Stripe side-effect barrier must
    // finish before deletion can safely own the account. Older deployments
    // returned null, so only an explicit false is treated as contention.
    if (deletionFenceStarted === false) {
      return NextResponse.json(
        { code: ACCOUNT_CLEANUP_IN_PROGRESS_CODE },
        { status: 409 },
      );
    }
    stage = "mark_account_identity_deleted";
    await markAccountIdentityDeleted(userId, freeQuotaSubject, serviceKey);

    stage = "fence_active_agent_resources";
    const activeAgentResources = await fenceAndGetActiveAgentResourcesForUser({
      userId,
    });
    if (activeAgentResources.hasMore) {
      throw new Error(
        "Too many active agent resources to delete safely. Please stop active Agent runs and retry.",
      );
    }

    stage = "close_active_agent_resources";
    const childCancellation = await cancelSubagentsForUserDeletion(
      userId,
      "account_deleted",
    );
    if (childCancellation.hasMore) {
      throw new Error(
        "Too many validation runs to delete safely. Please stop active validation runs and retry.",
      );
    }
    await closeAndCancelAgentResources(
      [
        ...activeAgentResources.resources,
        ...childCancellation.triggerRunIds.map((triggerRunId) => ({
          chatId: "subagent",
          triggerRunId,
        })),
      ],
      "account-deleted",
    );

    stage = "terminate_cloud_sandboxes";
    // Keep below-threshold lifecycle events on both success and failure paths.
    after(() => phLogger.flush());
    await terminateCloudSandboxesForUser(userId, { permanent: true });

    // Own app-data cleanup on the server so account deletion does not depend
    // on the browser successfully running a Convex mutation before this route.
    stage = "delete_convex_user_data";
    const cleanupComplete = await deleteConvexUserData(
      userId,
      serviceKey,
      requestId,
      preservedOrganizationIds,
      assertMembershipLocksOwned,
    );
    if (!cleanupComplete) {
      return NextResponse.json(
        { code: ACCOUNT_CLEANUP_IN_PROGRESS_CODE },
        { status: 409 },
      );
    }

    // Process each organization from memberships. Only delete org-level billing
    // and identity resources after proving this user is the sole active admin.
    stage = "delete_memberships_and_organizations";
    await assertMembershipLocksOwned();
    const organizationResults = await Promise.allSettled(
      membershipDeletionPlans.map(
        async ({ membership, deleteOrganization }) => {
          const orgId = membership.organizationId;

          if (!deleteOrganization) {
            await removeMembership(membership);
            return;
          }

          // Confirm owned billing and identity deletion before reporting success.
          const org = await workos.organizations.getOrganization(orgId);
          const stripeCustomerId = org.stripeCustomerId;
          if (stripeCustomerId) {
            // Deleting a customer can precede a failed org deletion. Retrieval
            // distinguishes that completed stage when the user retries.
            const customer = await stripe.customers.retrieve(stripeCustomerId);
            if (!customer.deleted) {
              const subs = await stripe.subscriptions.list({
                customer: stripeCustomerId,
                status: "all",
                limit: 100,
              });
              for (const sub of subs.data) {
                if (
                  sub.status === "canceled" ||
                  sub.status === "incomplete_expired"
                )
                  continue;
                await stripe.subscriptions.cancel(sub.id);
              }
              await stripe.customers.del(stripeCustomerId);
            }
          }

          await deleteDeletedOrganizationPauseRows(
            orgId,
            serviceKey,
            assertMembershipLocksOwned,
          );

          await workos.organizations.deleteOrganization(orgId);
          deletedOrganizationIds.add(orgId);
        },
      ),
    );

    // Keep membership locks held until every concurrent cleanup has stopped.
    const organizationFailure = organizationResults.find(
      (result) => result.status === "rejected",
    );
    if (organizationFailure?.status === "rejected") {
      throw organizationFailure.reason;
    }

    // Purge Redis rate-limit keys. Best-effort: WorkOS user deletion proceeds
    // even if this fails so the account is not left in a half-deleted state.
    stage = "delete_rate_limit_keys";
    await deleteUserRateLimitKeys(userId, freeQuotaSubject).catch((err) => {
      console.warn(
        "Failed to clear Redis rate-limit keys during account deletion:",
        err,
      );
    });

    // Finally, delete the WorkOS user
    stage = "delete_workos_user";
    await deleteWorkosUserAfterOrganizationCleanup(
      userId,
      deletedOrganizationIds,
      requestId,
    );

    return NextResponse.json({ ok: true });
  } catch (error) {
    if (error instanceof TeamInvitationLockUnavailableError) {
      return NextResponse.json(
        { error: "Account deletion coordination is temporarily unavailable" },
        { status: 503 },
      );
    }
    if (error instanceof ChatSDKError) {
      return error.toResponse();
    }
    const message =
      error && typeof error === "object" && "message" in (error as any)
        ? (error as any).message
        : "Failed to delete account";
    const errorName = error instanceof Error ? error.name : "UnknownError";
    logger.error(
      "account_deletion_failed",
      error instanceof Error ? error : undefined,
      {
        event: "account_deletion_failed",
        service: "hackerai-web",
        environment: process.env.VERCEL_ENV ?? process.env.NODE_ENV,
        request_id: requestId,
        stage,
        user_id: userIdForLog,
        membership_count: membershipCount,
        free_quota_subject_present: freeQuotaSubjectPresent,
        error_name: errorName,
        error_message: message,
      },
    );
    return NextResponse.json({ error: message }, { status: 500 });
  } finally {
    for (const lock of membershipLocks.reverse()) {
      try {
        await lock.release();
      } catch (error) {
        logger.warn("account_deletion_membership_lock_release_failed", {
          event: "account_deletion_membership_lock_release_failed",
          service: "hackerai-web",
          environment: process.env.VERCEL_ENV ?? process.env.NODE_ENV,
          request_id: requestId,
          user_id: userIdForLog,
          error_name: error instanceof Error ? error.name : "UnknownError",
        });
      }
    }
  }
};
