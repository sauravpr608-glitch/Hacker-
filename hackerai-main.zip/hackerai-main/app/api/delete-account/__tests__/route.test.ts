import { after } from "next/server";
import { phLogger } from "@/lib/posthog/server";
import { POST } from "../route";
import { getUserIDWithFreshLoginContext } from "@/lib/auth/get-user-id";
import { deleteUserRateLimitKeys } from "@/lib/rate-limit/token-bucket";
import { stripe } from "../../stripe";
import { workos } from "../../workos";
import { fenceAndGetActiveAgentResourcesForUser } from "@/lib/db/actions";
import { closeAndCancelAgentResources } from "@/lib/api/agent-deletion-cleanup";
import { cancelSubagentsForUserDeletion } from "@/lib/db/subagents";
import { terminateCloudSandboxesForUser } from "@/lib/ai/tools/utils/cloud-sandbox";
import { logger } from "@/lib/logger";
import { acquireTeamInvitationLock } from "@/lib/billing/team-invitation-lock";

const mockConvexMutation = jest.fn();
const mockMembershipLockAssertOwned = jest.fn();
const mockMembershipLockRelease = jest.fn();
const mockConvexQuery = jest.fn().mockResolvedValue("complete");

jest.mock("next/server", () => ({
  after: jest.fn(),
  NextResponse: {
    json: jest.fn((body: unknown, init?: { status?: number }) => ({
      status: init?.status ?? 200,
      json: async () => body,
    })),
  },
}));

jest.mock("@/lib/auth/get-user-id", () => ({
  getUserIDWithFreshLoginContext: jest.fn(),
}));

jest.mock("@/lib/rate-limit/token-bucket", () => ({
  deleteUserRateLimitKeys: jest.fn(),
}));

jest.mock("@/lib/db/convex-client", () => ({
  getConvexClient: jest.fn(() => ({
    mutation: mockConvexMutation,
    query: mockConvexQuery,
  })),
}));

jest.mock("@/lib/db/actions", () => ({
  fenceAndGetActiveAgentResourcesForUser: jest.fn(),
}));

jest.mock("@/lib/api/agent-deletion-cleanup", () => ({
  closeAndCancelAgentResources: jest.fn(),
}));

jest.mock("@/lib/db/subagents", () => ({
  cancelSubagentsForUserDeletion: jest.fn(),
}));

jest.mock("@/lib/ai/tools/utils/cloud-sandbox", () => ({
  terminateCloudSandboxesForUser: jest.fn(),
}));

jest.mock("@/lib/logger", () => ({
  logger: {
    error: jest.fn(),
    info: jest.fn(),
    warn: jest.fn(),
  },
}));

jest.mock("@/lib/billing/team-invitation-lock", () => ({
  acquireTeamInvitationLock: jest.fn(),
  TeamInvitationLockUnavailableError: class extends Error {},
}));

jest.mock("@/convex/_generated/api", () => ({
  api: {
    deletions: { getStatusForBackend: "deletions.getStatusForBackend" },
    accountIdentities: {
      markDeleted: "accountIdentities.markDeleted",
    },
    userDeletion: {
      beginUserDataDeletionByService:
        "userDeletion.beginUserDataDeletionByService",
      deleteAllUserDataByService: "userDeletion.deleteAllUserDataByService",
    },
    subscriptionPauses: {
      deleteForDeletedOrganization:
        "subscriptionPauses.deleteForDeletedOrganization",
    },
  },
}));

jest.mock("../../stripe", () => ({
  stripe: {
    subscriptions: {
      list: jest.fn(),
      cancel: jest.fn(),
    },
    customers: {
      retrieve: jest.fn().mockResolvedValue({ deleted: false }),
      del: jest.fn(),
    },
  },
}));

jest.mock("../../workos", () => ({
  workos: {
    userManagement: {
      listOrganizationMemberships: jest.fn(),
      listInvitations: jest.fn(),
      deleteOrganizationMembership: jest.fn(),
      deleteUser: jest.fn(),
      getUser: jest.fn(),
    },
    organizations: {
      getOrganization: jest.fn(),
      deleteOrganization: jest.fn(),
    },
  },
}));

jest.mock("@/lib/posthog/server", () => ({
  phLogger: { flush: jest.fn().mockResolvedValue(undefined) },
}));

const mockGetUserIDWithFreshLoginContext =
  getUserIDWithFreshLoginContext as jest.MockedFunction<
    typeof getUserIDWithFreshLoginContext
  >;
const mockDeleteUserRateLimitKeys =
  deleteUserRateLimitKeys as jest.MockedFunction<
    typeof deleteUserRateLimitKeys
  >;
const mockListOrganizationMemberships = workos.userManagement
  .listOrganizationMemberships as jest.MockedFunction<
  typeof workos.userManagement.listOrganizationMemberships
>;
const mockListInvitations = workos.userManagement
  .listInvitations as jest.MockedFunction<
  typeof workos.userManagement.listInvitations
>;
const mockAcquireTeamInvitationLock =
  acquireTeamInvitationLock as jest.MockedFunction<
    typeof acquireTeamInvitationLock
  >;
const mockDeleteOrganizationMembership = workos.userManagement
  .deleteOrganizationMembership as jest.MockedFunction<
  typeof workos.userManagement.deleteOrganizationMembership
>;
const mockDeleteUser = workos.userManagement.deleteUser as jest.MockedFunction<
  typeof workos.userManagement.deleteUser
>;
const mockGetOrganization = workos.organizations
  .getOrganization as jest.MockedFunction<
  typeof workos.organizations.getOrganization
>;
const mockDeleteOrganization = workos.organizations
  .deleteOrganization as jest.MockedFunction<
  typeof workos.organizations.deleteOrganization
>;
const mockListSubscriptions = stripe.subscriptions.list as jest.MockedFunction<
  typeof stripe.subscriptions.list
>;
const mockCancelSubscription = stripe.subscriptions
  .cancel as jest.MockedFunction<typeof stripe.subscriptions.cancel>;
const mockDeleteCustomer = stripe.customers.del as jest.MockedFunction<
  typeof stripe.customers.del
>;
const mockFenceAndGetActiveAgentResourcesForUser =
  fenceAndGetActiveAgentResourcesForUser as jest.MockedFunction<
    typeof fenceAndGetActiveAgentResourcesForUser
  >;
const mockCloseAndCancelAgentResources =
  closeAndCancelAgentResources as jest.MockedFunction<
    typeof closeAndCancelAgentResources
  >;
const mockCancelSubagentsForUserDeletion =
  cancelSubagentsForUserDeletion as jest.MockedFunction<
    typeof cancelSubagentsForUserDeletion
  >;
const mockTerminateCloudSandboxesForUser =
  terminateCloudSandboxesForUser as jest.MockedFunction<
    typeof terminateCloudSandboxesForUser
  >;
const mockLoggerError = logger.error as jest.MockedFunction<
  typeof logger.error
>;
const mockLoggerWarn = logger.warn as jest.MockedFunction<typeof logger.warn>;

const request = () => ({
  url: "https://hackerai.test/api/delete-account",
  headers: {
    get: (name: string) =>
      name === "x-vercel-id" ? "iad1::opaque-request" : null,
  },
});

describe("POST /api/delete-account", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    process.env.CONVEX_SERVICE_ROLE_KEY = "service_key";
    mockGetUserIDWithFreshLoginContext.mockResolvedValue({
      userId: "user_123",
      freeQuotaSubject: "free_quota:v1:identity_hash",
    });
    mockDeleteUserRateLimitKeys.mockResolvedValue(undefined);
    mockListInvitations.mockResolvedValue({ data: [] } as never);
    mockMembershipLockAssertOwned.mockResolvedValue(undefined);
    mockMembershipLockRelease.mockResolvedValue(undefined);
    mockAcquireTeamInvitationLock.mockResolvedValue({
      assertOwned: mockMembershipLockAssertOwned,
      release: mockMembershipLockRelease,
    });
    mockFenceAndGetActiveAgentResourcesForUser.mockResolvedValue({
      resources: [],
      hasMore: false,
    } as never);
    mockCloseAndCancelAgentResources.mockResolvedValue({
      canceledTriggerRuns: 0,
      closedApprovalSessions: 0,
    } as never);
    mockCancelSubagentsForUserDeletion.mockResolvedValue({
      triggerRunIds: [],
      hasMore: false,
    } as never);
    mockTerminateCloudSandboxesForUser.mockResolvedValue({
      total: 0,
      killed: 0,
      alreadyGone: 0,
    });
    mockConvexMutation.mockImplementation(async (functionReference) => {
      if (functionReference === "userDeletion.deleteAllUserDataByService") {
        return { hasMore: false };
      }
      if (
        functionReference === "subscriptionPauses.deleteForDeletedOrganization"
      ) {
        return { deletedCount: 0, hasMore: false };
      }
      return null;
    });
    mockDeleteOrganizationMembership.mockResolvedValue(undefined as never);
    mockDeleteUser.mockResolvedValue(undefined as never);
    mockDeleteOrganization.mockResolvedValue(undefined as never);
    mockCancelSubscription.mockResolvedValue({} as never);
    mockDeleteCustomer.mockResolvedValue({} as never);
  });

  it.each([false, true])(
    "flushes buffered diagnostics after the response when cleanup fails=%s",
    async (fails) => {
      mockListOrganizationMemberships.mockResolvedValue({ data: [] } as never);
      if (fails)
        mockTerminateCloudSandboxesForUser.mockRejectedValueOnce(
          new Error("cleanup failed"),
        );
      const response = await POST(request() as any);
      expect(response.status).toBe(fails ? 500 : 200);
      expect(after).toHaveBeenCalledTimes(1);
      expect(phLogger.flush).not.toHaveBeenCalled();
      const task = jest.mocked(after).mock.calls[0][0] as () => Promise<void>;
      let finishFlush!: () => void;
      const flush = new Promise<void>((resolve) => {
        finishFlush = resolve;
      });
      jest.mocked(phLogger.flush).mockReturnValueOnce(flush);
      expect(task()).toBe(flush);
      expect(phLogger.flush).toHaveBeenCalledTimes(1);
      finishFlush();
      await flush;
    },
  );

  it("removes only the caller's membership for shared organizations", async () => {
    mockCancelSubagentsForUserDeletion.mockResolvedValue({
      triggerRunIds: ["child-run-1"],
      hasMore: false,
    } as never);
    const callerMembership = {
      id: "membership_user",
      organizationId: "org_team",
      userId: "user_123",
      role: { slug: "member" },
    };

    mockListOrganizationMemberships
      .mockResolvedValueOnce({ data: [callerMembership] } as never)
      .mockResolvedValueOnce({
        data: [
          callerMembership,
          {
            id: "membership_admin",
            organizationId: "org_team",
            userId: "user_admin",
            role: { slug: "admin" },
          },
        ],
      } as never);

    const response = await POST(request() as any);

    expect(response.status).toBe(200);
    expect(mockConvexMutation).toHaveBeenCalledWith(
      "accountIdentities.markDeleted",
      {
        serviceKey: "service_key",
        identityHash: "free_quota:v1:identity_hash",
        userId: "user_123",
      },
    );
    expect(mockConvexMutation).toHaveBeenCalledWith(
      "userDeletion.deleteAllUserDataByService",
      {
        serviceKey: "service_key",
        userId: "user_123",
        preservedOrganizationIds: ["org_team"],
      },
    );
    expect(mockDeleteOrganizationMembership).toHaveBeenCalledWith(
      "membership_user",
    );
    expect(mockGetOrganization).not.toHaveBeenCalled();
    expect(mockListSubscriptions).not.toHaveBeenCalled();
    expect(mockCancelSubscription).not.toHaveBeenCalled();
    expect(mockDeleteCustomer).not.toHaveBeenCalled();
    expect(mockDeleteOrganization).not.toHaveBeenCalled();
    expect(mockDeleteUser).toHaveBeenCalledWith("user_123");
    expect(mockTerminateCloudSandboxesForUser).toHaveBeenCalledWith(
      "user_123",
      { permanent: true },
    );
    expect(mockCloseAndCancelAgentResources).toHaveBeenCalledWith(
      [{ chatId: "subagent", triggerRunId: "child-run-1" }],
      "account-deleted",
    );
    expect(mockConvexMutation.mock.invocationCallOrder[0]).toBeLessThan(
      mockFenceAndGetActiveAgentResourcesForUser.mock.invocationCallOrder[0],
    );
    expect(
      mockFenceAndGetActiveAgentResourcesForUser.mock.invocationCallOrder[0],
    ).toBeLessThan(
      mockCancelSubagentsForUserDeletion.mock.invocationCallOrder[0],
    );
    expect(
      mockCancelSubagentsForUserDeletion.mock.invocationCallOrder[0],
    ).toBeLessThan(
      mockCloseAndCancelAgentResources.mock.invocationCallOrder[0],
    );
    expect(
      mockCloseAndCancelAgentResources.mock.invocationCallOrder[0],
    ).toBeLessThan(
      mockTerminateCloudSandboxesForUser.mock.invocationCallOrder[0],
    );
    expect(
      mockTerminateCloudSandboxesForUser.mock.invocationCallOrder[0],
    ).toBeLessThan(mockConvexMutation.mock.invocationCallOrder[2]);
    expect(mockConvexMutation.mock.invocationCallOrder[2]).toBeLessThan(
      mockDeleteOrganizationMembership.mock.invocationCallOrder[0],
    );
    expect(mockConvexMutation.mock.invocationCallOrder[2]).toBeLessThan(
      mockDeleteUser.mock.invocationCallOrder[0],
    );
    expect(mockDeleteUserRateLimitKeys).toHaveBeenCalledWith(
      "user_123",
      "free_quota:v1:identity_hash",
    );
  });

  it("deletes billing and organization resources for a solo admin organization", async () => {
    const callerMembership = {
      id: "membership_user",
      organizationId: "org_solo",
      userId: "user_123",
      role: { slug: "admin" },
    };

    mockListOrganizationMemberships
      .mockResolvedValueOnce({ data: [callerMembership] } as never)
      .mockResolvedValueOnce({ data: [callerMembership] } as never);
    mockGetOrganization.mockResolvedValue({
      id: "org_solo",
      stripeCustomerId: "cus_123",
    } as never);
    mockListSubscriptions.mockResolvedValue({
      data: [{ id: "sub_1" }, { id: "sub_2" }],
    } as never);

    const response = await POST(request() as any);

    expect(response.status).toBe(200);
    expect(mockConvexMutation).toHaveBeenCalledWith(
      "accountIdentities.markDeleted",
      {
        serviceKey: "service_key",
        identityHash: "free_quota:v1:identity_hash",
        userId: "user_123",
      },
    );
    expect(mockConvexMutation).toHaveBeenCalledWith(
      "userDeletion.deleteAllUserDataByService",
      {
        serviceKey: "service_key",
        userId: "user_123",
        preservedOrganizationIds: ["org_solo"],
      },
    );
    expect(mockListSubscriptions).toHaveBeenCalledWith({
      customer: "cus_123",
      status: "all",
      limit: 100,
    });
    expect(mockCancelSubscription).toHaveBeenCalledWith("sub_1");
    expect(mockCancelSubscription).toHaveBeenCalledWith("sub_2");
    expect(mockDeleteCustomer).toHaveBeenCalledWith("cus_123");
    expect(mockConvexMutation).toHaveBeenCalledWith(
      "subscriptionPauses.deleteForDeletedOrganization",
      {
        serviceKey: "service_key",
        organizationId: "org_solo",
      },
    );
    expect(mockDeleteOrganization).toHaveBeenCalledWith("org_solo");
    expect(mockDeleteOrganizationMembership).not.toHaveBeenCalled();
    expect(mockDeleteUser).toHaveBeenCalledWith("user_123");
    expect(mockAcquireTeamInvitationLock).toHaveBeenCalledWith("org_solo");
    expect(mockMembershipLockRelease).toHaveBeenCalledTimes(1);
  });

  it("blocks a solo-admin deletion while an invitation can become active", async () => {
    const callerMembership = {
      id: "membership_user",
      organizationId: "org_solo",
      userId: "user_123",
      role: { slug: "admin" },
    };

    mockListOrganizationMemberships
      .mockResolvedValueOnce({ data: [callerMembership] } as never)
      .mockResolvedValueOnce({ data: [callerMembership] } as never);
    mockListInvitations.mockResolvedValueOnce({
      data: [{ id: "invitation_1", state: "pending" }],
    } as never);

    const response = await POST(request() as any);
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toContain("last admin");
    expect(mockListInvitations.mock.invocationCallOrder[0]).toBeLessThan(
      mockListOrganizationMemberships.mock.invocationCallOrder[1],
    );
    expect(mockConvexMutation).not.toHaveBeenCalled();
    expect(mockDeleteOrganization).not.toHaveBeenCalled();
    expect(mockMembershipLockRelease).toHaveBeenCalledTimes(1);
  });

  it("retries when an invitation mutation owns the organization lock", async () => {
    const callerMembership = {
      id: "membership_user",
      organizationId: "org_solo",
      userId: "user_123",
      role: { slug: "admin" },
    };
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [callerMembership],
    } as never);
    mockAcquireTeamInvitationLock.mockResolvedValueOnce(null);

    const response = await POST(request() as any);

    expect(response.status).toBe(409);
    await expect(response.json()).resolves.toEqual({
      code: "account_cleanup_in_progress",
    });
    expect(mockListInvitations).not.toHaveBeenCalled();
    expect(mockConvexMutation).not.toHaveBeenCalled();
  });

  it("retries before identity cleanup while a billing resume is authorized", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    mockConvexMutation.mockResolvedValueOnce(false);

    const response = await POST(request() as any);

    expect(response.status).toBe(409);
    await expect(response.json()).resolves.toEqual({
      code: "account_cleanup_in_progress",
    });
    expect(mockConvexMutation).toHaveBeenCalledTimes(1);
    expect(mockDeleteUser).not.toHaveBeenCalled();
  });

  it("stops before cleanup when organization ownership cannot be verified", async () => {
    const membership = {
      id: "membership_user",
      organizationId: "org_solo",
      userId: "user_123",
      role: { slug: "admin" },
    };
    mockListOrganizationMemberships
      .mockResolvedValueOnce({ data: [membership] } as never)
      .mockRejectedValueOnce(new Error("Provider unavailable") as never);
    const response = await POST(request() as any);
    expect(response.status).toBe(500);
    expect(mockConvexMutation).not.toHaveBeenCalled();
    expect(mockDeleteUser).not.toHaveBeenCalled();
  });

  it("does not remove identity before pending attachment cleanup is confirmed", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    mockConvexQuery.mockResolvedValueOnce("failed");
    const response = await POST(request() as any);
    expect(response.status).toBe(500);
    expect(mockDeleteUser).not.toHaveBeenCalled();
  });

  it.each(["customer", "organization", "subscription"])(
    "does not claim success when %s cleanup fails",
    async (stage) => {
      const membership = {
        id: "membership_user",
        organizationId: "org_solo",
        userId: "user_123",
        role: { slug: "admin" },
      };
      mockListOrganizationMemberships
        .mockResolvedValueOnce({ data: [membership] } as never)
        .mockResolvedValueOnce({ data: [membership] } as never);
      mockGetOrganization.mockResolvedValue({
        id: "org_solo",
        stripeCustomerId: "cus_123",
      } as never);
      mockListSubscriptions.mockResolvedValue({
        data: [{ id: "sub_1", status: "active" }],
      } as never);
      const failed =
        stage === "customer"
          ? mockDeleteCustomer
          : stage === "organization"
            ? mockDeleteOrganization
            : mockCancelSubscription;
      failed.mockRejectedValueOnce(new Error("Provider unavailable") as never);
      const response = await POST(request() as any);
      expect(response.status).toBe(500);
      expect(mockDeleteUser).not.toHaveBeenCalled();
    },
  );

  it("holds all organization locks until concurrent cleanup settles after a failure", async () => {
    const memberships = ["a", "b"].map((id) => ({
      id: `membership_${id}`,
      organizationId: `org_${id}`,
      userId: "user_123",
      role: { slug: "member" },
    }));
    mockListOrganizationMemberships
      .mockResolvedValueOnce({ data: memberships } as never)
      .mockResolvedValueOnce({ data: [memberships[0]] } as never)
      .mockResolvedValueOnce({ data: [memberships[1]] } as never);
    let finishCleanup!: () => void;
    let notifyStarted!: () => void;
    const started = new Promise<void>((resolve) => {
      notifyStarted = resolve;
    });
    const pending = new Promise<void>((resolve) => {
      finishCleanup = resolve;
    });
    mockDeleteOrganizationMembership
      .mockRejectedValueOnce(new Error("Provider unavailable") as never)
      .mockImplementationOnce(() => {
        notifyStarted();
        return pending as never;
      });
    const responsePromise = POST(request() as any);
    await started;
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(mockMembershipLockRelease).not.toHaveBeenCalled();
    finishCleanup();
    const response = await responsePromise;
    expect(response.status).toBe(500);
    expect(mockMembershipLockRelease).toHaveBeenCalledTimes(2);
    expect(mockDeleteUser).not.toHaveBeenCalled();
  });

  it("does not claim success when membership removal fails", async () => {
    const membership = {
      id: "membership_user",
      organizationId: "org_team",
      userId: "user_123",
      role: { slug: "member" },
    };
    mockListOrganizationMemberships
      .mockResolvedValueOnce({ data: [membership] } as never)
      .mockResolvedValueOnce({ data: [membership] } as never);
    mockDeleteOrganizationMembership.mockRejectedValueOnce(
      new Error("Provider unavailable") as never,
    );
    const response = await POST(request() as any);
    expect(response.status).toBe(500);
    expect(mockDeleteUser).not.toHaveBeenCalled();
  });

  it("marks identity and runs Convex cleanup before deleting a WorkOS user with no memberships", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);

    const response = await POST(request() as any);

    expect(response.status).toBe(200);
    expect(mockConvexMutation).toHaveBeenNthCalledWith(
      1,
      "userDeletion.beginUserDataDeletionByService",
      {
        serviceKey: "service_key",
        userId: "user_123",
      },
    );
    expect(mockConvexMutation).toHaveBeenNthCalledWith(
      2,
      "accountIdentities.markDeleted",
      {
        serviceKey: "service_key",
        identityHash: "free_quota:v1:identity_hash",
        userId: "user_123",
      },
    );
    expect(mockConvexMutation).toHaveBeenNthCalledWith(
      3,
      "userDeletion.deleteAllUserDataByService",
      {
        serviceKey: "service_key",
        userId: "user_123",
        preservedOrganizationIds: [],
      },
    );
    expect(mockConvexMutation.mock.invocationCallOrder[2]).toBeLessThan(
      mockDeleteUser.mock.invocationCallOrder[0],
    );
  });

  it("treats an already-missing WorkOS user as a completed deletion", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    const missingUserError = new Error("User not found: 'user_123'.");
    missingUserError.name = "NotFoundException";
    mockDeleteUser.mockRejectedValueOnce(missingUserError as never);

    const response = await POST(request() as any);

    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toEqual({ ok: true });
    expect(mockDeleteUser).toHaveBeenCalledWith("user_123");
  });

  it("keeps unexpected WorkOS user deletion failures visible", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    mockDeleteUser.mockRejectedValueOnce(
      new Error("WorkOS temporarily unavailable") as never,
    );

    const response = await POST(request() as any);
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.error).toBe("WorkOS temporarily unavailable");
  });

  it("does not accept absence of a different WorkOS user as success", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    mockDeleteUser.mockRejectedValueOnce(
      Object.assign(new Error("User not found: 'user_other'."), {
        name: "NotFoundException",
      }),
    );
    expect((await POST(request() as any)).status).toBe(500);
  });

  it("keeps other WorkOS NotFoundExceptions visible", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    const unrelatedNotFoundError = new Error(
      "Organization not found: 'org_123'.",
    );
    unrelatedNotFoundError.name = "NotFoundException";
    mockDeleteUser.mockRejectedValueOnce(unrelatedNotFoundError as never);

    const response = await POST(request() as any);
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.error).toBe("Organization not found: 'org_123'.");
  });

  it.each(["retry", "already_deleted", "exhausted", "read_failed"] as const)(
    "reconciles the just-deleted organization failure: %s",
    async (outcome) => {
      jest.useFakeTimers();
      try {
        const membership = {
          id: "membership_user",
          organizationId: "org_solo",
          userId: "user_123",
          role: { slug: "admin" },
        };
        mockListOrganizationMemberships
          .mockResolvedValueOnce({ data: [membership] } as never)
          .mockResolvedValueOnce({ data: [membership] } as never);
        mockGetOrganization.mockResolvedValueOnce({ id: "org_solo" } as never);
        const failure = Object.assign(
          new Error("Organization not found: 'org_solo'."),
          { name: "NotFoundException" },
        );
        const missingUser = Object.assign(
          new Error("User not found: 'user_123'."),
          { name: "NotFoundException" },
        );
        mockDeleteUser.mockRejectedValueOnce(failure);
        const getUser = jest.mocked(workos.userManagement.getUser);
        getUser.mockResolvedValue({ id: "user_123" } as never);
        if (outcome === "already_deleted")
          getUser.mockRejectedValueOnce(missingUser);
        if (outcome === "read_failed")
          getUser.mockRejectedValueOnce(new Error("read unavailable"));
        if (outcome === "exhausted") mockDeleteUser.mockRejectedValue(failure);

        const pending = POST(request() as any);
        await jest.runAllTimersAsync();
        const response = await pending;
        expect(response.status).toBe(
          outcome === "exhausted" || outcome === "read_failed" ? 500 : 200,
        );
        expect(mockDeleteOrganization).toHaveBeenCalledTimes(1);
        expect(mockDeleteUser).toHaveBeenCalledTimes(
          outcome === "exhausted" ? 3 : outcome === "retry" ? 2 : 1,
        );
        expect(getUser).toHaveBeenCalledWith("user_123");
        if (outcome === "exhausted") {
          expect(await response.json()).toEqual({
            error:
              "Account deletion needs identity-provider reconciliation. Please contact support so we can finish deleting your account.",
          });
          expect(mockLoggerError).toHaveBeenCalledWith(
            "account_deletion_failed",
            expect.objectContaining({ cause: failure }),
            expect.objectContaining({ stage: "delete_workos_user" }),
          );
          expect(mockLoggerWarn).toHaveBeenLastCalledWith(
            "account_identity_deletion_recovery",
            expect.objectContaining({
              attempt: 3,
              user_still_exists: true,
              reason: "reconciliation_required",
            }),
          );
        }
      } finally {
        jest.useRealTimers();
      }
    },
  );

  it("does not delete WorkOS or billing resources if Convex cleanup fails", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    mockConvexMutation
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(null)
      .mockRejectedValueOnce(new Error("Convex cleanup failed"));

    const response = await POST(request() as any);
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.error).toBe("Convex cleanup failed");
    expect(mockDeleteOrganizationMembership).not.toHaveBeenCalled();
    expect(mockListSubscriptions).not.toHaveBeenCalled();
    expect(mockDeleteCustomer).not.toHaveBeenCalled();
    expect(mockDeleteOrganization).not.toHaveBeenCalled();
    expect(mockDeleteUserRateLimitKeys).not.toHaveBeenCalled();
    expect(mockDeleteUser).not.toHaveBeenCalled();
  });

  it("closes approval Sessions and cancels Trigger runs before deleting Convex chat records", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    const resources = [
      {
        chatId: "chat-1",
        triggerRunId: "run-1",
        approvalSessionId: "approval-session-1",
      },
    ];
    mockFenceAndGetActiveAgentResourcesForUser.mockResolvedValue({
      resources,
      hasMore: false,
    } as never);

    const response = await POST(request() as any);

    expect(response.status).toBe(200);
    expect(mockCloseAndCancelAgentResources).toHaveBeenCalledWith(
      resources,
      "account-deleted",
    );
    expect(
      mockCloseAndCancelAgentResources.mock.invocationCallOrder[0],
    ).toBeLessThan(
      mockTerminateCloudSandboxesForUser.mock.invocationCallOrder[0],
    );
    expect(
      mockTerminateCloudSandboxesForUser.mock.invocationCallOrder[0],
    ).toBeLessThan(mockConvexMutation.mock.invocationCallOrder[2]);
    expect(mockConvexMutation.mock.invocationCallOrder[2]).toBeLessThan(
      mockDeleteUser.mock.invocationCallOrder[0],
    );
  });

  it("keeps Convex records and WorkOS identity when active resource cleanup fails", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    mockFenceAndGetActiveAgentResourcesForUser.mockResolvedValue({
      resources: [{ chatId: "chat-1", triggerRunId: "run-1" }],
      hasMore: false,
    } as never);
    mockCloseAndCancelAgentResources.mockRejectedValue(
      new Error("Trigger cleanup failed") as never,
    );

    const response = await POST(request() as any);
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.error).toBe("Trigger cleanup failed");
    expect(mockConvexMutation).toHaveBeenCalledTimes(2);
    expect(mockDeleteOrganizationMembership).not.toHaveBeenCalled();
    expect(mockDeleteUserRateLimitKeys).not.toHaveBeenCalled();
    expect(mockDeleteUser).not.toHaveBeenCalled();
  });

  it("keeps cloud session identifiers when provider termination fails", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    mockTerminateCloudSandboxesForUser.mockRejectedValueOnce(
      new Error("AWS termination failed"),
    );

    const response = await POST(request() as any);
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.error).toBe("AWS termination failed");
    expect(mockCloseAndCancelAgentResources).toHaveBeenCalled();
    expect(mockConvexMutation).toHaveBeenCalledTimes(2);
    expect(mockDeleteOrganizationMembership).not.toHaveBeenCalled();
    expect(mockDeleteUserRateLimitKeys).not.toHaveBeenCalled();
    expect(mockDeleteUser).not.toHaveBeenCalled();
  });

  it("repeats Convex cleanup batches before deleting external identity resources", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    mockConvexMutation
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce({ hasMore: true })
      .mockResolvedValueOnce({ hasMore: false });

    const response = await POST(request() as any);

    expect(response.status).toBe(200);
    expect(mockConvexMutation).toHaveBeenNthCalledWith(
      1,
      "userDeletion.beginUserDataDeletionByService",
      {
        serviceKey: "service_key",
        userId: "user_123",
      },
    );
    expect(mockConvexMutation).toHaveBeenNthCalledWith(
      2,
      "accountIdentities.markDeleted",
      {
        serviceKey: "service_key",
        identityHash: "free_quota:v1:identity_hash",
        userId: "user_123",
      },
    );
    expect(mockConvexMutation).toHaveBeenNthCalledWith(
      3,
      "userDeletion.deleteAllUserDataByService",
      {
        serviceKey: "service_key",
        userId: "user_123",
        preservedOrganizationIds: [],
      },
    );
    expect(mockConvexMutation).toHaveBeenNthCalledWith(
      4,
      "userDeletion.deleteAllUserDataByService",
      {
        serviceKey: "service_key",
        userId: "user_123",
        preservedOrganizationIds: [],
      },
    );
    expect(mockConvexMutation.mock.invocationCallOrder[3]).toBeLessThan(
      mockDeleteUser.mock.invocationCallOrder[0],
    );
    expect(mockDeleteUser).toHaveBeenCalledWith("user_123");
    expect(mockLoggerError).not.toHaveBeenCalled();
  });

  it("returns a continuation response with bounded progress when cleanup needs another request", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    mockConvexMutation
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(null)
      // Older Convex deployments returned only the completion marker. Keep
      // that deploy-skew shape compatible while collecting newer progress.
      .mockResolvedValueOnce({ hasMore: true })
      .mockResolvedValue({
        hasMore: true,
        deleted: { feedback: 40, messages: 40 },
        anonymized: { usage_logs: 10 },
        s3ObjectsQueued: 2,
      });

    const response = await POST(request() as any);
    const body = await response.json();

    expect(response.status).toBe(409);
    expect(body).toEqual({ code: "account_cleanup_in_progress" });
    expect(mockConvexMutation).toHaveBeenCalledTimes(52);
    expect(mockLoggerWarn).toHaveBeenCalledWith(
      "account_cleanup_continuation_required",
      {
        event: "account_cleanup_continuation_required",
        service: "hackerai-web",
        environment: process.env.VERCEL_ENV ?? process.env.NODE_ENV,
        request_id: "iad1::opaque-request",
        user_id: "user_123",
        reason: "cleanup_batch_limit_exhausted",
        batch_limit: 50,
        progress_stats_batches: 49,
        batches_with_progress: 49,
        deleted_documents: 3920,
        anonymized_documents: 490,
        s3_objects_queued: 98,
        last_batch_deleted_documents: 80,
        last_batch_anonymized_documents: 10,
        last_batch_s3_objects_queued: 2,
      },
    );
    expect(mockDeleteOrganizationMembership).not.toHaveBeenCalled();
    expect(mockDeleteUserRateLimitKeys).not.toHaveBeenCalled();
    expect(mockDeleteUser).not.toHaveBeenCalled();
    expect(mockLoggerError).not.toHaveBeenCalled();
  });

  it("does not delete external identity resources when Convex cleanup returns an unexpected shape", async () => {
    mockListOrganizationMemberships.mockResolvedValueOnce({
      data: [],
    } as never);
    mockConvexMutation
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(null);

    const response = await POST(request() as any);
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.error).toContain("unexpected response");
    expect(mockDeleteOrganizationMembership).not.toHaveBeenCalled();
    expect(mockListSubscriptions).not.toHaveBeenCalled();
    expect(mockDeleteCustomer).not.toHaveBeenCalled();
    expect(mockDeleteOrganization).not.toHaveBeenCalled();
    expect(mockDeleteUserRateLimitKeys).not.toHaveBeenCalled();
    expect(mockDeleteUser).not.toHaveBeenCalled();
  });

  it("does not delete org billing when a shared-org admin deletes their account", async () => {
    const callerMembership = {
      id: "membership_admin",
      organizationId: "org_team",
      userId: "user_123",
      role: { slug: "admin" },
    };

    mockListOrganizationMemberships
      .mockResolvedValueOnce({ data: [callerMembership] } as never)
      .mockResolvedValueOnce({
        data: [
          callerMembership,
          {
            id: "membership_other_admin",
            organizationId: "org_team",
            userId: "user_admin",
            role: { slug: "admin" },
          },
          {
            id: "membership_member",
            organizationId: "org_team",
            userId: "user_member",
            role: { slug: "member" },
          },
        ],
      } as never);

    const response = await POST(request() as any);

    expect(response.status).toBe(200);
    expect(mockDeleteOrganizationMembership).toHaveBeenCalledWith(
      "membership_admin",
    );
    expect(mockListSubscriptions).not.toHaveBeenCalled();
    expect(mockDeleteCustomer).not.toHaveBeenCalled();
    expect(mockDeleteOrganization).not.toHaveBeenCalled();
    expect(mockDeleteUser).toHaveBeenCalledWith("user_123");
    expect(mockConvexMutation).toHaveBeenCalledWith(
      "accountIdentities.markDeleted",
      {
        serviceKey: "service_key",
        identityHash: "free_quota:v1:identity_hash",
        userId: "user_123",
      },
    );
    expect(mockConvexMutation).toHaveBeenCalledWith(
      "userDeletion.deleteAllUserDataByService",
      {
        serviceKey: "service_key",
        userId: "user_123",
        preservedOrganizationIds: ["org_team"],
      },
    );
  });

  it("blocks deletion when the caller is the last admin of a shared organization", async () => {
    const callerMembership = {
      id: "membership_admin",
      organizationId: "org_team",
      userId: "user_123",
      role: { slug: "admin" },
    };

    mockListOrganizationMemberships
      .mockResolvedValueOnce({ data: [callerMembership] } as never)
      .mockResolvedValueOnce({
        data: [
          callerMembership,
          {
            id: "membership_member",
            organizationId: "org_team",
            userId: "user_member",
            role: { slug: "member" },
          },
        ],
      } as never);

    const response = await POST(request() as any);
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toContain("last admin");
    expect(mockDeleteOrganizationMembership).not.toHaveBeenCalled();
    expect(mockListSubscriptions).not.toHaveBeenCalled();
    expect(mockDeleteOrganization).not.toHaveBeenCalled();
    expect(mockConvexMutation).not.toHaveBeenCalled();
    expect(mockDeleteUser).not.toHaveBeenCalled();
  });
});
