"use client";

import { useConvexAuth } from "convex/react";
import { ChatLayout } from "@/app/components/ChatLayout";
import Loading from "@/components/ui/loading";
import { SlowLoadingNotice } from "@/app/components/SlowLoadingNotice";
import { useHasAuthenticatedBefore } from "@/app/hooks/useHasAuthenticatedBefore";
import { ChatRoutePresentationProvider } from "@/app/contexts/ChatRoutePresentationContext";
import { useGlobalState } from "@/app/contexts/GlobalState";
import TeamPricingDialog from "@/app/components/TeamPricingDialog";

const fullWidthShell = (
  <div className="h-dvh min-h-0 flex flex-col bg-background overflow-hidden">
    <div className="flex-1 flex flex-col items-center justify-center min-h-0">
      <Loading />
      <SlowLoadingNotice label="Connecting…" />
    </div>
  </div>
);

/**
 * Shared layout for / and /c/[id]. Renders the Chat Sidebar only when authenticated
 * so it stays mounted across navigations within the group. Returning users keep
 * the shell mounted during brief auth refreshes so active streams and
 * computer-sidebar state do not flash away.
 */
export default function ChatRouteLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isLoading, isAuthenticated } = useConvexAuth();
  const hasAuthHint = useHasAuthenticatedBefore();
  const { teamPricingDialogOpen, setTeamPricingDialogOpen } = useGlobalState();

  if (isAuthenticated || (isLoading && hasAuthHint)) {
    return (
      <div className="h-dvh min-h-0 flex flex-col bg-background overflow-hidden">
        <ChatRoutePresentationProvider>
          <ChatLayout>{children}</ChatLayout>
          <TeamPricingDialog
            isOpen={teamPricingDialogOpen}
            onClose={() => setTeamPricingDialogOpen(false)}
          />
        </ChatRoutePresentationProvider>
      </div>
    );
  }

  if (isLoading) {
    return fullWidthShell;
  }

  return (
    <div className="h-dvh min-h-0 flex flex-col bg-background overflow-hidden">
      {children}
    </div>
  );
}
