"use client";

import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import dynamic from "next/dynamic";
import { Terminal } from "lucide-react";
import { codeToHtml } from "shiki";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { isInteractiveShellAction } from "@/app/components/tools/shell-tool-utils";
import { isWebAssemblyAvailable } from "@/lib/utils/shiki";
import type { SidebarTerminal } from "@/types/chat";

const XtermRenderer = dynamic(
  () => import("./XtermRenderer").then((m) => m.XtermRenderer),
  { ssr: false },
);

interface TerminalCodeBlockProps {
  command: string;
  output?: string;
  isExecuting?: boolean;
  status?: "ready" | "submitted" | "streaming" | "error";
  isBackground?: boolean;
  variant?: "default" | "sidebar";
  wrap?: boolean;
  shellAction?: string;
  rawBytes?: string; // Raw PTY bytes for xterm rendering
  executionPhase?: SidebarTerminal["executionPhase"];
}

interface AnsiCodeBlockProps {
  code: string;
  isWrapped?: boolean;
  isStreaming?: boolean;
  theme?: string;
  className?: string;
  style?: React.CSSProperties;
  delay?: number;
}

// Cache for rendered ANSI content to avoid re-rendering identical content
const ansiCache = new Map<string, string>();
const MAX_CACHE_SIZE = 100;

// Clean cache when it gets too large
const cleanCache = () => {
  if (ansiCache.size >= MAX_CACHE_SIZE) {
    const entries = Array.from(ansiCache.entries());
    // Remove only the overflow count of oldest entries (FIFO)
    const toRemove = Math.max(0, ansiCache.size - MAX_CACHE_SIZE + 1);
    for (let i = 0; i < toRemove; i++) {
      ansiCache.delete(entries[i][0]);
    }
  }
};

const createPlainTextHtml = (codeToRender: string): string => {
  const escapedCode = codeToRender.replace(/[&<>"']/g, (char) => {
    const entities: Record<string, string> = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    };
    return entities[char];
  });
  return `<pre><code>${escapedCode}</code></pre>`;
};

/**
 * Optimized ANSI code renderer with streaming support
 * Uses native Shiki codeToHtml with react-shiki patterns for performance
 *
 * Features:
 * - Bounded rendering batches so continuous output keeps making visible progress
 * - Caching to avoid re-rendering identical content
 * - Race condition protection for async renders
 * - Memory management with cache cleanup
 * - Proper HTML escaping for fallback content
 */
const AnsiCodeBlock = ({
  code,
  isWrapped,
  isStreaming = false,
  theme = "houston",
  className,
  style,
  delay: customDelay,
}: AnsiCodeBlockProps) => {
  const [htmlContent, setHtmlContent] = useState<string>("");
  const [isRendering, setIsRendering] = useState(false);
  const renderTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const pendingCodeRef = useRef("");
  const lastRenderedCodeRef = useRef<string>("");
  const cacheKeyRef = useRef<string>("");

  const scheduleRender = useCallback(
    (code: string) => {
      // A replacement invalidates an old highlight immediately. Appended output
      // may still display its in-flight prefix while the next batch is pending.
      if (!code.startsWith(pendingCodeRef.current)) cacheKeyRef.current = "";
      pendingCodeRef.current = code;
      // Keep the first chunk's deadline. Restarting it on every update can
      // leave the terminal blank until a continuous stream finally stops.
      if (renderTimeoutRef.current !== null) return;

      const delay = customDelay ?? (isStreaming ? 150 : 0);

      renderTimeoutRef.current = setTimeout(async () => {
        renderTimeoutRef.current = null;
        const codeToRender = pendingCodeRef.current;
        const cacheKey = `${codeToRender}-${isWrapped}-${theme}`;
        cacheKeyRef.current = cacheKey;

        // Skip if we've already rendered this exact content
        if (lastRenderedCodeRef.current === codeToRender) {
          return;
        }

        // Check cache first
        if (ansiCache.has(cacheKey)) {
          setHtmlContent(ansiCache.get(cacheKey)!);
          lastRenderedCodeRef.current = codeToRender;
          return;
        }

        setIsRendering(true);

        try {
          if (!isWebAssemblyAvailable()) {
            const fallbackHtml = createPlainTextHtml(codeToRender);
            if (cacheKeyRef.current === cacheKey) {
              setHtmlContent(fallbackHtml);
              cleanCache();
              ansiCache.set(cacheKey, fallbackHtml);
              lastRenderedCodeRef.current = codeToRender;
            }
            return;
          }

          const html = await codeToHtml(codeToRender, {
            lang: "ansi",
            theme: theme,
          });

          // Only update if this is still the current render request
          if (cacheKeyRef.current === cacheKey) {
            setHtmlContent(html);
            cleanCache();
            ansiCache.set(cacheKey, html);
            lastRenderedCodeRef.current = codeToRender;
          }
        } catch (error) {
          console.error("Failed to render ANSI code:", error);
          const fallbackHtml = createPlainTextHtml(codeToRender);

          if (cacheKeyRef.current === cacheKey) {
            setHtmlContent(fallbackHtml);
            cleanCache();
            ansiCache.set(cacheKey, fallbackHtml);
            lastRenderedCodeRef.current = codeToRender;
          }
        } finally {
          if (cacheKeyRef.current === cacheKey) setIsRendering(false);
        }
      }, delay);
    },
    [isStreaming, isWrapped, theme, customDelay],
  );

  useEffect(
    () => () => {
      if (renderTimeoutRef.current !== null) {
        clearTimeout(renderTimeoutRef.current);
        renderTimeoutRef.current = null;
      }
      cacheKeyRef.current = "";
    },
    [scheduleRender],
  );

  useEffect(() => {
    if (code) {
      scheduleRender(code);
    } else {
      if (renderTimeoutRef.current !== null) {
        clearTimeout(renderTimeoutRef.current);
        renderTimeoutRef.current = null;
      }
      cacheKeyRef.current = "";
      setHtmlContent("");
      setIsRendering(false);
      lastRenderedCodeRef.current = "";
    }
  }, [code, scheduleRender]);

  // Memoize the className to prevent unnecessary re-calculations (react-shiki pattern)
  const containerClassName = useMemo(() => {
    const heightClasses = "h-full [&_pre]:h-full [&_pre]:flex [&_pre]:flex-col";
    const baseClasses = `shiki not-prose relative bg-transparent text-sm font-[450] text-card-foreground [&_pre]:!bg-transparent [&_pre]:px-[1em] [&_pre]:py-[1em] [&_pre]:rounded-none [&_pre]:m-0 [&_pre]:min-w-0 [&_code]:bg-transparent [&_span]:bg-transparent ${heightClasses} ${
      isWrapped
        ? "[&_pre]:whitespace-pre-wrap [&_pre]:break-words [&_pre]:word-break-break-word"
        : "[&_pre]:whitespace-pre [&_pre]:overflow-x-auto [&_pre]:max-w-full"
    }`;
    return className ? `${baseClasses} ${className}` : baseClasses;
  }, [isWrapped, className]);

  // Show loading state for initial render or when switching between very different content
  if (!htmlContent && (isRendering || code)) {
    return (
      <div className="px-4 py-4 text-muted-foreground">
        <Shimmer>
          {isStreaming ? "Processing output..." : "Rendering output..."}
        </Shimmer>
      </div>
    );
  }

  // Show empty state
  if (!htmlContent && !code) {
    return null;
  }

  return (
    <div
      className={containerClassName}
      style={style}
      dangerouslySetInnerHTML={{ __html: htmlContent }}
    />
  );
};

export const TerminalCodeBlock = ({
  command,
  output,
  isExecuting = false,
  status,
  isBackground = false,
  variant = "default",
  wrap = false,
  shellAction,
  rawBytes,
  executionPhase,
}: TerminalCodeBlockProps) => {
  const [isWrapped, setIsWrapped] = useState(wrap);

  // Update wrapping state when prop changes
  useEffect(() => {
    setIsWrapped(wrap);
  }, [wrap]);

  const isInteractiveAction = isInteractiveShellAction(shellAction);
  const commandPrefix = shellAction === "send" ? ">" : "$";

  // For interactive actions the output already contains the full session
  // snapshot (with the PTY echo of the model's input inline). The ToolBlock
  // chip shows "Sent input X" so no prefix/append needed here. Use `??` so
  // an intentionally empty snapshot (e.g. a fresh session that hasn't echoed
  // yet) renders as a blank terminal instead of falling back to the command.
  const terminalContent = isInteractiveAction
    ? (output ?? command)
    : output
      ? `${commandPrefix} ${command}\n${output}`
      : `${commandPrefix} ${command}`;
  const displayContent = output || "";

  // For non-sidebar variant, keep the original terminal look
  if (variant !== "sidebar") {
    return (
      <div className="terminal-codeblock not-prose relative rounded-lg bg-card border border-border my-2 overflow-hidden flex flex-col h-full">
        {/* Terminal command input */}
        <div className="flex items-center justify-between px-4 py-2 bg-secondary border-b border-border">
          <div className="flex items-center space-x-2 flex-1 min-w-0">
            <Terminal
              size={14}
              className="text-muted-foreground flex-shrink-0"
            />
            <code className="text-sm font-mono text-foreground truncate">
              {command}
            </code>
          </div>
        </div>

        {/* Background process indicator */}
        {isBackground && (
          <div className="px-4 py-3 text-muted-foreground border-b border-border">
            Running in background
          </div>
        )}

        {/* Terminal output */}
        {(output || isExecuting) && (
          <div className="flex-1 min-h-0 overflow-hidden">
            {isExecuting && !output && status === "streaming" ? (
              <div className="px-4 py-4 text-muted-foreground">
                <Shimmer>
                  {isInteractiveAction
                    ? "Waiting for output"
                    : "Executing command"}
                </Shimmer>
              </div>
            ) : (
              <AnsiCodeBlock
                code={displayContent}
                isWrapped={isWrapped}
                isStreaming={status === "streaming" || isExecuting}
                theme="houston"
                delay={150}
              />
            )}
          </div>
        )}
      </div>
    );
  }

  // For sidebar variant, use file block style (no floating buttons since header handles them).
  // rawBytes is only populated for interactive PTY contexts (interact_terminal_session
  // actions or run_terminal_cmd interactive=true) where cursor-movement / TUI rendering
  // matters. Non-interactive exec falls through to AnsiCodeBlock (shiki).
  const useXterm = rawBytes !== undefined;
  const preExecutionLabel =
    executionPhase === "reviewing"
      ? "Reviewing before execution…"
      : executionPhase === "awaiting_approval"
        ? "Awaiting approval…"
        : undefined;

  return (
    <div className="shiki not-prose relative h-full w-full bg-transparent overflow-hidden">
      {/* xterm manages its own viewport + scrollbar; AnsiCodeBlock needs the
          wrapper to scroll. Avoid double scrollbars by toggling overflow. */}
      <div
        className={`h-full w-full bg-background ${useXterm ? "overflow-hidden" : "overflow-auto"}`}
      >
        {preExecutionLabel ? (
          <div className="h-full w-full overflow-auto px-[1em] py-[1em] text-sm font-[450] text-card-foreground">
            <pre
              className={`m-0 font-mono ${
                isWrapped
                  ? "whitespace-pre-wrap break-words"
                  : "whitespace-pre overflow-x-auto"
              }`}
            >
              <code>{`${commandPrefix} ${command}`}</code>
            </pre>
            <div className="mt-3 text-muted-foreground">
              {preExecutionLabel}
            </div>
          </div>
        ) : isExecuting && !output && status === "streaming" ? (
          isInteractiveAction ? (
            <div className="px-4 py-4 text-muted-foreground h-full flex items-start">
              <Shimmer>Waiting for output</Shimmer>
            </div>
          ) : (
            <div className="h-full w-full overflow-auto px-[1em] py-[1em] text-sm font-[450] text-card-foreground">
              <pre
                className={`m-0 font-mono ${
                  isWrapped
                    ? "whitespace-pre-wrap break-words"
                    : "whitespace-pre overflow-x-auto"
                }`}
              >
                <code>{`${commandPrefix} ${command}`}</code>
              </pre>
              <div className="mt-3 text-muted-foreground">
                <Shimmer>Executing command</Shimmer>
              </div>
            </div>
          )
        ) : useXterm ? (
          <XtermRenderer
            bytes={rawBytes}
            isStreaming={status === "streaming" || isExecuting}
            className="h-full w-full"
          />
        ) : (
          <AnsiCodeBlock
            code={terminalContent}
            isWrapped={isWrapped}
            isStreaming={status === "streaming" || isExecuting}
            theme="houston"
            delay={150}
            className="h-full w-full"
          />
        )}
      </div>
    </div>
  );
};
