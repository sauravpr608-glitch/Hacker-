"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import { useAction, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { RefreshCw, Info, TrendingDown } from "lucide-react";
import {
  Tooltip,
  TooltipTrigger,
  TooltipContent,
} from "@/components/ui/tooltip";
import type { SubscriptionTier } from "@/types";
import { calculateUsageProjection } from "@/lib/usage-projection";

type UsageLimitStatus = {
  remaining: number;
  limit: number;
  used: number;
  usagePercentage: number;
  resetTime: string | null;
};

type TokenUsageStatus = {
  monthly: UsageLimitStatus;
  monthlyBudgetUsd: number;
};

const POINTS_PER_DOLLAR = 10_000;

const formatPointsAsDollars = (points: number): string => {
  const dollars = points / POINTS_PER_DOLLAR;
  return `$${dollars.toFixed(2)}`;
};

const formatResetDateShort = (resetTime: string | null): string => {
  if (!resetTime) return "";
  const date = new Date(resetTime);
  return `Renews ${date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`;
};

const formatResetDateFull = (resetTime: string | null): string => {
  if (!resetTime) return "";
  const date = new Date(resetTime);
  return date.toLocaleString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZoneName: "short",
  });
};

const getRemainingColorClass = (percentage: number): string => {
  if (percentage <= 10) return "bg-red-500";
  if (percentage <= 30) return "bg-orange-500";
  return "bg-blue-500";
};

const formatProjectionDate = (date: Date): string => {
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });
};

interface IncludedUsageCardProps {
  subscription: SubscriptionTier;
}

const IncludedUsageCard = ({ subscription }: IncludedUsageCardProps) => {
  const [tokenUsage, setTokenUsage] = useState<TokenUsageStatus | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const getAgentRateLimitStatus = useAction(
    api.rateLimitStatus.getAgentRateLimitStatus,
  );

  const dailyUsage = useQuery(
    api.usageLogs.getDailyUsageSummary,
    subscription !== "free" ? { days: 7 } : "skip",
  );

  const fetchTokenUsage = useCallback(async () => {
    if (subscription === "free") {
      setTokenUsage(null);
      return;
    }

    setIsLoading(true);
    try {
      const status = await getAgentRateLimitStatus({ subscription });
      setTokenUsage(status);
    } catch (error) {
      console.error("Failed to fetch token usage:", error);
    } finally {
      setIsLoading(false);
    }
  }, [subscription, getAgentRateLimitStatus]);

  useEffect(() => {
    fetchTokenUsage();
  }, [fetchTokenUsage]);

  const projection = useMemo(() => {
    if (!tokenUsage || !dailyUsage || !tokenUsage.monthly.resetTime) {
      return null;
    }
    const remainingDollars = tokenUsage.monthly.remaining / POINTS_PER_DOLLAR;
    const resetTime = new Date(tokenUsage.monthly.resetTime);
    return calculateUsageProjection(remainingDollars, resetTime, dailyUsage);
  }, [tokenUsage, dailyUsage]);

  const remainingPercentage =
    tokenUsage && tokenUsage.monthly.limit > 0
      ? Math.round(
          (tokenUsage.monthly.remaining / tokenUsage.monthly.limit) * 100,
        )
      : 0;

  return (
    <div className="rounded-lg border bg-card p-4 space-y-3">
      <p className="text-xs text-muted-foreground">Included usage remaining</p>
      {tokenUsage ? (
        <>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-semibold tabular-nums">
              {formatPointsAsDollars(tokenUsage.monthly.remaining)}
            </span>
            <span className="text-sm text-muted-foreground">
              / {formatPointsAsDollars(tokenUsage.monthly.limit)}
            </span>
          </div>
          <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div
              className={`h-full transition-all duration-500 ${getRemainingColorClass(remainingPercentage)}`}
              style={{
                width: `${Math.min(100, remainingPercentage)}%`,
              }}
            />
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <span>{formatResetDateShort(tokenUsage.monthly.resetTime)}</span>
            {tokenUsage.monthly.resetTime && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    type="button"
                    className="inline-flex items-center p-0.5 rounded hover:bg-muted"
                    aria-label="Show exact reset date and time"
                    tabIndex={0}
                  >
                    <Info className="h-3 w-3" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="bottom">
                  Included usage renews{" "}
                  {formatResetDateFull(tokenUsage.monthly.resetTime)}
                </TooltipContent>
              </Tooltip>
            )}
          </div>
          {projection?.projectedExhaustionDate ? (
            <div className="flex items-center gap-1.5 text-xs text-orange-600 dark:text-orange-400">
              <TrendingDown className="h-3 w-3 flex-shrink-0" />
              <span>
                At this pace, runs out ~
                {formatProjectionDate(projection.projectedExhaustionDate)}
                {projection.daysRemaining !== null && (
                  <>
                    {" "}
                    (
                    {projection.daysRemaining <= 1
                      ? "less than a day"
                      : `~${Math.round(projection.daysRemaining)} days`}
                    )
                  </>
                )}
              </span>
            </div>
          ) : null}
        </>
      ) : isLoading ? (
        <div className="flex items-center gap-2 text-sm text-muted-foreground py-3">
          <RefreshCw className="h-3.5 w-3.5 animate-spin" />
          <span>Loading...</span>
        </div>
      ) : (
        <p className="text-sm text-muted-foreground py-3">
          Unable to load usage.
        </p>
      )}
    </div>
  );
};

export { IncludedUsageCard };
