"use client";

import { useEffect, useRef } from "react";
import { toast } from "sonner";
import { getSubscriptionCancellationStatus } from "@/lib/billing/client";
import { openSettingsDialog } from "@/lib/utils/settings-dialog";
import { reloadWithEntitlementRefresh } from "@/lib/auth/entitlement-refresh-navigation";

const NOTICE_ID = "billing-recovery-return";

/** Checks Stripe's invoice state after returning from a payment-method flow. */
export function BillingRecoveryReturnNotice() {
  const latestCheck = useRef(0);
  const returnedFromPortal = useRef(false);
  useEffect(() => {
    const url = new URL(window.location.href);
    if (url.searchParams.get("billing-recovery-return") === "1") {
      returnedFromPortal.current = true;
      url.searchParams.delete("billing-recovery-return");
      window.history.replaceState(window.history.state, "", url.toString());
    }
    if (!returnedFromPortal.current) return;
    let mounted = true;

    const checkPayment = async () => {
      const checkId = ++latestCheck.current;
      try {
        const status = await getSubscriptionCancellationStatus();
        if (!mounted || checkId !== latestCheck.current) return;
        if (status.checkoutRequiresReview) {
          toast.warning(
            status.billingReviewUnavailable
              ? "We couldn't verify your billing status"
              : "Your previous subscription payment still needs review",
            {
              id: NOTICE_ID,
              description: status.billingReviewUnavailable
                ? "We couldn't check your payment history. Open Account settings to retry or get billing help."
                : "Updating your card does not restart an ended subscription. Open Account settings for billing help.",
              action: {
                label: "Review billing",
                onClick: () => openSettingsDialog("Account"),
              },
            },
          );
        } else if (!status.hasActiveSubscription) {
          toast.info("You can choose a plan to subscribe again", {
            id: NOTICE_ID,
            description: "Updating a card does not start a subscription.",
          });
        } else if (
          status.renewalInvoicePaid &&
          (status.subscriptionStatus === "active" ||
            status.subscriptionStatus === "trialing")
        ) {
          toast.success(
            "Your renewal invoice is paid. Refresh to update your access.",
            {
              id: NOTICE_ID,
              action: {
                label: "Refresh",
                onClick: reloadWithEntitlementRefresh,
              },
            },
          );
        } else if (status.renewalPaymentRequired) {
          const detail =
            status.renewalPaymentFailure === "insufficient_funds"
              ? "The latest payment was declined for insufficient funds."
              : status.renewalPaymentFailure === "authentication_required"
                ? "The latest payment needs authentication."
                : status.renewalPaymentFailure === "declined"
                  ? "The latest payment was declined."
                  : "A successful payment has not been confirmed yet.";
          toast.error("Your renewal invoice is still unpaid", {
            id: NOTICE_ID,
            description: `${detail} Open billing to pay the invoice, complete verification, or update your card.`,
            duration: Infinity,
            action: {
              label: "Resolve payment",
              onClick: () => openSettingsDialog("Account"),
            },
            cancel: {
              label: "Check again",
              onClick: () => void checkPayment(),
            },
          });
        } else if (status.subscriptionStatus === "active") {
          toast.info(
            "Your plan is active. Check billing for your latest invoice.",
            {
              id: NOTICE_ID,
              action: {
                label: "Check again",
                onClick: () => void checkPayment(),
              },
            },
          );
        } else {
          toast.warning("Payment is not confirmed yet", {
            id: NOTICE_ID,
            description:
              "Check your invoice in billing. Access returns after payment succeeds.",
            action: {
              label: "Check again",
              onClick: () => void checkPayment(),
            },
          });
        }
      } catch {
        if (!mounted || checkId !== latestCheck.current) return;
        toast.error("We couldn't verify the payment yet", {
          id: NOTICE_ID,
          description: "Check your invoice in billing or try again.",
          action: { label: "Check again", onClick: () => void checkPayment() },
        });
      }
    };

    void checkPayment();
    return () => {
      mounted = false;
    };
  }, []);

  return null;
}
