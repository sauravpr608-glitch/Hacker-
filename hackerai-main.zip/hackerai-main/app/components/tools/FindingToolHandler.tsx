"use client";

import { memo, useMemo } from "react";
import Link from "next/link";
import { useQueries } from "convex/react";
import { CopyCheck, ShieldAlert } from "lucide-react";
import { api } from "@/convex/_generated/api";
import type { ChatStatus, SidebarFinding } from "@/types/chat";
import type { FindingDetailRecord } from "@/types/finding";
import { isSidebarFinding } from "@/types/chat";
import ToolBlock from "@/components/ui/tool-block";
import { useToolSidebar } from "@/app/hooks/useToolSidebar";
import { captureAuthenticatedEvent } from "@/lib/analytics/client";
import { FindingCard } from "@/app/components/findings/FindingCard";
import {
  ToolErrorHandler,
  ToolValidationErrorHandler,
} from "./ToolErrorHandler";
import {
  createFindingFailureContent,
  isToolInputValidationError,
} from "@/lib/chat/tool-error-display";

type FindingOutput = {
  success?: boolean;
  finding_id?: string;
  duplicate_of?: string;
  title?: string;
  target?: string;
  endpoint?: string;
  severity?: SidebarFinding["severity"];
  cvss_score?: number;
  error?: "validation" | "duplicate" | "chat_not_found" | "general";
  validation_kind?: "evidence";
  message?: string;
  warning?: string;
};

export const SavedFindingCard = ({
  output,
  toolCallId,
}: {
  output: Required<
    Pick<
      FindingOutput,
      "finding_id" | "title" | "target" | "severity" | "cvss_score"
    >
  > &
    Pick<FindingOutput, "endpoint" | "warning">;
  toolCallId: string;
}) => {
  const queries = useMemo(
    () => ({
      finding: {
        query: api.findings.getFinding,
        args: { findingId: output.finding_id },
      },
    }),
    [output.finding_id],
  );
  const { finding: result } = useQueries(queries) as {
    finding?: FindingDetailRecord | null | Error;
  };
  const queryFailed = result instanceof Error;
  const finding = queryFailed ? undefined : result;

  const content = useMemo<SidebarFinding>(
    () => ({
      findingId: output.finding_id,
      title: finding?.title ?? output.title,
      target: finding?.target ?? output.target,
      endpoint: finding?.endpoint ?? output.endpoint,
      severity: finding?.severity ?? output.severity,
      cvssScore: finding?.cvss_score ?? output.cvss_score,
      isExecuting: false,
      toolCallId,
    }),
    [finding, output, toolCallId],
  );
  const { handleOpenInSidebar } = useToolSidebar({
    toolCallId,
    content,
    typeGuard: isSidebarFinding,
  });

  if (finding === null) {
    return (
      <ToolBlock
        icon={<ShieldAlert aria-hidden="true" />}
        action="Finding deleted"
        target={output.title}
      />
    );
  }

  const handleOpen = () => {
    captureAuthenticatedEvent("finding_viewed", { surface: "inline_card" });
    handleOpenInSidebar();
  };

  return (
    <div className="space-y-2">
      <FindingCard
        title={content.title}
        target={content.endpoint || content.target}
        severity={content.severity}
        cvssScore={content.cvssScore}
        onClick={handleOpen}
      />
      {queryFailed && (
        <p role="alert" className="text-xs text-muted-foreground">
          Saved report temporarily unavailable. Open the report to retry.
        </p>
      )}
      {(finding?.evidence_verification?.warning ?? output.warning) && (
        <p role="note" className="text-xs text-amber-600 dark:text-amber-400">
          Evidence verification incomplete. Open the report for details.
        </p>
      )}
    </div>
  );
};

export const FindingToolHandler = memo(function FindingToolHandler({
  part,
  status,
}: {
  part: any;
  status: ChatStatus;
}) {
  const { toolCallId = "", state, input, output, errorText } = part;
  const result = (output?.result ?? output ?? {}) as FindingOutput;
  const target = input?.title || input?.target;

  if (state === "input-streaming") {
    return status === "streaming" ? (
      <ToolBlock
        icon={<ShieldAlert aria-hidden="true" />}
        action="Preparing vulnerability report"
        isShimmer={true}
      />
    ) : null;
  }

  if (state === "input-available") {
    return status === "streaming" ? (
      <ToolBlock
        icon={<ShieldAlert aria-hidden="true" />}
        action="Saving confirmed finding"
        target={target}
        isShimmer={true}
      />
    ) : null;
  }

  if (state === "output-error") {
    return isToolInputValidationError(errorText) ? (
      <ToolValidationErrorHandler
        toolType="tool-create_vulnerability_report"
        toolCallId={toolCallId}
        errorText={errorText}
      />
    ) : (
      <ToolErrorHandler
        content={createFindingFailureContent({
          toolCallId,
          reason: "general",
        })}
      />
    );
  }

  if (state === "output-available") {
    if (result.success === false) {
      if (result.error !== "duplicate") {
        return (
          <ToolErrorHandler
            content={createFindingFailureContent({
              toolCallId,
              reason:
                result.error === "validation" &&
                result.validation_kind === "evidence"
                  ? "evidence"
                  : result.error === "validation" ||
                      result.error === "chat_not_found"
                    ? result.error
                    : "general",
            })}
          />
        );
      }

      return (
        <div className="max-w-xl space-y-2 rounded-xl border border-border bg-muted/20 p-3">
          <div className="flex items-center gap-2 text-sm font-medium">
            <CopyCheck className="size-4 shrink-0" aria-hidden="true" />
            Already reported
          </div>
          <p className="text-sm text-muted-foreground">
            This issue matches an existing finding in this chat. No duplicate
            was saved.
          </p>
          {result.duplicate_of && (
            <Link
              href={`/findings?finding=${encodeURIComponent(result.duplicate_of)}`}
              className="inline-flex rounded-md text-sm font-medium text-link hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              Open existing finding
            </Link>
          )}
        </div>
      );
    }

    if (
      result.success === true &&
      result.finding_id &&
      result.title &&
      result.target &&
      result.severity &&
      typeof result.cvss_score === "number"
    ) {
      return (
        <SavedFindingCard
          output={{
            warning: result.warning,
            finding_id: result.finding_id,
            title: result.title,
            target: result.target,
            endpoint: result.endpoint,
            severity: result.severity,
            cvss_score: result.cvss_score,
          }}
          toolCallId={toolCallId}
        />
      );
    }

    return (
      <ToolErrorHandler
        content={createFindingFailureContent({
          toolCallId,
          reason: "invalid_result",
        })}
      />
    );
  }

  return null;
});
