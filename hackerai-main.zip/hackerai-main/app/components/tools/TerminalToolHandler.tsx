import React, { memo, useMemo } from "react";
import { UIMessage } from "@ai-sdk/react";
import ToolBlock from "@/components/ui/tool-block";
import { Terminal } from "lucide-react";
import type { ChatStatus } from "@/types/chat";
import { isSidebarTerminal } from "@/types/chat";
import { useToolSidebar } from "../../hooks/useToolSidebar";
import {
  computeShellTerminalBlock,
  getTerminalExecutionPhase,
  getTerminalFailureAction,
  getShellDisplayCommand,
  getStreamingTerminalOutput,
  type ShellToolInput,
  type ShellToolOutput,
} from "./shell-tool-utils";
import { isUserStoppedToolError } from "@/lib/chat/tool-abort-utils";
import {
  getAgentAutoReviewDisplayState,
  getStreamedAgentAutoReviewLifecycle,
  getStreamedAgentAutoReviewSummary,
  getToolApprovalDisplayState,
  getToolApprovalDisplayTarget,
  ToolApprovalControls,
  useAgentAutoReviewLifecycleDisplay,
} from "./ToolApprovalControls";

interface TerminalToolHandlerProps {
  message: UIMessage;
  part: any;
  status: ChatStatus;
  canRequestApproval?: boolean;
  /** Pre-computed streaming output for this toolCallId (avoids filtering message.parts in every instance) */
  precomputedStreamingOutput?: string;
}

// Custom comparison to avoid re-renders when tool state hasn't changed
function areTerminalPropsEqual(
  prev: TerminalToolHandlerProps,
  next: TerminalToolHandlerProps,
): boolean {
  if (prev.status !== next.status) return false;
  if (prev.canRequestApproval !== next.canRequestApproval) return false;
  if (prev.part.state !== next.part.state) return false;
  if (prev.part.toolCallId !== next.part.toolCallId) return false;
  if (prev.part.output !== next.part.output) return false;
  if (prev.part.input !== next.part.input) return false;
  if (prev.part.errorText !== next.part.errorText) return false;
  if (prev.part.approval?.id !== next.part.approval?.id) return false;
  // Compare message.parts length for streaming output updates
  if (prev.message.parts.length !== next.message.parts.length) return false;
  if (prev.precomputedStreamingOutput !== next.precomputedStreamingOutput)
    return false;
  return true;
}

export const TerminalToolHandler = memo(function TerminalToolHandler({
  message,
  part,
  status,
  canRequestApproval,
  precomputedStreamingOutput,
}: TerminalToolHandlerProps) {
  const { toolCallId, state, input, output, errorText } = part;

  // Support both legacy run_terminal_cmd and new shell tool input shapes
  const isShellTool = part.type === "tool-shell" || input?.action !== undefined;
  const terminalInput = isShellTool
    ? {
        command: getShellDisplayCommand(input),
        is_background: false,
        interactive: false,
      }
    : (input as {
        command: string;
        justification?: string;
        prefix_rule?: string[];
        is_background: boolean;
        interactive?: boolean;
      });
  const terminalOutput = output as ShellToolOutput;

  // Memoize streaming output: use pre-computed value when passed, else derive from message.parts
  const effectiveToolCallId = (part as any).data?.toolCallId ?? toolCallId;
  const streamingOutput = useMemo(() => {
    if (precomputedStreamingOutput !== undefined)
      return precomputedStreamingOutput;
    return getStreamingTerminalOutput(message.parts, effectiveToolCallId);
  }, [precomputedStreamingOutput, message.parts, effectiveToolCallId]);
  const autoReview = useMemo(
    () =>
      getStreamedAgentAutoReviewSummary({
        parts: message.parts,
        approvalId: part.approval?.id,
        toolCallId,
      }),
    [message.parts, part.approval?.id, toolCallId],
  );
  const streamedAutoReviewLifecycle = useMemo(
    () =>
      getStreamedAgentAutoReviewLifecycle({
        parts: message.parts,
        toolCallId,
      }),
    [message.parts, toolCallId],
  );
  const autoReviewLifecycleDisplay = useAgentAutoReviewLifecycleDisplay({
    parts: message.parts,
    toolCallId,
  });
  const autoReviewDisplay = getAgentAutoReviewDisplayState(
    autoReviewLifecycleDisplay,
  );

  const executionPhase = getTerminalExecutionPhase({
    toolState: state,
    autoReviewStatus: streamedAutoReviewLifecycle?.status,
    errorText,
  });
  const isExecuting = executionPhase === "executing";
  const hasResult = state === "output-available";

  const { blockAction, blockTarget, sidebarContent } = useMemo(
    () =>
      computeShellTerminalBlock({
        isShellTool,
        shellInput: input as ShellToolInput | undefined,
        shellOutput: terminalOutput,
        errorText,
        streamingOutput,
        isExecuting,
        hasResult,
        toolCallId,
        legacyInteractive: !isShellTool
          ? terminalInput?.interactive
          : undefined,
        legacyIsBackground: !isShellTool
          ? terminalInput?.is_background
          : undefined,
        legacyCommand: !isShellTool ? terminalInput?.command : undefined,
        executionPhase,
      }),
    [
      isShellTool,
      input,
      terminalOutput,
      errorText,
      streamingOutput,
      isExecuting,
      hasResult,
      toolCallId,
      terminalInput?.interactive,
      terminalInput?.is_background,
      terminalInput?.command,
      executionPhase,
    ],
  );

  const { handleOpenInSidebar, handleKeyDown } = useToolSidebar({
    toolCallId,
    content: sidebarContent,
    typeGuard: isSidebarTerminal,
  });

  const shellAction = (input as { action?: string })?.action;
  const isStoppedByUser = isUserStoppedToolError(errorText);

  switch (state) {
    case "input-streaming": {
      if (status !== "streaming") return null;
      // For non-exec shell actions (wait, send, kill), use the action-specific
      // label instead of "Generating command" which only applies to exec
      if (isShellTool && shellAction && shellAction !== "exec") {
        return (
          <ToolBlock
            key={toolCallId}
            icon={<Terminal />}
            action={blockAction(true)}
            target={blockTarget || undefined}
            isShimmer={true}
          />
        );
      }
      return (
        <ToolBlock
          key={toolCallId}
          icon={<Terminal />}
          action="Generating command"
          isShimmer={true}
        />
      );
    }
    case "input-available":
      return (
        <ToolBlock
          key={toolCallId}
          icon={<Terminal />}
          action={
            autoReviewDisplay?.action ?? blockAction(status === "streaming")
          }
          target={blockTarget}
          isShimmer={autoReviewDisplay?.isShimmer ?? status === "streaming"}
          isClickable
          onClick={handleOpenInSidebar}
          onKeyDown={handleKeyDown}
        />
      );
    case "approval-requested":
      return (
        <ToolApprovalControls
          canRequestApproval={canRequestApproval}
          key={toolCallId}
          approvalId={part.approval?.id}
          toolCallId={toolCallId}
          title="Allow HackerAI to run this terminal command?"
          target={blockTarget}
          justification={terminalInput?.justification}
          prefixRule={terminalInput?.prefix_rule}
          detail="Approve to continue, or deny to stop this command."
          kind="terminal"
          operation="terminal_execute"
          autoReview={autoReview}
        >
          {(sendState) => {
            const display = getToolApprovalDisplayState({
              sendState,
              approvedAction: blockAction(true),
              deniedAction: "Command denied",
            });

            return (
              <ToolBlock
                icon={<Terminal />}
                action={display.action}
                target={getToolApprovalDisplayTarget({
                  sendState,
                  target: blockTarget,
                })}
                isShimmer={display.isShimmer}
                isClickable={!!sidebarContent}
                onClick={handleOpenInSidebar}
                onKeyDown={handleKeyDown}
              />
            );
          }}
        </ToolApprovalControls>
      );
    case "output-available":
      return (
        <ToolBlock
          key={toolCallId}
          icon={<Terminal />}
          action={blockAction(false)}
          target={blockTarget}
          isClickable
          onClick={handleOpenInSidebar}
          onKeyDown={handleKeyDown}
        />
      );
    case "output-error":
      return (
        <ToolBlock
          key={toolCallId}
          icon={<Terminal />}
          action={
            isStoppedByUser
              ? "Stopped command"
              : getTerminalFailureAction(errorText, shellAction)
          }
          target={blockTarget}
          isClickable={!!sidebarContent}
          onClick={handleOpenInSidebar}
          onKeyDown={handleKeyDown}
        />
      );
    default:
      return null;
  }
}, areTerminalPropsEqual);
