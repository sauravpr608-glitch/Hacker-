"use client";
import type { CompletedPredictionTurn } from "@/lib/chat/next-actions/contracts";
import { goalResumeMessage } from "@/lib/goals/commands";
import { CloudWorkspaceRecovery } from "./CloudWorkspaceRecovery";
import {
  CloudRecoveryAdmissionContext,
  useCloudRecoveryAdmission,
} from "@/app/hooks/useCloudRecoveryAdmission";

import { useChat, type UseChatHelpers } from "@ai-sdk/react";
import { DefaultChatTransport, type FileUIPart } from "ai";
import dynamic from "next/dynamic";
import {
  useRef,
  useEffect,
  useLayoutEffect,
  useState,
  useReducer,
  useCallback,
  useMemo,
  type RefObject,
} from "react";
import {
  useQuery,
  usePaginatedQuery,
  useMutation,
  useConvexAuth,
  useConvex,
} from "convex/react";
import { api } from "@/convex/_generated/api";
import type { FileDetails } from "@/types/file";
import { Messages } from "./Messages";
import { ChatInput } from "./ChatInput";
import { AgentGoalPanel } from "./AgentGoalPanel";
import { ComposerOverlay } from "./ComposerOverlay";
import { ScrollToBottomButton } from "./ScrollToBottomButton";
import { BrowserHandoffEntry } from "./BrowserHandoffEntry";
import type { RateLimitWarningData } from "./RateLimitWarning";
import ChatHeader from "./ChatHeader";
import Footer from "./Footer";
import { useMessageScroll } from "../hooks/useMessageScroll";
import { useQueuedMessageDelivery } from "@/app/hooks/useQueuedMessageDelivery";
import { useChatHandlers } from "../hooks/useChatHandlers";
import { useGlobalState } from "../contexts/GlobalState";
import { resolveFreeDesktopSandboxPreference } from "@/lib/activation/free-desktop-sandbox";
import { useComposerInput } from "../contexts/ComposerState";
import { useChatRoutePresentation } from "../contexts/ChatRoutePresentationContext";
import {
  type ActiveAgentToolApprovalRequest,
  useAgentApproval,
} from "../contexts/AgentApprovalContext";
import { useFileUpload } from "../hooks/useFileUpload";
import { useDocumentDragAndDrop } from "../hooks/useDocumentDragAndDrop";
import { DragDropOverlay } from "./DragDropOverlay";
import { normalizeMessages } from "@/lib/utils/message-processor";
import { ChatSDKError, deserializeChatSDKErrorFromStream } from "@/lib/errors";
import {
  fetchWithErrorHandlers,
  convertToUIMessages,
  type MessageRecord,
} from "@/lib/utils";
import { getSafeErrorEventMessage } from "@/lib/utils/error-event";
import { getBranchErrorMessage } from "@/lib/chat/branch-error";
import {
  cancelAgentLongRealtimeStreams,
  fetchAgentLongStream,
  resumeAgentLongStream,
} from "@/lib/chat/agent-long-transport";
import {
  areMessagesEquivalentForConvexSync,
  mergePersistedGoalMessages,
  arePersistedMessagesAtLeastAsComplete,
  normalizeStreamedRecoveryMessages,
} from "@/lib/chat/message-reconciliation";
import {
  LEGACY_DESKTOP_AGENT_UPDATE_MESSAGE,
  isLegacyDesktopAgentClient,
  shouldUseAgentLongForAgent,
} from "@/lib/chat/agent-routing";
import {
  AGENT_PARTIAL_SAVE_ENDPOINT,
  AGENT_RESUME_ENDPOINT,
  AGENT_STATUS_ENDPOINT,
  LEGACY_AGENT_RESUME_ENDPOINT,
} from "@/lib/api/agent-endpoints";
import { isTauriEnvironment } from "@/app/hooks/useTauri";
import { stripAgentLongHeartbeatPartsFromMessages } from "@/lib/chat/agent-long-heartbeat";
import { createAgentPartialSaveQueue } from "@/lib/chat/agent-partial-save-queue";
import { getAgentLongMessageProgressFingerprint } from "@/lib/chat/agent-long-message-progress";
import { getLatestAgentLongAssistantMessageForPartialSave } from "@/lib/chat/agent-partial-save-snapshot";
import { toast } from "sonner";
import {
  addAuthenticatedExceptionStep,
  getPostHogRequestHeaders,
} from "@/lib/analytics/client";
import {
  normalizeSelectedModelForSubscription,
  parseAgentAutoReviewSummary,
  type Todo,
  type ChatMessage,
} from "@/types";
import {
  getAgentToolApprovalPromptDetail,
  getAgentToolApprovalPromptKind,
  getAgentToolApprovalPromptTitle,
  isAgentToolApprovalOperation,
} from "@/types/agent";
import { coerceSelectedModel } from "@/types/chat";
import { v4 as uuidv4 } from "uuid";
import { useIsMobile } from "@/hooks/use-mobile";
import { useComputerSidebarOverlay } from "@/hooks/use-workspace-layout";
import { useSelectedComputerConnection } from "@/app/hooks/useSelectedComputerConnection";
import { useParams, useRouter } from "next/navigation";
import { ConvexErrorBoundary } from "./ConvexErrorBoundary";
import { SlowLoadingNotice } from "./SlowLoadingNotice";
import { useAutoResume } from "../hooks/useAutoResume";
import { useAutoContinue } from "../hooks/useAutoContinue";
import { findActiveTimelineAnchorMessageId } from "./message-timeline-rows";
import { useCommittedRef, useLatestRef } from "../hooks/useLatestRef";
import { useDataStreamDispatch } from "./DataStreamProvider";
import { useBatchedDataStreamAppend } from "@/app/hooks/useBatchedDataStreamAppend";
import {
  markSidebarTaskVisited,
  removeDraft,
} from "@/lib/utils/client-storage";
import { parseRateLimitWarning } from "@/lib/utils/parse-rate-limit-warning";
import { formatTaskUiCopy } from "@/app/utils/task-ui-copy";
import { finalizeNewChatRoute } from "./chat-route";
import { ChatPerformanceTracker } from "@/lib/analytics/chat-performance";
import { useChatPerformance } from "@/app/hooks/useChatPerformance";
import { useBrowserResponsiveness } from "@/app/hooks/useBrowserResponsiveness";

import { HackingSuggestions } from "./HackingSuggestions";

const AGENT_LONG_SILENT_COMPLETION_POLL_DELAY_MS = 5_000;
const AGENT_LONG_SILENT_COMPLETION_POLL_INTERVAL_MS = 5_000;
const AGENT_LONG_ACTIVE_COMPLETION_POLL_INTERVAL_MS = 15_000;
const AGENT_LONG_COMPLETION_STOP_GRACE_MS = 2_000;
const AGENT_LONG_COMPLETION_REQUEST_TIMEOUT_MS = 8_000;
type MessagePaginationStatus =
  "LoadingFirstPage" | "CanLoadMore" | "LoadingMore" | "Exhausted";

export const getStoredAgentApprovalRequest = (
  chatData: unknown,
): ActiveAgentToolApprovalRequest | null => {
  if (!chatData || typeof chatData !== "object") return null;
  const record = chatData as Record<string, unknown>;
  if (record.active_agent_approval_pending !== true) return null;
  const request = record.active_agent_approval_request;
  if (!request || typeof request !== "object") return null;
  const approvalRequest = request as Record<string, unknown>;
  const approvalId = approvalRequest.approvalId;
  const toolCallId = approvalRequest.toolCallId;
  if (typeof approvalId !== "string" || typeof toolCallId !== "string") {
    return null;
  }
  const operation = isAgentToolApprovalOperation(approvalRequest.operation)
    ? approvalRequest.operation
    : undefined;
  const fallbackTitle =
    typeof approvalRequest.title === "string"
      ? approvalRequest.title
      : undefined;
  const title = getAgentToolApprovalPromptTitle({
    operation,
    fallback: fallbackTitle,
  });
  if (!title) return null;
  const fallbackDetail =
    typeof approvalRequest.detail === "string"
      ? approvalRequest.detail
      : undefined;
  const fallbackKind =
    approvalRequest.kind === "terminal" || approvalRequest.kind === "file"
      ? approvalRequest.kind
      : undefined;
  const kind = getAgentToolApprovalPromptKind(operation) ?? fallbackKind;
  const detail = getAgentToolApprovalPromptDetail({
    operation,
    fallback: fallbackDetail,
  });
  const autoReview = parseAgentAutoReviewSummary(approvalRequest.autoReview);

  return {
    approvalId,
    toolCallId,
    ...(typeof approvalRequest.sourceRunId === "string"
      ? { sourceRunId: approvalRequest.sourceRunId }
      : {}),
    ...(typeof approvalRequest.sourceAgentId === "string"
      ? { sourceAgentId: approvalRequest.sourceAgentId }
      : {}),
    ...(typeof approvalRequest.sourceAgentName === "string"
      ? { sourceAgentName: approvalRequest.sourceAgentName }
      : {}),
    title,
    ...(operation ? { operation } : {}),
    ...(typeof approvalRequest.target === "string"
      ? { target: approvalRequest.target }
      : {}),
    ...(typeof approvalRequest.justification === "string"
      ? { justification: approvalRequest.justification }
      : {}),
    ...(Array.isArray(approvalRequest.prefixRule) &&
    approvalRequest.prefixRule.every((part) => typeof part === "string")
      ? { prefixRule: approvalRequest.prefixRule as string[] }
      : {}),
    ...(detail ? { detail } : {}),
    ...(kind ? { kind } : {}),
    ...(typeof approvalRequest.createdAt === "number"
      ? { createdAt: approvalRequest.createdAt }
      : {}),
    ...(autoReview ? { autoReview } : {}),
  };
};

export function getExistingChatLoadState({
  isExistingChat,
  hasMessages,
  isConvexAuthLoading,
  isConvexAuthenticated,
  shouldFetchMessages,
  chatData,
  paginationStatus,
  hasPaginatedMessageResults,
  awaitingServerChat,
}: {
  isExistingChat: boolean;
  hasMessages: boolean;
  isConvexAuthLoading: boolean;
  isConvexAuthenticated: boolean;
  shouldFetchMessages: boolean;
  chatData: unknown;
  paginationStatus?: MessagePaginationStatus;
  hasPaginatedMessageResults: boolean;
  awaitingServerChat: boolean;
}) {
  const isInitialExistingChatLoad =
    isExistingChat &&
    !hasMessages &&
    (isConvexAuthLoading ||
      !isConvexAuthenticated ||
      (shouldFetchMessages &&
        (chatData === undefined || paginationStatus === "LoadingFirstPage")));

  const isChatNotFound =
    isExistingChat &&
    chatData === null &&
    shouldFetchMessages &&
    !awaitingServerChat &&
    paginationStatus !== "LoadingFirstPage" &&
    !hasPaginatedMessageResults;

  return { isInitialExistingChatLoad, isChatNotFound };
}

const shouldReleaseStreamedTitle = (
  streamedTitle: string | null,
  persistedTitle: string | null | undefined,
): boolean => Boolean(streamedTitle && persistedTitle === streamedTitle);

export function useStreamedChatTitle(
  persistedTitle: string | null | undefined,
) {
  const [streamedTitle, setStreamedTitle] = useState<string | null>(null);

  // The streamed title only bridges the gap until Convex receives the same
  // generated title. This guarded adjustment restarts the current render
  // before children commit with a stale title source.
  if (shouldReleaseStreamedTitle(streamedTitle, persistedTitle)) {
    setStreamedTitle(null);
  }

  return [streamedTitle ?? persistedTitle ?? null, setStreamedTitle] as const;
}

export function useServerMessages(
  paginatedMessageResults: MessageRecord[] | undefined,
): ChatMessage[] {
  return useMemo(
    () =>
      paginatedMessageResults && paginatedMessageResults.length > 0
        ? convertToUIMessages([...paginatedMessageResults].reverse())
        : [],
    [paginatedMessageResults],
  );
}

const ComputerSidebar = dynamic(
  () => import("./ComputerSidebar").then((m) => m.ComputerSidebar),
  { ssr: false },
);

// --- Streaming ephemeral state reducer ---
// Consolidates high-frequency streaming state updates into a single dispatch
// to avoid cascading re-renders from multiple independent useState calls.
interface StreamingEphemeralState {
  uploadStatus: { message: string; isUploading: boolean } | null;
  summarizationStatus: {
    status: "started" | "completed";
    message: string;
    startedAt?: number;
  } | null;
  rateLimitWarning: RateLimitWarningData | null;
}

type StreamingAction =
  | {
      type: "SET_UPLOAD_STATUS";
      payload: StreamingEphemeralState["uploadStatus"];
    }
  | {
      type: "SET_SUMMARIZATION_STATUS";
      payload: StreamingEphemeralState["summarizationStatus"];
    }
  | {
      type: "SET_RATE_LIMIT_WARNING";
      payload: StreamingEphemeralState["rateLimitWarning"];
    }
  | { type: "RESET_ON_FINISH" }
  | { type: "RESET_ON_CHAT_CHANGE" };

const initialStreamingState: StreamingEphemeralState = {
  uploadStatus: null,
  summarizationStatus: null,
  rateLimitWarning: null,
};

function streamingReducer(
  state: StreamingEphemeralState,
  action: StreamingAction,
): StreamingEphemeralState {
  switch (action.type) {
    case "SET_UPLOAD_STATUS":
      if (state.uploadStatus === action.payload) return state;
      return { ...state, uploadStatus: action.payload };
    case "SET_SUMMARIZATION_STATUS":
      if (state.summarizationStatus === action.payload) return state;
      return { ...state, summarizationStatus: action.payload };
    case "SET_RATE_LIMIT_WARNING":
      return { ...state, rateLimitWarning: action.payload };
    case "RESET_ON_FINISH":
      if (state.uploadStatus === null && state.summarizationStatus === null)
        return state;
      return {
        ...state,
        uploadStatus: null,
        summarizationStatus: null,
      };
    case "RESET_ON_CHAT_CHANGE":
      if (
        state.uploadStatus === null &&
        state.summarizationStatus === null &&
        state.rateLimitWarning === null
      ) {
        return state;
      }
      return initialStreamingState;
    default:
      return state;
  }
}

function getLatestTodoWriteOutput(messages: ChatMessage[]):
  | {
      key: string;
      todos: Todo[];
    }
  | undefined {
  for (
    let messageIndex = messages.length - 1;
    messageIndex >= 0;
    messageIndex--
  ) {
    const message = messages[messageIndex];
    const parts = message.parts || [];
    for (let partIndex = parts.length - 1; partIndex >= 0; partIndex--) {
      const part = parts[partIndex] as any;
      const currentTodos = part?.output?.currentTodos;
      if (
        part?.type === "tool-todo_write" &&
        part?.state === "output-available" &&
        Array.isArray(currentTodos)
      ) {
        return {
          key: `${message.id}:${part.toolCallId || partIndex}`,
          todos: currentTodos as Todo[],
        };
      }
    }
  }
  return undefined;
}

// Renderless component that isolates dataStream state subscriptions
// (useAutoResume + useAutoContinue) from the Chat component.
// Without this boundary, Chat subscribes to DataStreamStateContext
// through these hooks and re-renders on every stream chunk.
function StreamEffects({
  chatId,
  autoResume,
  serverMessages,
  resumeStream,
  setMessages,
  status,
  chatMode,
  sendMessage,
  hasManuallyStoppedRef,
  todos,
  sandboxPreference,
  agentPermissionMode,
  selectedModel,
  resetRef,
  hasActiveStream,
  sendDisabledReason,
}: {
  sendDisabledReason?: string;
  chatId: string;
  autoResume: boolean;
  serverMessages: ChatMessage[];
  resumeStream: UseChatHelpers<ChatMessage>["resumeStream"];
  setMessages: UseChatHelpers<ChatMessage>["setMessages"];
  status: UseChatHelpers<ChatMessage>["status"];
  chatMode: string;
  sendMessage: (
    message: { text: string } | any,
    options?: { body?: Record<string, unknown> },
  ) => void;
  hasManuallyStoppedRef: RefObject<boolean>;
  todos: Todo[];
  sandboxPreference: string;
  agentPermissionMode: string;
  selectedModel: string;
  resetRef: RefObject<(() => void) | null>;
  hasActiveStream: boolean | undefined;
}) {
  useAutoResume({
    chatId,
    autoResume,
    initialMessages: serverMessages,
    resumeStream,
    setMessages,
    status,
    hasActiveStream,
  });

  const { resetAutoContinueCount } = useAutoContinue({
    chatId,
    status,
    chatMode,
    sendMessage,
    hasManuallyStoppedRef,
    todos,
    sandboxPreference,
    agentPermissionMode,
    selectedModel,
    sendDisabledReason,
  });

  // Expose resetAutoContinueCount to parent via ref (avoids state coupling)
  useEffect(() => {
    resetRef.current = resetAutoContinueCount;
  }, [resetRef, resetAutoContinueCount]);

  return null;
}

// Keep the live composer subscription below Chat. This effect needs to react
// when a shared-task draft is restored, but the rest of the chat shell does
// not need to rerender for every character the user types.
function ForkAutoSendEffect({
  chatId,
  status,
  isExistingChat,
  messageCount,
  onSubmit,
  sendDisabledReason,
}: {
  sendDisabledReason?: string;
  chatId: string;
  status: UseChatHelpers<ChatMessage>["status"];
  isExistingChat: boolean;
  messageCount: number;
  onSubmit: (event: React.FormEvent) => void | Promise<boolean>;
}) {
  const input = useComposerInput();
  const autoSendFiredRef = useRef(false);

  useEffect(() => {
    if (autoSendFiredRef.current || sendDisabledReason) return;
    try {
      const pendingChatId = sessionStorage.getItem("autoSendChatId");
      if (pendingChatId !== chatId) return;
    } catch {
      return;
    }
    if (status !== "ready" || !input.trim()) return;
    if (!isExistingChat || messageCount === 0) return;

    autoSendFiredRef.current = true;
    sessionStorage.removeItem("autoSendChatId");
    void onSubmit(new Event("submit") as unknown as React.FormEvent);
  }, [
    chatId,
    input,
    isExistingChat,
    messageCount,
    onSubmit,
    status,
    sendDisabledReason,
  ]);

  return null;
}

export const Chat = ({ autoResume }: { autoResume: boolean }) => {
  return (
    <ConvexErrorBoundary>
      <ChatContent autoResume={autoResume} />
    </ConvexErrorBoundary>
  );
};

const ChatContent = ({ autoResume }: { autoResume: boolean }) => {
  const convex = useConvex();
  const { sendDisabledReason: connectionSendDisabledReason } =
    useSelectedComputerConnection();
  const params = useParams();
  const routeChatId = params?.id as string | undefined;
  const router = useRouter();
  const isMobile = useIsMobile();
  const computerSidebarOverlay = useComputerSidebarOverlay();
  const computerDialogRef = useRef<HTMLDivElement>(null);
  const computerDialogPreviousFocusRef = useRef<HTMLElement | null>(null);
  const computerDialogShowedGoalRef = useRef(false);
  const { setDataStream, setIsAutoResuming } = useDataStreamDispatch();
  const { appendDataPart, clearDataStream } =
    useBatchedDataStreamAppend(setDataStream);
  const {
    isLoading: isConvexAuthLoading,
    isAuthenticated: isConvexAuthenticated,
  } = useConvexAuth();
  const [streamingState, dispatchStreaming] = useReducer(
    streamingReducer,
    initialStreamingState,
  );
  const { uploadStatus, summarizationStatus, rateLimitWarning } =
    streamingState;

  const {
    chatMode,
    setChatMode,
    sidebarOpen,
    sidebarContent,
    openSidebar,
    closeSidebar,
    chatSidebarOpen,
    initializeChat,
    setTodos,
    setChatReset,
    setChatNavigationHandler,
    hasUserDismissedRateLimitWarning,
    setHasUserDismissedRateLimitWarning,
    messageQueue,
    editingQueuedMessageId,
    removeQueuedMessage,
    setQueuedMessageDelivery,
    clearQueue,
    todos,
    sandboxPreference,
    setSandboxPreference,
    resetSandboxPreference,
    freeDesktopAgentOnlyActive,
    desktopBridgeActive,
    localConnections,
    agentPermissionMode,
    selectedModel,
    setSelectedModel,
    subscription,
    activeProjectId,
  } = useGlobalState();
  const { setAgentApprovalSession, clearAgentApprovalSession } =
    useAgentApproval();
  const { hasResolvedInitialPresentation, markInitialPresentationResolved } =
    useChatRoutePresentation();

  useEffect(() => {
    if (!computerSidebarOverlay || !sidebarOpen) return;

    const dialog = computerDialogRef.current;
    if (!dialog) return;

    computerDialogPreviousFocusRef.current =
      document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;

    const getFocusableElements = () =>
      Array.from(
        dialog.querySelectorAll<HTMLElement>(
          [
            "a[href]",
            "button:not([disabled])",
            "input:not([disabled])",
            "select:not([disabled])",
            "textarea:not([disabled])",
            "summary",
            '[tabindex]:not([tabindex="-1"])',
          ].join(", "),
        ),
      ).filter((element) => {
        if (element.getClientRects().length === 0) return false;
        // Closed details can still give descendants layout boxes in Chromium.
        // Only their direct summary remains keyboard-accessible.
        for (
          let parent = element.parentElement;
          parent && parent !== dialog;
          parent = parent.parentElement
        ) {
          if (
            parent instanceof HTMLDetailsElement &&
            !parent.open &&
            !(element.tagName === "SUMMARY" && element.parentElement === parent)
          )
            return false;
        }
        return true;
      });

    const hasNestedDialogFocus = () => {
      const focused = document.activeElement;
      return (
        focused instanceof HTMLElement &&
        !dialog.contains(focused) &&
        !!focused.closest('[role="dialog"]')
      );
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      // Takeover and its exit prompt render in portals above this dialog.
      if (hasNestedDialogFocus()) return;
      if (event.key === "Escape") {
        event.preventDefault();
        closeSidebar();
        return;
      }

      if (event.key !== "Tab") return;

      const focusableElements = getFocusableElements();
      if (focusableElements.length === 0) {
        event.preventDefault();
        dialog.focus();
        return;
      }

      const firstElement = focusableElements[0];
      const lastElement = focusableElements[focusableElements.length - 1];
      if (event.shiftKey && document.activeElement === firstElement) {
        event.preventDefault();
        lastElement.focus();
      } else if (!event.shiftKey && document.activeElement === lastElement) {
        event.preventDefault();
        firstElement.focus();
      }
    };

    const focusTimeout = window.setTimeout(() => {
      if (!hasNestedDialogFocus())
        (
          dialog.querySelector<HTMLElement>('[aria-label="Goal objective"]') ??
          getFocusableElements()[0] ??
          dialog
        ).focus();
    }, 0);
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      window.clearTimeout(focusTimeout);
      document.removeEventListener("keydown", handleKeyDown);
      const previousFocus = computerDialogPreviousFocusRef.current;
      const showedGoalEditor = computerDialogShowedGoalRef.current;
      computerDialogShowedGoalRef.current = false;
      if (!hasNestedDialogFocus()) {
        if (
          previousFocus?.isConnected &&
          previousFocus !== document.body &&
          !dialog.contains(previousFocus)
        )
          previousFocus.focus();
        else if (showedGoalEditor)
          document
            .querySelector<HTMLButtonElement>(
              '[aria-label="Edit goal"], [aria-label="Show goal controls"], [aria-label="Show goal details"]',
            )
            ?.focus();
      }
    };
  }, [closeSidebar, computerSidebarOverlay, sidebarOpen]);

  // Record content while open: closing clears it, and the lazy sidebar may not
  // have mounted the editor when the focus trap first runs.
  useEffect(() => {
    if (
      computerSidebarOverlay &&
      sidebarOpen &&
      sidebarContent &&
      "kind" in sidebarContent &&
      sidebarContent.kind === "goal"
    )
      computerDialogShowedGoalRef.current = true;
  }, [computerSidebarOverlay, sidebarContent, sidebarOpen]);

  // Simple logic: use route chatId if provided, otherwise generate new one
  const [chatId, setChatId] = useState<string>(() => {
    return routeChatId || uuidv4();
  });

  useEffect(() => {
    clearAgentApprovalSession();
  }, [chatId, clearAgentApprovalSession]);

  // Track whether this is an existing chat (prop-driven initially, flips after first completion)
  const [isExistingChat, setIsExistingChat] = useState<boolean>(!!routeChatId);
  const wasNewChatRef = useRef(!routeChatId);
  const shouldFetchMessages =
    isExistingChat && !isConvexAuthLoading && isConvexAuthenticated;

  // Refs to avoid stale closures in callbacks
  const isExistingChatRef = useLatestRef(isExistingChat);
  const chatModeRef = useLatestRef(chatMode);
  const subscriptionRef = useLatestRef(subscription);

  // Suppress transient "Chat Not Found" while server creates the chat
  const [awaitingServerChat, setAwaitingServerChat] = useState<boolean>(false);

  // Store streamed file metadata separately from AI SDK message state.
  const [tempChatFileDetails, setTempChatFileDetails] = useState<
    Map<string, FileDetails[]>
  >(new Map());

  // Use global state ref so streaming callback reads latest value
  const hasUserDismissedWarningRef = useLatestRef(
    hasUserDismissedRateLimitWarning,
  );
  // Use ref for todos to avoid stale closures in auto-send
  const todosRef = useLatestRef(todos);
  // Use ref for sandbox preference to avoid stale closures in auto-send
  const sandboxPreferenceRef = useLatestRef(sandboxPreference);
  const activeProjectIdRef = useLatestRef(activeProjectId);
  const agentPermissionModeRef = useLatestRef(agentPermissionMode);
  const requestSelectedModel = normalizeSelectedModelForSubscription(
    selectedModel,
    subscription,
  );
  const shouldUseAgentLong = shouldUseAgentLongForAgent({
    mode: chatMode,
    subscription,
    isTauri: isTauriEnvironment(),
  });
  // Use ref for model selection to avoid stale closures in auto-send
  const requestSelectedModelRef = useLatestRef(requestSelectedModel);
  const lastAppliedTodoOutputRef = useRef<string | null>(null);

  // Ensure we only initialize mode from server once per chat id
  const hasInitializedModeFromChatRef = useRef(false);
  const [initializedPredictionModeChatId, setInitializedPredictionModeChatId] =
    useState<string | null>(null);
  // Keep automatic sends blocked until the task's saved environment is applied.
  const [initializedSandboxChatId, setInitializedSandboxChatId] = useState<
    string | null
  >(null);
  const usesCloudRecovery =
    sandboxPreference === "e2b" && subscription !== "free";
  const [cloudConnectionFailure, setCloudConnectionFailure] = useState<{
    chatId: string;
    sequence: number;
  } | null>(null);
  // A remounted Cloud panel must verify fresh state before any send effect runs.
  const cloudRecoveryScope = useMemo(
    () => ({
      chatId,
      usesCloudRecovery,
      sequence: cloudConnectionFailure?.sequence,
    }),
    [chatId, usesCloudRecovery, cloudConnectionFailure?.sequence],
  );
  const cloudRecoveryAdmission = useCloudRecoveryAdmission(cloudRecoveryScope);
  const computerSendDisabledReason =
    isExistingChat && initializedSandboxChatId !== chatId
      ? "Loading the task's computer selection"
      : (usesCloudRecovery && cloudRecoveryAdmission.sendDisabledReason) ||
        connectionSendDisabledReason;
  const computerSendDisabledReasonRef = useCommittedRef(
    computerSendDisabledReason,
  );
  const hasInitializedModelRef = useRef(false);
  // Snapshot of the last picker values successfully persisted to the chat doc.
  // Seeded after init from chatData; subsequent picker toggles trigger a debounced patch.
  const persistedPrefsRef = useRef<{ model: string; mode: string } | null>(
    null,
  );

  // Use paginated query to load messages in batches of 14
  const paginatedMessages = usePaginatedQuery(
    api.messages.getMessagesByChatId,
    shouldFetchMessages ? { chatId } : "skip",
    { initialNumItems: 14 },
  );

  // Get chat data to retrieve title when loading existing chat
  const chatData = useQuery(
    api.chats.getChatByIdFromClient,
    shouldFetchMessages ? { id: chatId } : "skip",
  );

  const chatDataForCurrentChat =
    chatData && (chatData as any).id === chatId ? chatData : undefined;
  const [chatTitle, setStreamedTitle] = useStreamedChatTitle(
    chatDataForCurrentChat?.title,
  );
  const loadedChatDocumentId = chatDataForCurrentChat?._id;
  const lastRunFinishedAt = chatDataForCurrentChat?.last_run_finished_at;

  // Sync local chat state from URL (single source of truth)
  useLayoutEffect(() => {
    setStreamedTitle(null);
    lastAppliedTodoOutputRef.current = null;
    if (routeChatId) {
      setChatId(routeChatId);
      setIsExistingChat(true);
    } else {
      // Navigated to "/" (new chat) — reset to fresh state
      resetSandboxPreference();
      setChatId(uuidv4());
      setIsExistingChat(false);
      wasNewChatRef.current = true;
    }
  }, [routeChatId, setStreamedTitle, resetSandboxPreference]);

  useEffect(() => {
    if (!loadedChatDocumentId) return;
    markSidebarTaskVisited(
      chatId,
      Math.max(Date.now(), lastRunFinishedAt ?? 0),
    );
  }, [chatId, lastRunFinishedAt, loadedChatDocumentId]);

  const paginatedMessageResults =
    paginatedMessages.results &&
    paginatedMessages.results.length > 0 &&
    paginatedMessages.results.every(
      (message: any) => message.chat_id === chatId,
    )
      ? paginatedMessages.results
      : undefined;

  // Use the shared local sandbox connection subscription when validating a saved non-E2B sandbox.
  const storedSandboxType = (chatDataForCurrentChat as any)?.sandbox_type as
    string | undefined;

  const activeTriggerRunId = (chatDataForCurrentChat as any)
    ?.active_trigger_run_id as string | undefined;
  const persistedGoal = useQuery(
    api.agentGoals.get,
    chatDataForCurrentChat ? { chatId } : "skip",
  );
  // The pending request is its own persisted lifecycle. Do not gate it on the
  // run id: Convex can publish those fields in separate snapshots during
  // reload, and hiding an otherwise-pending request briefly shows the composer.
  const storedAgentApprovalRequest = getStoredAgentApprovalRequest(
    chatDataForCurrentChat,
  );
  const activeTriggerRunRef = useLatestRef(activeTriggerRunId);
  const hasLoadedCurrentChat = chatDataForCurrentChat !== undefined;

  useEffect(() => {
    if (
      !hasLoadedCurrentChat ||
      activeTriggerRunId ||
      storedAgentApprovalRequest
    ) {
      return;
    }
    clearAgentApprovalSession();
  }, [
    activeTriggerRunId,
    clearAgentApprovalSession,
    hasLoadedCurrentChat,
    storedAgentApprovalRequest,
  ]);

  // Convert paginated Convex messages to UI format for useChat and useAutoResume
  // Messages come from server in descending order (newest first from pagination); reverse for chronological order
  const serverMessages = useServerMessages(paginatedMessageResults);

  // State to prevent double-processing of queue
  const [isProcessingQueue, setIsProcessingQueue] = useState(false);
  // Ref to track when "Send Now" is actively processing to prevent auto-processing interference
  const isSendingNowRef = useRef(false);
  // Ref to track if user manually stopped - prevents auto-processing until new message submitted
  const hasManuallyStoppedRef = useRef(false);
  const recoveryDuringComputerLoad = useRef({ chatId, observed: false });
  useLayoutEffect(() => {
    if (recoveryDuringComputerLoad.current.chatId !== chatId)
      recoveryDuringComputerLoad.current = { chatId, observed: false };
    if (isExistingChat && initializedSandboxChatId !== chatId) {
      if (cloudRecoveryAdmission.recoveryStarted)
        recoveryDuringComputerLoad.current.observed = true;
      return;
    }
    const observedWhileLoading = recoveryDuringComputerLoad.current.observed;
    recoveryDuringComputerLoad.current.observed = false;
    if (
      !usesCloudRecovery ||
      (!cloudRecoveryAdmission.recoveryStarted && !observedWhileLoading)
    )
      return;
    // Recovery never resumes an old intent. Retain drafts/queued messages for
    // a fresh explicit send instead of releasing auto-continue after the fence.
    hasManuallyStoppedRef.current = true;
    try {
      if (sessionStorage.getItem("autoSendChatId") === chatId)
        sessionStorage.removeItem("autoSendChatId");
    } catch {
      // Storage may be disabled; the shared send guard still owns admission.
    }
  }, [
    usesCloudRecovery,
    cloudRecoveryAdmission.recoveryStarted,
    isExistingChat,
    initializedSandboxChatId,
    chatId,
  ]);
  const messagesRef = useRef<ChatMessage[]>([]);
  const isChatMountedRef = useRef(false);
  const browserStreamFinishedRef = useRef(false);
  const activeChatIdRef = useRef(chatId);
  const streamChatIdRef = useRef(chatId);
  const agentLongPartialSavesRef = useRef(createAgentPartialSaveQueue());
  const agentLongRunCorrelationRef = useRef<{
    runId: string;
    token: string;
  } | null>(null);
  const [agentLongRunId, setAgentLongRunId] = useState<string | null>(null);
  const agentLongRequestGenerationRef = useRef(0);
  const [agentLongSubmissionGeneration, setAgentLongSubmissionGeneration] =
    useState(0);
  const [terminalAgentRunUiState, setTerminalAgentRunUiState] = useState<{
    chatId: string;
    submissionGeneration: number;
    runId?: string;
  } | null>(null);
  const lastPersistedAgentRunRef = useRef<{
    chatId: string;
    runId?: string;
  }>({ chatId });
  const agentLongHasVisibleProgressRef = useRef(false);
  const agentLongRunFallbackAllowedRef = useRef(true);

  const markAgentRunUiTerminal = useCallback(
    (runId: string | undefined, requestGeneration: number | undefined) => {
      if (
        requestGeneration !== undefined &&
        requestGeneration !== agentLongRequestGenerationRef.current
      ) {
        return;
      }
      setTerminalAgentRunUiState({
        chatId,
        submissionGeneration: agentLongSubmissionGeneration,
        ...(runId ? { runId } : {}),
      });
    },
    [agentLongSubmissionGeneration, chatId],
  );

  useLayoutEffect(() => {
    activeChatIdRef.current = chatId;
    streamChatIdRef.current = chatId;
  }, [chatId]);

  useEffect(() => {
    isChatMountedRef.current = true;
    return () => {
      isChatMountedRef.current = false;
    };
  }, []);

  // Ref for setMessages — needed by DefaultChatTransport which is created before useChat returns
  const setMessagesRef = useRef<(messages: any[]) => void>(() => {});
  const handleAgentLongRunClosed = (runId: string) => {
    setAgentLongRunId((current) => (current === runId ? null : current));
  };

  // Default transport (OpenRouter) - stored in ref since it's created before useChat
  const browserHandoffAdmissionRef = useRef<{
    chatId: string;
    id: string;
    resolve: () => void;
  } | null>(null);
  type GoalAdmission = {
    chatId: string;
    id: string;
    resolve: () => void;
    error?: Error;
    aborted?: boolean;
    accepted: boolean;
  };
  const goalAdmissionRef = useRef<GoalAdmission | null>(null);
  const queuedAdmissionRef = useRef<(chatId: string, id: string) => void>(
    () => {},
  );
  const [performanceTracker] = useState(() => new ChatPerformanceTracker());
  useBrowserResponsiveness();
  const transportRef = useRef(
    new DefaultChatTransport({
      api: "/api/chat",
      fetch: async (input, init) => {
        const mode = chatModeRef.current;
        if (init?.method === "POST") {
          performanceTracker.start(
            activeChatIdRef.current,
            mode,
            messagesRef.current
              .filter((message) => message.role === "assistant")
              .map((message) => message.id),
          );
        }
        const isTauri = isTauriEnvironment();
        if (isLegacyDesktopAgentClient({ mode, isTauri })) {
          throw new ChatSDKError(
            "forbidden:chat",
            LEGACY_DESKTOP_AGENT_UPDATE_MESSAGE,
          );
        }
        const useTriggerAgent = shouldUseAgentLongForAgent({
          mode,
          subscription: subscriptionRef.current,
          isTauri,
        });
        if (useTriggerAgent) {
          // useChat reuses this fetch for both POST sendMessages and GET
          // reconnectToStream — dispatch on method.
          if (init?.method === "GET") {
            return resumeAgentLongStream(
              typeof input === "string" ? input : input.toString(),
              init,
              handleAgentLongRunClosed,
            );
          }
          // Reset the previous run before starting the request. Doing this in
          // the passive `submitted` effect can race with onRunStarted and
          // erase the new run metadata before completion reconciliation sees it.
          const requestGeneration = ++agentLongRequestGenerationRef.current;
          setAgentLongSubmissionGeneration((generation) => generation + 1);
          agentLongRunCorrelationRef.current = null;
          agentLongRunFallbackAllowedRef.current = false;
          setAgentLongRunId(null);
          agentLongHasVisibleProgressRef.current = false;
          agentLongMessageFingerprintRef.current = {
            chatId: activeChatIdRef.current,
            fingerprint: getAgentLongMessageProgressFingerprint(
              messagesRef.current,
            ),
          };
          const request =
            typeof init?.body === "string" ? JSON.parse(init.body) : undefined;
          const queuedMessageId = request?.messages?.at(-1)?.id;
          return fetchAgentLongStream(
            init,
            (run) => {
              const pendingGoal = goalAdmissionRef.current;
              if (
                pendingGoal &&
                pendingGoal.chatId === request?.chatId &&
                pendingGoal?.id === queuedMessageId
              )
                pendingGoal.resolve();
              if (
                requestGeneration !== agentLongRequestGenerationRef.current ||
                (run.chatId !== undefined &&
                  run.chatId !== activeChatIdRef.current)
              ) {
                return;
              }
              if (
                typeof request?.chatId === "string" &&
                typeof queuedMessageId === "string"
              ) {
                queuedAdmissionRef.current(request.chatId, queuedMessageId);
              }
              // Only expose the saved-task route after attachment staging and
              // user-message persistence have succeeded.
              if (
                finalizeNewChatRoute({
                  chatId: activeChatIdRef.current,
                  isAbort: false,
                  isExistingChat: isExistingChatRef.current,
                })
              ) {
                removeDraft("new");
                setIsExistingChat(true);
              }
              setAgentLongRunId(run.runId);
              if (run.runCorrelationToken) {
                agentLongRunCorrelationRef.current = {
                  runId: run.runId,
                  token: run.runCorrelationToken,
                };
              }
            },
            handleAgentLongRunClosed,
          );
        }
        if (init?.method !== "GET") {
          agentLongRequestGenerationRef.current += 1;
          setAgentLongSubmissionGeneration((generation) => generation + 1);
          agentLongRunCorrelationRef.current = null;
          agentLongRunFallbackAllowedRef.current = false;
          setAgentLongRunId(null);
        }
        // Reconnect for legacy "agent-long" chats normalised to "agent" mode
        // on load — route based on the URL (not on ref state) to be resilient
        // to stale refs.
        if (
          init?.method === "GET" &&
          [AGENT_RESUME_ENDPOINT, LEGACY_AGENT_RESUME_ENDPOINT].some(
            (resumeEndpoint) =>
              (typeof input === "string" ? input : input.toString()).includes(
                resumeEndpoint,
              ),
          )
        ) {
          return resumeAgentLongStream(
            typeof input === "string" ? input : input.toString(),
            init,
            handleAgentLongRunClosed,
          );
        }
        const requestChatId = activeChatIdRef.current;
        const requestGeneration = agentLongRequestGenerationRef.current;
        const response = await fetchWithErrorHandlers(input, init);
        // Ask persists its chat before returning a successful response. Expose
        // that route now so stopping the stream still leaves a reloadable task.
        if (
          init?.method === "POST" &&
          response.ok &&
          !init.signal?.aborted &&
          isChatMountedRef.current &&
          activeChatIdRef.current === requestChatId &&
          agentLongRequestGenerationRef.current === requestGeneration &&
          finalizeNewChatRoute({
            chatId: requestChatId,
            isAbort: false,
            isExistingChat: isExistingChatRef.current,
          })
        ) {
          removeDraft("new");
          setIsExistingChat(true);
        }
        return response;
      },
      prepareReconnectToStreamRequest: ({ id, api }) => {
        // Use the Trigger-backed Agent resume endpoint when there is a stored
        // trigger run (covers legacy "agent-long" chats normalised to "agent")
        // or when the current run is using Trigger.dev for agent mode.
        const useTriggerAgent = shouldUseAgentLongForAgent({
          mode: chatModeRef.current,
          subscription: subscriptionRef.current,
          isTauri: isTauriEnvironment(),
        });
        if (useTriggerAgent || !!activeTriggerRunRef.current) {
          return {
            api: `${AGENT_RESUME_ENDPOINT}?chatId=${encodeURIComponent(id)}`,
          };
        }
        return { api: `${api}/${id}/stream` };
      },
      prepareSendMessagesRequest: ({ id, messages, body }) => {
        const {
          messages: normalizedMessages,
          lastMessage,
          hasChanges,
        } = normalizeMessages(messages as ChatMessage[]);
        if (hasChanges) {
          setMessagesRef.current(normalizedMessages);
        }

        const stripUrlsFromMessages = (msgs: ChatMessage[]): ChatMessage[] => {
          const messagesWithoutHeartbeats =
            stripAgentLongHeartbeatPartsFromMessages(msgs);
          return messagesWithoutHeartbeats.map((msg) => {
            if (!msg.parts || msg.parts.length === 0) return msg;
            const strippedParts = msg.parts.map((part: any) => {
              if (part.type === "file" && "url" in part) {
                const { url, ...partWithoutUrl } = part;
                return partWithoutUrl;
              }
              return part;
            });
            return {
              ...msg,
              parts: strippedParts,
            };
          });
        };

        const messagesWithoutUrls = stripUrlsFromMessages(lastMessage);

        return {
          headers: getPostHogRequestHeaders(),
          body: {
            chatId: id,
            messages: messagesWithoutUrls,
            ...body,
            ...(activeProjectIdRef.current
              ? { projectId: activeProjectIdRef.current }
              : {}),
          },
        };
      },
    }),
  );

  const [completedPredictionTurn, setCompletedPredictionTurn] =
    useState<CompletedPredictionTurn | null>(null);
  const [interruptedPredictionTurn, setInterruptedPredictionTurn] = useState<{
    chatId: string;
  } | null>(null);

  const {
    messages: streamedMessages,
    sendMessage: sendMessageUnchecked,
    setMessages,
    status,
    stop,
    error,
    regenerate: regenerateUnchecked,
    resumeStream,
    clearError,
  } = useChat({
    id: chatId,
    messages: serverMessages,
    experimental_throttle: 150,
    generateId: () => uuidv4(),

    transport: transportRef.current,

    onData: (dataPart) => {
      if (!isChatMountedRef.current || activeChatIdRef.current !== chatId) {
        return;
      }
      if (dataPart.type === "data-agent-run-correlation") {
        const correlationData = dataPart.data as {
          chatId?: unknown;
          runId?: unknown;
          token?: unknown;
        };
        if (
          typeof correlationData.runId === "string" &&
          typeof correlationData.token === "string" &&
          (correlationData.chatId === undefined ||
            correlationData.chatId === chatId)
        ) {
          agentLongRunCorrelationRef.current = {
            runId: correlationData.runId,
            token: correlationData.token,
          };
          setAgentLongRunId(correlationData.runId);
        }
        return;
      }
      agentLongHasVisibleProgressRef.current = true;
      appendDataPart({ ...dataPart, __chatId: chatId });
      switch (dataPart.type) {
        case "data-cloud-connection-error": {
          setCloudConnectionFailure((prior) => ({
            chatId,
            sequence: (prior?.sequence ?? 0) + 1,
          }));
          const data = dataPart.data as { code?: unknown };
          if (data?.code === "timeout") {
            toast.error(
              "Cloud connection timed out. Your workspace is preserved. Try sending your message again shortly.",
              { duration: 10_000 },
            );
          }
          break;
        }
        case "data-agent-approval-session": {
          const approvalData = dataPart.data as {
            chatId?: unknown;
            sessionId?: unknown;
            publicAccessToken?: unknown;
          };
          if (
            typeof approvalData.sessionId === "string" &&
            typeof approvalData.publicAccessToken === "string" &&
            (approvalData.chatId === undefined ||
              approvalData.chatId === chatId)
          ) {
            setAgentApprovalSession({
              chatId,
              sessionId: approvalData.sessionId,
              publicAccessToken: approvalData.publicAccessToken,
            });
          }
          break;
        }
        case "data-upload-status": {
          const uploadData = dataPart.data as {
            message: string;
            isUploading: boolean;
          };
          dispatchStreaming({
            type: "SET_UPLOAD_STATUS",
            payload: uploadData.isUploading ? uploadData : null,
          });
          break;
        }
        case "data-summarization": {
          const summaryData = dataPart.data as {
            status: "started" | "completed";
            message: string;
            startedAt?: number;
          };
          dispatchStreaming({
            type: "SET_SUMMARIZATION_STATUS",
            payload: summaryData.status === "started" ? summaryData : null,
          });
          break;
        }
        case "data-rate-limit-warning": {
          const rawData = dataPart.data as Record<string, unknown>;
          const parsed = parseRateLimitWarning(rawData, {
            hasUserDismissed: hasUserDismissedWarningRef.current,
          });
          if (parsed) {
            dispatchStreaming({
              type: "SET_RATE_LIMIT_WARNING",
              payload: parsed,
            });
          }
          break;
        }
        case "data-file-metadata": {
          const fileData = dataPart.data as {
            messageId: string;
            fileDetails: FileDetails[];
          };
          // Merge into parallel state (outside AI SDK control)
          // Uses merge-with-dedup so incremental events (per-file) and
          // the onFinish batch event both work without duplicates
          setTempChatFileDetails((prev) => {
            const next = new Map(prev);
            const existing = next.get(fileData.messageId) || [];
            const existingIds = new Set(
              existing.map((f: FileDetails) => f.fileId),
            );
            const newFiles = fileData.fileDetails.filter(
              (f: FileDetails) => !existingIds.has(f.fileId),
            );
            next.set(fileData.messageId, [...existing, ...newFiles]);
            return next;
          });
          break;
        }
        case "data-title": {
          const titleData = dataPart.data as { chatTitle?: string };
          if (titleData?.chatTitle) {
            setStreamedTitle(titleData.chatTitle);
          }
          break;
        }
        case "data-sandbox-fallback": {
          const fallbackData = dataPart.data as {
            occurred: boolean;
            reason: "connection_unavailable" | "no_local_connections";
            requestedPreference: string;
            actualSandbox: string;
            actualSandboxName?: string;
          };

          // Skip fallback notifications for Tauri — the server-side health check
          // hits its own localhost, not the user's desktop, so it consistently
          // reports false disconnects. The frontend already validated Tauri availability.
          if (fallbackData.requestedPreference === "tauri") {
            break;
          }

          // Update sandbox preference to match actual sandbox used
          setSandboxPreference(fallbackData.actualSandbox, { remember: false });

          // Show toast notification
          const message =
            fallbackData.reason === "no_local_connections"
              ? `Local sandbox unavailable. Using ${fallbackData.actualSandboxName || "Cloud"}; host files, drives, localhost, and private networks are unavailable until local reconnects.`
              : `Selected sandbox disconnected. Switched to ${fallbackData.actualSandboxName || "Cloud"}. Commands run there, not on the selected host.`;
          toast.info(message, { duration: 8000 });
          break;
        }
      }
    },
    onFinish: ({ isAbort, isError, message, messages: finishedMessages }) => {
      if (isAbort && goalAdmissionRef.current?.chatId === chatId)
        goalAdmissionRef.current.aborted = true;
      performanceTracker.setOutcome(
        isError ? "error" : isAbort ? "aborted" : "completed",
      );
      if (!isChatMountedRef.current || activeChatIdRef.current !== chatId) {
        return;
      }
      // useChat forwards old Chat instances to the latest callback after
      // navigation. Its event history still belongs to the originating task.
      // Check membership rather than the newest user ID: throttled visible
      // messages may lag a legitimate abort before its assistant is appended.
      const visibleUser = messagesRef.current.findLast(
        (item) => item.role === "user",
      );
      if (
        !visibleUser ||
        finishedMessages?.some((item) => item.id === visibleUser.id)
      ) {
        setCompletedPredictionTurn(
          !isAbort && !isError ? { chatId, messageId: message.id } : null,
        );
        setInterruptedPredictionTurn(isAbort || isError ? { chatId } : null);
      }
      browserStreamFinishedRef.current = true;
      agentLongRunCorrelationRef.current = null;
      agentLongRunFallbackAllowedRef.current = false;
      setIsAutoResuming(false);
      setAwaitingServerChat(false);
      dispatchStreaming({ type: "RESET_ON_FINISH" });

      if (
        finalizeNewChatRoute({
          chatId,
          isAbort,
          isError,
          isExistingChat: isExistingChatRef.current,
        })
      ) {
        removeDraft("new");
        setIsExistingChat(true);
      }
    },
    onError: (error) => {
      performanceTracker.setOutcome("error");
      if (!isChatMountedRef.current || activeChatIdRef.current !== chatId) {
        return;
      }
      browserStreamFinishedRef.current = true;
      agentLongRunCorrelationRef.current = null;
      agentLongRunFallbackAllowedRef.current = false;
      setIsAutoResuming(false);
      setAwaitingServerChat(false);
      dispatchStreaming({ type: "RESET_ON_FINISH" });
      const structuredStreamError = deserializeChatSDKErrorFromStream(error);
      const displayError = structuredStreamError ?? error;
      if (
        goalAdmissionRef.current?.chatId === chatId &&
        !goalAdmissionRef.current.accepted
      ) {
        goalAdmissionRef.current.error =
          displayError instanceof ChatSDKError
            ? new Error(
                formatTaskUiCopy(
                  typeof displayError.cause === "string"
                    ? displayError.cause
                    : displayError.message,
                ),
              )
            : displayError;
        return; // The composer reports this admission error and preserves its draft.
      }
      if (displayError instanceof ChatSDKError) {
        const errorMessage =
          typeof displayError.cause === "string"
            ? displayError.cause
            : displayError.message;
        if (displayError.type !== "rate_limit") {
          toast.error(formatTaskUiCopy(errorMessage));
        }
      } else if (isMobile && displayError.name !== "AbortError") {
        toast.error(
          formatTaskUiCopy(displayError.message || "An error occurred."),
        );
      }
    },
  });

  const messages = useMemo(
    () => normalizeStreamedRecoveryMessages(streamedMessages),
    [streamedMessages],
  );

  useEffect(() => {
    if (status === "submitted" || status === "streaming" || status === "error")
      setCompletedPredictionTurn(null);
  }, [chatId, status]);

  useChatPerformance({
    tracker: performanceTracker,
    chatId,
    messages,
    status,
    runId: agentLongRunId,
  });

  // Guard the shared dispatch boundary as well as the UI. Forks, retries,
  // auto-continue, and queued sends must retain the selected environment.
  const sendMessage = useCallback<typeof sendMessageUnchecked>(
    (...args) => {
      const reason = computerSendDisabledReasonRef.current;
      if (reason) return Promise.reject(new Error(reason));
      return sendMessageUnchecked(...args);
    },
    [sendMessageUnchecked, computerSendDisabledReasonRef],
  );
  const sendGoalMessage = useCallback(
    async (
      message: {
        text?: string;
        files?: FileUIPart[];
        metadata?: ChatMessage["metadata"];
      },
      options?: { body?: Record<string, unknown> },
    ) => {
      if (goalAdmissionRef.current)
        throw new Error("A goal is already starting.");
      const id = uuidv4();
      let accepted = false;
      let resolveAdmission!: () => void;
      const admitted = new Promise<void>((resolve) => {
        resolveAdmission = resolve;
      });
      const pending: GoalAdmission = {
        chatId,
        id,
        accepted: false,
        resolve: () => {
          accepted = true;
          pending.accepted = true;
          resolveAdmission();
        },
      };
      goalAdmissionRef.current = pending;
      try {
        // The SDK generates a new ID for text-form sends; use explicit parts so
        // admission can acknowledge this exact message, including attachments.
        const sending = sendMessage(
          {
            id,
            role: "user",
            parts: [
              ...(message.files ?? []),
              ...(message.text
                ? [{ type: "text" as const, text: message.text }]
                : []),
            ],
            metadata: message.metadata,
          },
          options,
        );
        await Promise.race([sending, admitted]);
        if (!accepted) {
          if (pending.aborted)
            throw new DOMException("Goal submission stopped", "AbortError");
          throw (
            pending.error ??
            new Error("Goal could not start. Your draft is saved; try again.")
          );
        }
      } catch (error) {
        if (
          isChatMountedRef.current &&
          activeChatIdRef.current === chatId &&
          !(error instanceof Error && error.name === "AbortError")
        ) {
          // Failed requests can leave an optimistic bubble. Remove it only after
          // confirming it was never persisted; unknown outcomes stay visible.
          let persistenceTimeout: ReturnType<typeof setTimeout> | undefined;
          let persisted: boolean | undefined;
          try {
            persisted = await Promise.race([
              convex
                .query(api.messages.isUserMessagePersisted, {
                  chatId,
                  messageId: id,
                })
                .catch(() => undefined),
              new Promise<undefined>((resolve) => {
                persistenceTimeout = setTimeout(
                  () => resolve(undefined),
                  5_000,
                );
              }),
            ]);
          } finally {
            clearTimeout(persistenceTimeout);
          }
          if (isChatMountedRef.current && activeChatIdRef.current === chatId) {
            if (persisted === false)
              setMessages((current) =>
                current.filter((item) => item.id !== id),
              );
            clearError?.();
          }
        }
        throw error;
      } finally {
        if (goalAdmissionRef.current === pending)
          goalAdmissionRef.current = null;
      }
    },
    [chatId, sendMessage, convex, setMessages, clearError],
  );
  const regenerate = useCallback<typeof regenerateUnchecked>(
    (...args) => {
      const reason = computerSendDisabledReasonRef.current;
      if (reason) return Promise.reject(new Error(reason));
      return regenerateUnchecked(...args);
    },
    [regenerateUnchecked, computerSendDisabledReasonRef],
  );

  const { send: sendQueuedMessage, accept: acceptQueuedMessage } =
    useQueuedMessageDelivery({
      chatId,
      messages,
      queue: messageQueue,
      enabled: shouldUseAgentLong,
      isStopped: () => hasManuallyStoppedRef.current,
      getRequestGeneration: () => agentLongRequestGenerationRef.current,
      sendDisabledReason: computerSendDisabledReason,
      sendMessage,
      resumeStream,
      remove: removeQueuedMessage,
      setDelivery: setQueuedMessageDelivery,
    });
  useLayoutEffect(() => {
    queuedAdmissionRef.current = (admittedChatId, id) => {
      acceptQueuedMessage(admittedChatId, id);
      const pending = browserHandoffAdmissionRef.current;
      if (pending?.chatId === admittedChatId && pending.id === id)
        pending.resolve();
    };
  }, [acceptQueuedMessage]);

  const continueBrowserHandoff = useCallback(
    async (message: { id: string; text: string }) => {
      if (browserHandoffAdmissionRef.current)
        throw new Error("A continuation is already starting.");
      if (computerSendDisabledReasonRef.current)
        throw new Error(computerSendDisabledReasonRef.current);
      // Keep the private saved note immutable; this is only a restart signal.
      const continuationId = `${message.id}-continue`;
      let accepted = false;
      const admitted = new Promise<void>((resolve) => {
        browserHandoffAdmissionRef.current = {
          chatId,
          id: continuationId,
          resolve: () => {
            accepted = true;
            resolve();
          },
        };
      });
      try {
        hasManuallyStoppedRef.current = false;
        setChatMode("agent");
        chatModeRef.current = "agent";
        const existing = messagesRef.current.some(
          (item) => item.id === continuationId,
        );
        const sending = sendMessage(
          {
            id: continuationId,
            role: "user",
            metadata: { isAutoContinue: true },
            parts: [{ type: "text", text: "Continue after browser takeover." }],
            ...(existing ? { messageId: continuationId } : {}),
          },
          {
            body: {
              mode: "agent",
              isAutoContinue: true,
              todos: todosRef.current,
              sandboxPreference: sandboxPreferenceRef.current,
              agentPermissionMode: agentPermissionModeRef.current,
              selectedModel: requestSelectedModelRef.current,
            },
          },
        );
        await Promise.race([sending, admitted]);
        if (!accepted)
          throw new Error(
            "Your note is saved, but the Agent could not start. Try Send and continue again.",
          );
      } finally {
        browserHandoffAdmissionRef.current = null;
      }
    },
    [
      chatId,
      sendMessage,
      setChatMode,
      chatModeRef,
      sandboxPreferenceRef,
      computerSendDisabledReasonRef,
      messagesRef,
      todosRef,
      agentPermissionModeRef,
      requestSelectedModelRef,
    ],
  );

  const previousChatStatusRef = useRef<typeof status | null>(null);
  useEffect(() => {
    previousChatStatusRef.current = null;
  }, [chatId]);
  useEffect(() => {
    const previousStatus = previousChatStatusRef.current;
    if (previousStatus === status) return;

    addAuthenticatedExceptionStep("chat_status_changed", {
      previous_status: previousStatus ?? "initial",
      status,
      mode: chatModeRef.current,
      subscription: subscriptionRef.current,
      transport: shouldUseAgentLong ? "trigger" : "browser",
      existing_chat: isExistingChatRef.current,
      message_count: messagesRef.current.length,
    });
    previousChatStatusRef.current = status;
  }, [
    chatModeRef,
    isExistingChatRef,
    shouldUseAgentLong,
    status,
    subscriptionRef,
  ]);

  // Keep refs in sync so closures read latest values
  setMessagesRef.current = setMessages;
  messagesRef.current = messages;

  const messagesChatIdRef = useRef(chatId);
  useLayoutEffect(() => {
    if (messagesChatIdRef.current === chatId) return;
    messagesChatIdRef.current = chatId;
    messagesRef.current = serverMessages;
    setMessages(serverMessages);
    setTempChatFileDetails(new Map());
  }, [chatId, serverMessages, setMessages]);

  useEffect(() => {
    const shouldApplyOutput =
      status === "streaming" || status === "submitted" || !shouldFetchMessages;
    if (!shouldApplyOutput) return;

    const latestTodoOutput = getLatestTodoWriteOutput(
      messages as ChatMessage[],
    );
    if (!latestTodoOutput) return;
    if (lastAppliedTodoOutputRef.current === latestTodoOutput.key) return;

    lastAppliedTodoOutputRef.current = latestTodoOutput.key;
    setTodos(latestTodoOutput.todos);
  }, [messages, setTodos, shouldFetchMessages, status]);

  // Ref keeps asynchronous completion and cancellation callbacks on the latest status.
  const statusRef = useRef(status);
  statusRef.current = status;
  const stopRef = useRef(stop);
  stopRef.current = stop;
  const shouldUseAgentLongForCurrentChat =
    shouldUseAgentLong &&
    (!isExistingChat ||
      (!!chatDataForCurrentChat &&
        (!!chatDataForCurrentChat.active_trigger_run_id ||
          (chatDataForCurrentChat as any).default_model_slug === "agent" ||
          (chatDataForCurrentChat as any).default_model_slug ===
            "agent-long")));
  const shouldUseAgentLongForCurrentChatRef = useRef(
    shouldUseAgentLongForCurrentChat,
  );
  shouldUseAgentLongForCurrentChatRef.current =
    shouldUseAgentLongForCurrentChat;
  const stopActiveBrowserStream = useCallback(
    (nextChatId?: string) => {
      const streamChatId = streamChatIdRef.current;
      if (nextChatId) {
        // Invalidate terminal callbacks before either cancellation path can
        // finish synchronously.
        activeChatIdRef.current = nextChatId;
      }
      cancelAgentLongRealtimeStreams(streamChatId);
      const streamAlreadyFinished =
        shouldUseAgentLongForCurrentChatRef.current &&
        browserStreamFinishedRef.current;
      if (
        !streamAlreadyFinished &&
        (statusRef.current === "streaming" || statusRef.current === "submitted")
      ) {
        stopRef.current();
      }
      clearDataStream();
      setIsAutoResuming(false);
    },
    [clearDataStream, setIsAutoResuming],
  );

  useEffect(() => {
    setChatNavigationHandler(stopActiveBrowserStream);
    return () => setChatNavigationHandler(null);
  }, [setChatNavigationHandler, stopActiveBrowserStream]);

  const saveAgentLongPartialSnapshot = useCallback(
    (clientReason: string) => {
      const runCorrelation = agentLongRunCorrelationRef.current;
      if (!runCorrelation) return;
      const partialMessage = getLatestAgentLongAssistantMessageForPartialSave(
        messagesRef.current,
        runCorrelation.runId,
      );
      if (!partialMessage) return;

      const saveKey = `${chatId}:${partialMessage.id}`;
      // Capture the request now: the correlation ref is cleared on completion.
      const requestBody = JSON.stringify({
        chatId,
        message: partialMessage,
        generationStartedAt: partialMessage.generationStartedAt,
        generationTimeMs: partialMessage.generationTimeMs,
        clientReason,
        triggerRunId: runCorrelation.runId,
        runCorrelationToken: runCorrelation.token,
      });
      return agentLongPartialSavesRef.current.save(
        chatId,
        saveKey,
        async () => {
          return fetch(AGENT_PARTIAL_SAVE_ENDPOINT, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: requestBody,
          });
        },
      );
    },
    [chatId],
  );

  useEffect(() => {
    if (status === "submitted") {
      agentLongHasVisibleProgressRef.current = false;
      agentLongMessageFingerprintRef.current = {
        chatId,
        fingerprint: getAgentLongMessageProgressFingerprint(
          messagesRef.current,
        ),
      };
    }
    if (
      shouldUseAgentLongForCurrentChat &&
      (status === "streaming" || status === "submitted")
    ) {
      browserStreamFinishedRef.current = false;
    }
  }, [chatId, shouldUseAgentLongForCurrentChat, status]);

  useEffect(() => {
    if (lastPersistedAgentRunRef.current.chatId !== chatId) {
      lastPersistedAgentRunRef.current = { chatId };
    }

    if (activeTriggerRunId) {
      lastPersistedAgentRunRef.current = {
        chatId,
        runId: activeTriggerRunId,
      };
      return;
    }

    if (status !== "streaming" && status !== "submitted") {
      lastPersistedAgentRunRef.current = { chatId };
    }
  }, [activeTriggerRunId, chatId, status]);

  useEffect(() => {
    const isAgentLongDoubleCloseNoise = (message: unknown) =>
      shouldUseAgentLongForCurrentChatRef.current &&
      typeof message === "string" &&
      (message.includes("Cannot close an errored readable stream") ||
        message.includes(
          "ReadableStreamDefaultController is not in a state where it can be closed",
        ) ||
        message.includes("Cannot close a stream that is already closed"));

    const suppressAgentLongDoubleCloseNoise = (event: ErrorEvent) => {
      if (isAgentLongDoubleCloseNoise(getSafeErrorEventMessage(event))) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    };

    const previousOnError = window.onerror;
    const suppressAgentLongDoubleCloseOnError: OnErrorEventHandler = (
      message,
      source,
      lineno,
      colno,
      error,
    ) => {
      if (isAgentLongDoubleCloseNoise(message)) return true;
      if (typeof previousOnError === "function") {
        try {
          return previousOnError(message, source, lineno, colno, error);
        } catch {
          return false;
        }
      }
      return false;
    };
    window.onerror = suppressAgentLongDoubleCloseOnError;

    window.addEventListener("error", suppressAgentLongDoubleCloseNoise, true);
    return () => {
      if (window.onerror === suppressAgentLongDoubleCloseOnError) {
        window.onerror = previousOnError;
      }
      window.removeEventListener(
        "error",
        suppressAgentLongDoubleCloseNoise,
        true,
      );
    };
  }, []);

  useEffect(() => {
    agentLongRequestGenerationRef.current += 1;
    agentLongRunCorrelationRef.current = null;
    agentLongRunFallbackAllowedRef.current = true;
    setAgentLongRunId(null);
    agentLongHasVisibleProgressRef.current = false;
    clearDataStream();
    setIsAutoResuming(false);
    dispatchStreaming({ type: "RESET_ON_CHAT_CHANGE" });
  }, [chatId, clearDataStream, setIsAutoResuming]);

  useEffect(() => {
    return () => {
      stopActiveBrowserStream();
    };
  }, [stopActiveBrowserStream]);

  const agentLongMessageFingerprint =
    getAgentLongMessageProgressFingerprint(messages);
  const agentLongMessageFingerprintRef = useRef({
    chatId,
    fingerprint: agentLongMessageFingerprint,
  });

  useEffect(() => {
    if (agentLongMessageFingerprintRef.current.chatId !== chatId) {
      agentLongMessageFingerprintRef.current = {
        chatId,
        fingerprint: agentLongMessageFingerprint,
      };
      return;
    }
    if (
      agentLongMessageFingerprintRef.current.fingerprint ===
      agentLongMessageFingerprint
    ) {
      return;
    }
    agentLongMessageFingerprintRef.current = {
      chatId,
      fingerprint: agentLongMessageFingerprint,
    };
    agentLongHasVisibleProgressRef.current = true;
  }, [agentLongMessageFingerprint, chatId]);

  // Trigger.dev can finish and persist an Agent answer even if the realtime
  // UI stream never delivers a terminal chunk to useChat. Reconcile against
  // the app's authenticated resume endpoint so the first message in a new
  // chat can leave "Working..." even before chatData is subscribed.
  useEffect(() => {
    const requestGeneration = agentLongRequestGenerationRef.current;
    const trackedAgentLongRunId =
      agentLongRunId ??
      agentLongRunCorrelationRef.current?.runId ??
      (agentLongRunFallbackAllowedRef.current
        ? (activeTriggerRunRef.current ??
          (lastPersistedAgentRunRef.current.chatId === chatId
            ? lastPersistedAgentRunRef.current.runId
            : null))
        : null);
    if (
      (status !== "streaming" && status !== "submitted") ||
      (!shouldUseAgentLongForCurrentChat && !trackedAgentLongRunId)
    ) {
      return;
    }

    let stopped = false;
    let pollTimeout: ReturnType<typeof setTimeout> | undefined;
    let finishTimeout: ReturnType<typeof setTimeout> | undefined;
    let isCompletionCheckInFlight = false;
    const abortController = new AbortController();

    const finishLocally = () => {
      if (stopped || activeChatIdRef.current !== chatId) return;
      stopped = true;
      agentLongRunCorrelationRef.current = null;
      agentLongRunFallbackAllowedRef.current = false;
      setAgentLongRunId(null);
      stopRef.current();
      setIsAutoResuming(false);
      setAwaitingServerChat(false);
      dispatchStreaming({ type: "RESET_ON_FINISH" });

      if (
        finalizeNewChatRoute({
          chatId,
          isAbort: false,
          isExistingChat: isExistingChatRef.current,
        })
      ) {
        removeDraft("new");
        setIsExistingChat(true);
      }
    };

    const scheduleFinishLocally = () => {
      if (stopped || finishTimeout !== undefined) return;
      markAgentRunUiTerminal(
        trackedAgentLongRunId ?? undefined,
        requestGeneration,
      );
      void saveAgentLongPartialSnapshot("resume_terminal_204")?.catch(() => {
        // Retain the failed request so an explicit recovery can retry the save.
      });

      // The transport also polls the status endpoint and can deliver a
      // synthetic finish after a terminal status. Give it a brief chance to
      // close normally before falling back to stop(), which aborts the stream.
      const stopGraceMs = agentLongHasVisibleProgressRef.current
        ? AGENT_LONG_COMPLETION_STOP_GRACE_MS
        : 0;
      finishTimeout = setTimeout(() => {
        finishTimeout = undefined;
        if (
          statusRef.current === "streaming" ||
          statusRef.current === "submitted"
        ) {
          finishLocally();
        }
      }, stopGraceMs);
    };

    const checkRunCompletion = async () => {
      if (isCompletionCheckInFlight) return;

      const runId =
        trackedAgentLongRunId ??
        agentLongRunCorrelationRef.current?.runId ??
        (agentLongRunFallbackAllowedRef.current
          ? activeTriggerRunRef.current
          : null);
      if (!runId) return;

      isCompletionCheckInFlight = true;
      const requestAbortController = new AbortController();
      const abortRequest = () => requestAbortController.abort();
      abortController.signal.addEventListener("abort", abortRequest, {
        once: true,
      });
      const requestTimeout = setTimeout(
        abortRequest,
        AGENT_LONG_COMPLETION_REQUEST_TIMEOUT_MS,
      );
      try {
        const response = await fetch(AGENT_STATUS_ENDPOINT, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chatId, runId }),
          signal: requestAbortController.signal,
        });
        if (response.status === 404) {
          scheduleFinishLocally();
          return;
        }
        if (!response.ok) return;

        const payload = (await response.json()) as { terminal?: unknown };
        if (payload.terminal === true) {
          scheduleFinishLocally();
        }
      } catch (error) {
        if ((error as Error).name !== "AbortError") {
          // Ignore transient polling failures; the underlying stream still owns
          // the visible error state.
        }
      } finally {
        clearTimeout(requestTimeout);
        abortController.signal.removeEventListener("abort", abortRequest);
        isCompletionCheckInFlight = false;
      }
    };

    const scheduleCompletionCheck = (delayMs: number) => {
      pollTimeout = setTimeout(async () => {
        await checkRunCompletion();
        if (stopped) return;
        scheduleCompletionCheck(
          agentLongHasVisibleProgressRef.current
            ? AGENT_LONG_ACTIVE_COMPLETION_POLL_INTERVAL_MS
            : AGENT_LONG_SILENT_COMPLETION_POLL_INTERVAL_MS,
        );
      }, delayMs);
    };
    const persistedRunDetached =
      !activeTriggerRunId &&
      lastPersistedAgentRunRef.current.chatId === chatId &&
      lastPersistedAgentRunRef.current.runId === trackedAgentLongRunId;
    if (persistedRunDetached) {
      scheduleFinishLocally();
    } else {
      scheduleCompletionCheck(AGENT_LONG_SILENT_COMPLETION_POLL_DELAY_MS);
    }

    return () => {
      stopped = true;
      abortController.abort();
      if (pollTimeout !== undefined) {
        clearTimeout(pollTimeout);
      }
      if (finishTimeout !== undefined) {
        clearTimeout(finishTimeout);
      }
    };
  }, [
    activeTriggerRunRef,
    activeTriggerRunId,
    agentLongSubmissionGeneration,
    agentLongRunId,
    chatId,
    isExistingChatRef,
    markAgentRunUiTerminal,
    setIsAutoResuming,
    saveAgentLongPartialSnapshot,
    shouldUseAgentLongForCurrentChat,
    status,
  ]);

  // Ref bridge: StreamEffects exposes resetAutoContinueCount here
  const resetAutoContinueRef = useRef<(() => void) | null>(null);
  const resetAutoContinueCount = useCallback(() => {
    resetAutoContinueRef.current?.();
  }, []);

  // Register a reset function with global state so initializeNewChat can call it
  useEffect(() => {
    const reset = () => {
      const nextChatId = uuidv4();
      stopActiveBrowserStream(nextChatId);
      setMessages([]);
      setChatId(nextChatId);
      setIsExistingChat(false);
      wasNewChatRef.current = true;
      setTodos([]);
      setStreamedTitle(null);
      setAwaitingServerChat(false);
      dispatchStreaming({ type: "RESET_ON_FINISH" });
      setHasUserDismissedRateLimitWarning(false);
      resetAutoContinueCount();
    };
    setChatReset(reset);
    return () => setChatReset(null);
  }, [
    setChatReset,
    setHasUserDismissedRateLimitWarning,
    setMessages,
    setStreamedTitle,
    setTodos,
    resetAutoContinueCount,
    stopActiveBrowserStream,
  ]);

  // Reset the one-time initializer when chat changes (must come before chatData effect to handle cached data)
  useEffect(() => {
    hasInitializedModeFromChatRef.current = false;
    hasInitializedModelRef.current = false;
    persistedPrefsRef.current = null;
  }, [chatId]);

  // Set chat title and load todos when chat data is loaded
  useEffect(() => {
    // Only process when we intend to fetch for an existing chat
    if (!shouldFetchMessages) {
      return;
    }

    const dataId = (chatData as any)?.id as string | undefined;
    // Ignore when no data or data is stale (doesn't match current chatId)
    if (!chatData || dataId !== chatId) {
      return;
    }

    // Load todos from the chat data if they exist.
    if (chatData.todos) {
      // setTodos signature expects Todo[], so derive the new array first
      const nextTodos: Todo[] = (() => {
        const incoming: Todo[] = chatData.todos as Todo[];
        if (!incoming || incoming.length === 0) return [] as Todo[];

        // Split by assistant attribution
        const incomingAssistant: Todo[] = incoming.filter((t: Todo) =>
          Boolean(t.sourceMessageId),
        );
        const incomingManual: Todo[] = incoming.filter(
          (t: Todo) => !t.sourceMessageId,
        );

        // Replace assistant todos entirely with incoming assistant todos and keep incoming manual ones as-is
        return [...incomingAssistant, ...incomingManual] as Todo[];
      })();

      setTodos(nextTodos);
    } else {
      setTodos([]);
    }
    // Server has responded for this chat id; stop suppressing not-found state
    setAwaitingServerChat(false);
    // Initialize mode from server once per chat id (only for existing chats)
    if (!hasInitializedModeFromChatRef.current && isExistingChat) {
      hasInitializedModeFromChatRef.current = true;
      const slug = (chatData as any).default_model_slug;
      if (slug === "ask" || slug === "agent") {
        setChatMode(slug);
      } else if (slug === "agent-long") {
        // Legacy chats stored as agent-long map to agent mode
        setChatMode("agent");
      }
      setInitializedPredictionModeChatId(chatId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chatData, setTodos, shouldFetchMessages, isExistingChat, chatId]);

  // Restore the task's environment independently of connection availability.
  // A missing computer must reconnect or be explicitly replaced by the user.
  useEffect(() => {
    if (initializedSandboxChatId === chatId || !isExistingChat) return;

    const dataId = (chatData as any)?.id as string | undefined;
    if (!chatData || dataId !== chatId) return;

    if (!storedSandboxType && wasNewChatRef.current) {
      // The newly created chat already sent the current environment in its request.
      setInitializedSandboxChatId(chatId);
      return;
    }

    const restoredPreference =
      storedSandboxType === "tauri" ? "desktop" : storedSandboxType || "e2b";
    // Only an unspecified/Cloud default needs discovery. Saved computers must
    // restore immediately, even when unavailable or still being discovered.
    if (
      freeDesktopAgentOnlyActive &&
      restoredPreference === "e2b" &&
      !desktopBridgeActive &&
      localConnections === undefined
    ) {
      return;
    }
    // Resolve free Desktop's local default before committing the selection.
    // Restoring Cloud first creates a false unavailable → available transition.
    setSandboxPreference(
      freeDesktopAgentOnlyActive
        ? resolveFreeDesktopSandboxPreference({
            sandboxPreference: restoredPreference,
            desktopBridgeActive,
            localConnections,
          })
        : restoredPreference,
      { remember: false },
    );
    setInitializedSandboxChatId(chatId);
  }, [
    chatData,
    storedSandboxType,
    isExistingChat,
    chatId,
    initializedSandboxChatId,
    setSandboxPreference,
    freeDesktopAgentOnlyActive,
    desktopBridgeActive,
    localConnections,
  ]);

  // Initialize model selection from chat data
  useEffect(() => {
    if (hasInitializedModelRef.current || !isExistingChat) return;
    const dataId = (chatData as any)?.id as string | undefined;
    if (!chatData || dataId !== chatId) return;
    const savedModel = (chatData as any).selected_model as string | undefined;
    hasInitializedModelRef.current = true;
    const coerced = coerceSelectedModel(savedModel ?? null);
    if (coerced) {
      setSelectedModel(coerced);
    }
  }, [chatData, isExistingChat, chatId, setSelectedModel]);

  // Persist picker preferences (model + mode) when the user toggles them.
  // Debounced so quick toggles don't spam Convex; baseline is seeded from the
  // chat's stored values so the post-init render doesn't trigger a no-op write.
  const updateChatPreferences = useMutation(api.chats.updateChatPreferences);
  useEffect(() => {
    if (!isExistingChat || !chatData) return;
    const dataId = (chatData as any).id as string | undefined;
    if (dataId !== chatId) return;
    if (
      !hasInitializedModelRef.current ||
      !hasInitializedModeFromChatRef.current
    ) {
      return;
    }

    if (persistedPrefsRef.current === null) {
      const savedModel = (chatData as any).selected_model as string | undefined;
      const savedMode = (chatData as any).default_model_slug as
        string | undefined;
      persistedPrefsRef.current = {
        model: savedModel ?? selectedModel,
        mode: savedMode ?? chatMode,
      };
    }

    const last = persistedPrefsRef.current;
    if (last.model === selectedModel && last.mode === chatMode) return;

    // `cancelled` guards both branches: clearTimeout cancels before the
    // request fires, and the flag prevents an in-flight request from writing
    // its (stale) snapshot to persistedPrefsRef after the user has already
    // navigated to a different chat or toggled again.
    let cancelled = false;
    const handle = setTimeout(() => {
      if (cancelled) return;
      const snapshot = { model: selectedModel, mode: chatMode };
      void updateChatPreferences({
        id: chatId,
        selectedModel,
        mode: chatMode,
      })
        .then(() => {
          if (cancelled) return;
          persistedPrefsRef.current = snapshot;
        })
        .catch(() => {
          // Silent — picker state in memory is still correct; backend will
          // re-persist on next send via updateChat.
        });
    }, 500);
    return () => {
      cancelled = true;
      clearTimeout(handle);
    };
  }, [
    selectedModel,
    chatMode,
    isExistingChat,
    chatId,
    chatData,
    updateChatPreferences,
  ]);

  // Sync Convex real-time data with useChat messages.
  // Guards against BOTH "streaming" and "submitted" statuses to prevent
  // Convex real-time updates from overwriting useChat's in-flight state, then
  // reruns when the status settles so a completion persisted during streaming
  // is not left unapplied.
  // Without the "submitted" guard, a race condition occurs in production:
  // Convex receives the user message (via handleInitialChatAndUserMessage)
  // and pushes a subscription update before the first streaming chunk arrives,
  // resetting useChat's messages and causing an empty AI response.
  useEffect(() => {
    if (status === "streaming" || status === "submitted") {
      return;
    }
    if (!paginatedMessageResults || paginatedMessageResults.length === 0) {
      return;
    }

    const uiMessages = convertToUIMessages(
      [...paginatedMessageResults].reverse(),
    );

    // Skip if useChat already has the same rendered message content.
    // This prevents redundant setMessages calls — e.g. after a local provider
    // save, Convex echoes the same data back via reactive query, which would
    // otherwise cause a visible flicker from new object references.
    // Content comparison is required because a partial and completed text part can
    // share the same message ID and part count.
    const current = messagesRef.current;

    // Don't overwrite with fewer messages — the backend (e.g. agent-long Trigger.dev
    // task) hasn't finished persisting the generated messages yet. Once it catches
    // up, Convex will push the full set and the normal sync below will apply.
    if (uiMessages.length < current.length && !persistedGoal) {
      return;
    }

    if (areMessagesEquivalentForConvexSync(current, uiMessages)) {
      return;
    }

    // Don't let Convex reorder messages that already exist locally. The trigger
    // task's onFinish saves the assistant message after the stream finishes, so
    // the next user message may land in Convex first (_creationTime ordering).
    // Local ordering is authoritative; only accept additive/content updates.
    const currentIdSet = new Set(current.map((m) => m.id));
    const uiIdSet = new Set(uiMessages.map((m) => m.id));
    const uiSharedOrder = uiMessages
      .map((m) => m.id)
      .filter((id) => currentIdSet.has(id));
    const currentSharedOrder = current
      .map((m) => m.id)
      .filter((id) => uiIdSet.has(id));
    if (
      uiSharedOrder.length > 0 &&
      uiSharedOrder.join("\0") !== currentSharedOrder.join("\0")
    ) {
      return;
    }

    // A status transition can rerun this effect before Convex has published the
    // final save. Never replace more complete local text or tool progress with a
    // stale persisted snapshot; the later Convex update will rerun the effect.
    if (!arePersistedMessagesAtLeastAsComplete(current, uiMessages)) {
      if (persistedGoal && isExistingChat) {
        const merged = mergePersistedGoalMessages(current, uiMessages);
        if (!areMessagesEquivalentForConvexSync(current, merged))
          setMessages(merged);
      }
      return;
    }

    if (isExistingChat) {
      setMessages(uiMessages);
    }
  }, [
    paginatedMessageResults,
    setMessages,
    isExistingChat,
    chatId,
    status,
    persistedGoal,
  ]);

  // Keep the latest visible user turn anchored while its response streams.
  // Auto-continue prompts are hidden from the timeline and must not replace
  // the user-visible anchor.
  const timelineAnchorMessageId = useMemo(
    () => findActiveTimelineAnchorMessageId(messages, status),
    [messages, status],
  );
  const { scrollRef, contentRef, scrollToBottom, isAtBottom } =
    useMessageScroll(timelineAnchorMessageId);

  // File upload with drag and drop support
  const {
    isDragOver,
    showDragOverlay,
    handleDragEnter,
    handleDragLeave,
    handleDragOver,
    handleDrop,
  } = useFileUpload(chatMode);

  // Handle instant scroll to bottom when first loading existing chat messages.
  // Only runs once per chat — pagination (which prepends older messages and
  // increases messages.length) must NOT re-trigger this.
  const hasScrolledToBottomRef = useRef(false);
  useEffect(() => {
    hasScrolledToBottomRef.current = false;
  }, [chatId]);
  useEffect(() => {
    if (
      isExistingChat &&
      messages.length > 0 &&
      !hasScrolledToBottomRef.current
    ) {
      hasScrolledToBottomRef.current = true;
      scrollToBottom({ instant: true, force: true });
    }
  }, [messages.length, scrollToBottom, isExistingChat]);

  // Keep a ref to the latest messageQueue to avoid stale closures
  const messageQueueRef = useLatestRef(messageQueue);

  // Clear queue when navigating to a different chat.
  // Intentionally reads messageQueueRef at cleanup time (latest value).
  useEffect(() => {
    return () => {
      // eslint-disable-next-line react-hooks/exhaustive-deps
      if (messageQueueRef.current.length > 0) {
        clearQueue();
      }
    };
  }, [chatId, clearQueue, messageQueueRef]);

  // Document-level drag and drop listeners encapsulated in a hook
  useDocumentDragAndDrop({
    handleDragEnter,
    handleDragLeave,
    handleDragOver,
    handleDrop,
  });

  // The start response can arrive before the Convex subscription catches up.
  // Keep that exact local run available to Stop after the pending POST settles.
  const cancellationTriggerRunRef = useCommittedRef(
    agentLongRunId ?? activeTriggerRunId,
  );

  // Chat handlers
  const {
    handleSubmit,
    handleStop,
    handleRegenerate,
    handleRetry,
    handleEditMessage,
    handleSendNow,
    handleContinue,
    hasPendingSummarySteer,
  } = useChatHandlers({
    chatId,
    messages,
    sendMessage,
    sendGoalMessage,
    sendQueuedMessage:
      shouldUseAgentLong ||
      messageQueue.some((message) => message.deliveryStatus)
        ? sendQueuedMessage
        : undefined,
    stop,
    regenerate,
    setMessages,
    isExistingChat,
    isUserMessagePersisted: (messageId) =>
      convex.query(api.messages.isUserMessagePersisted, { chatId, messageId }),
    status,
    isSummarizing: summarizationStatus?.status === "started",
    goalState: persistedGoal?.state,
    goalGeneration: persistedGoal?.generation,
    persistedTriggerRunId: activeTriggerRunId,
    isSendingNowRef,
    hasManuallyStoppedRef,
    activeTriggerRunRef: cancellationTriggerRunRef,
    resumeActiveRun: resumeStream,
    prepareAgentRecovery: () => agentLongPartialSavesRef.current.flush(chatId),
    getAgentRunRequestGeneration: () => agentLongRequestGenerationRef.current,
    onAgentRunAlreadyFinished: markAgentRunUiTerminal,
    onStopCallback: () => {
      dispatchStreaming({ type: "RESET_ON_FINISH" });
    },
    resetAutoContinueCount,
    sendDisabledReason: computerSendDisabledReason,
  });

  // Automatic queue processing - send next queued message when ready
  useEffect(() => {
    if (
      status === "ready" &&
      !hasPendingSummarySteer &&
      !computerSendDisabledReason &&
      messageQueue.length > 0 &&
      !messageQueue[0].deliveryStatus &&
      editingQueuedMessageId === null &&
      !isProcessingQueue &&
      !isSendingNowRef.current &&
      !hasManuallyStoppedRef.current
    ) {
      setIsProcessingQueue(true);
      const nextMessage = messageQueue[0];

      if (nextMessage && !nextMessage.deliveryStatus) {
        const body = {
          mode: chatModeRef.current,
          todos: todosRef.current,
          sandboxPreference: sandboxPreferenceRef.current,
          agentPermissionMode: agentPermissionModeRef.current,
          selectedModel: requestSelectedModelRef.current,
        };
        if (shouldUseAgentLong) {
          void sendQueuedMessage(nextMessage.id, body);
        } else {
          try {
            const sending = sendMessage(
              {
                text: nextMessage.text,
                files: nextMessage.files as any,
                metadata: { createdAt: nextMessage.timestamp },
              },
              { body },
            );
            removeQueuedMessage(nextMessage.id);
            void sending.catch((error) =>
              console.error("Failed to send queued message:", error),
            );
          } catch (error) {
            console.error("Failed to send queued message:", error);
          }
        }
      }

      setTimeout(() => setIsProcessingQueue(false), 100);
    }
  }, [
    status,
    hasPendingSummarySteer,
    shouldUseAgentLong,
    messageQueue,
    editingQueuedMessageId,
    computerSendDisabledReason,
    isProcessingQueue,
    sendQueuedMessage,
    sendMessage,
    removeQueuedMessage,
    chatModeRef,
    todosRef,
    sandboxPreferenceRef,
    agentPermissionModeRef,
    requestSelectedModelRef,
  ]);

  const handleScrollToBottom = useCallback(() => {
    scrollToBottom({ force: true });
  }, [scrollToBottom]);

  // Rate limit warning dismiss handler
  const handleDismissRateLimitWarning = useCallback(() => {
    dispatchStreaming({ type: "SET_RATE_LIMIT_WARNING", payload: null });
    setHasUserDismissedRateLimitWarning(true);
  }, [setHasUserDismissedRateLimitWarning]);

  // Branch chat handler
  const branchChatMutation = useMutation(api.messages.branchChat);

  const handleBranchMessage = useCallback(
    async (messageId: string) => {
      try {
        const newChatId = await branchChatMutation({ messageId });
        if (!newChatId) {
          toast.error("That message is no longer available to branch.");
          return;
        }
        initializeChat(newChatId);
        router.push(`/c/${newChatId}`);
      } catch (error) {
        console.error("Failed to branch chat:", error);
        toast.error(getBranchErrorMessage(error));
      }
    },
    [branchChatMutation, initializeChat, router],
  );

  const isRouteTransitioning =
    routeChatId !== undefined && routeChatId !== chatId;
  const hasMessages = !isRouteTransitioning && messages.length > 0;
  const showChatLayout = hasMessages || isExistingChat;
  const { isInitialExistingChatLoad, isChatNotFound } =
    getExistingChatLoadState({
      isExistingChat,
      hasMessages,
      isConvexAuthLoading,
      isConvexAuthenticated,
      shouldFetchMessages,
      chatData,
      paginationStatus: paginatedMessages.status,
      hasPaginatedMessageResults: !!paginatedMessageResults,
      awaitingServerChat,
    });
  const canResolveApprovalPresentation =
    !isInitialExistingChatLoad && chatDataForCurrentChat !== undefined;

  useEffect(() => {
    if (!isExistingChat || canResolveApprovalPresentation) {
      markInitialPresentationResolved();
    }
  }, [
    canResolveApprovalPresentation,
    isExistingChat,
    markInitialPresentationResolved,
  ]);

  const isApprovalPresentationLoading =
    isExistingChat &&
    !hasResolvedInitialPresentation &&
    !canResolveApprovalPresentation;
  const isComposerCentered = !hasMessages && !isExistingChat && !isMobile;
  const [composerOverlayHeight, setComposerOverlayHeight] = useState(0);
  // The mobile goal pill hosts the scroll button when there is room beside it.
  const [scrollButtonInGoal, setScrollButtonInGoal] = useState(false);
  const agentRunSpendCapWarning =
    rateLimitWarning?.warningType === "agent-run-spend-cap"
      ? rateLimitWarning
      : undefined;

  // Get branched chat info directly from chatData (no additional query needed)
  const branchedFromChatId = chatDataForCurrentChat?.branched_from_chat_id;
  const branchedFromChatTitle = (chatDataForCurrentChat as any)
    ?.branched_from_title;
  const currentAgentRunUiId =
    agentLongRunId ??
    activeTriggerRunId ??
    (terminalAgentRunUiState?.chatId === chatId
      ? terminalAgentRunUiState.runId
      : undefined);
  const isAgentRunUiTerminal =
    terminalAgentRunUiState?.chatId === chatId &&
    terminalAgentRunUiState.submissionGeneration ===
      agentLongSubmissionGeneration &&
    (terminalAgentRunUiState.runId
      ? terminalAgentRunUiState.runId === currentAgentRunUiId
      : !currentAgentRunUiId);

  const hasActiveGoalRun =
    !!activeTriggerRunId &&
    ["queued", "running", "needs_approval"].includes(
      persistedGoal?.state ?? "",
    );
  const pauseGoalOnSend = [
    "queued",
    "running",
    "waiting",
    "needs_approval",
  ].includes(persistedGoal?.state ?? "");
  const stopGoalRunBeforeControl = async (runId: string) => {
    // Never let a delayed goal control stop a replacement or unrelated run.
    if (activeTriggerRunId === runId) cancellationTriggerRunRef.current = runId;
    if (cancellationTriggerRunRef.current !== runId)
      throw new Error("The goal run changed. Reload before changing the goal.");
    return handleStop({
      requireSavedResponse: true,
      expectedTriggerRunId: runId,
    });
  };
  const goalPanel = (placement: "attached" | "detached") => (
    <AgentGoalPanel
      key={chatId}
      detached={placement === "detached"}
      onEdit={() => openSidebar({ kind: "goal", chatId })}
      chatId={chatId}
      exists={!!chatDataForCurrentChat}
      stopRunBeforeControl={stopGoalRunBeforeControl}
      latestSavedUserMessageAt={paginatedMessageResults?.reduce(
        (latest, message) =>
          message.role === "user"
            ? Math.max(latest, message.created_at)
            : latest,
        0,
      )}
      eligible={chatMode === "agent" && subscription !== "free"}
      idle={
        status === "ready" && !activeTriggerRunId && messageQueue.length === 0
      }
      disabledReason={computerSendDisabledReason}
      mobileAccessory={
        <ScrollToBottomButton
          variant="inline"
          onClick={handleScrollToBottom}
          hasMessages={hasMessages}
          isAtBottom={isAtBottom}
        />
      }
      onMobileAccessoryInlineChange={setScrollButtonInGoal}
      send={async (message, options) => {
        hasManuallyStoppedRef.current = false;
        resetAutoContinueCount();
        if (!isExistingChat)
          window.history.replaceState({}, "", `/c/${chatId}`);
        await sendGoalMessage(message, options);
      }}
      settings={{
        sandboxPreference,
        agentPermissionMode,
        selectedModel: requestSelectedModel,
      }}
    />
  );

  return (
    <CloudRecoveryAdmissionContext.Provider value={cloudRecoveryAdmission}>
      <StreamEffects
        sendDisabledReason={computerSendDisabledReason}
        key={chatId}
        chatId={chatId}
        autoResume={autoResume}
        serverMessages={serverMessages}
        resumeStream={resumeStream}
        setMessages={setMessages}
        status={status}
        chatMode={chatMode}
        sendMessage={sendMessage}
        hasManuallyStoppedRef={hasManuallyStoppedRef}
        todos={todos}
        sandboxPreference={sandboxPreference}
        agentPermissionMode={agentPermissionMode}
        selectedModel={requestSelectedModel}
        resetRef={resetAutoContinueRef}
        hasActiveStream={
          chatData === undefined || (chatData && !chatDataForCurrentChat)
            ? undefined
            : !!chatDataForCurrentChat?.active_stream_id ||
              !!chatDataForCurrentChat?.active_trigger_run_id
        }
      />
      <ForkAutoSendEffect
        sendDisabledReason={computerSendDisabledReason}
        key={`fork-auto-send:${chatId}`}
        chatId={chatId}
        status={status}
        isExistingChat={isExistingChat}
        messageCount={messages.length}
        onSubmit={handleSubmit}
      />
      <div className="flex min-h-0 flex-1 w-full flex-col bg-background overflow-hidden">
        <div className="flex min-h-0 flex-1 min-w-0 relative">
          {/* Left side - Chat content */}
          <div className="flex min-h-0 flex-col flex-1 min-w-0">
            {/* Unified Header */}
            <ChatHeader
              hasMessages={hasMessages}
              hasActiveChat={isExistingChat}
              chatTitle={chatTitle}
              id={chatId}
              chatData={chatDataForCurrentChat}
              chatSidebarOpen={chatSidebarOpen}
              isExistingChat={isExistingChat}
              isChatNotFound={isChatNotFound}
              branchedFromChatTitle={branchedFromChatTitle}
            />

            {usesCloudRecovery && (
              <div className="mx-auto w-full max-w-[768px] px-4">
                <CloudWorkspaceRecovery
                  key={`${chatId}:${cloudConnectionFailure?.sequence ?? 0}`}
                  surface={
                    cloudConnectionFailure?.chatId === chatId
                      ? "cloud_connection_error"
                      : "workspace_status"
                  }
                />
              </div>
            )}

            {/* Chat interface */}
            <div
              className={`bg-background flex flex-col flex-1 relative min-h-0 ${
                !showChatLayout && !isChatNotFound
                  ? "justify-center-safe overflow-y-auto"
                  : ""
              }`}
            >
              {/* Messages area */}
              {isChatNotFound ? (
                <div className="flex-1 flex flex-col items-center justify-center px-4 py-8 min-h-0">
                  <div className="w-full max-w-full sm:max-w-[768px] flex flex-col items-center space-y-8">
                    <div className="text-center">
                      <h1 className="text-2xl font-bold text-foreground mb-2">
                        Task Not Found
                      </h1>
                      <p className="text-muted-foreground">
                        This task doesn&apos;t exist or you don&apos;t have
                        permission to view it.
                      </p>
                    </div>
                  </div>
                </div>
              ) : showChatLayout ? (
                <div
                  className="flex min-h-0 flex-1"
                  aria-busy={isInitialExistingChatLoad || isRouteTransitioning}
                  data-testid="chat-timeline-shell"
                >
                  {isInitialExistingChatLoad || isRouteTransitioning ? (
                    <div
                      className="flex min-h-0 flex-1 items-center justify-center text-sm text-muted-foreground"
                      role="status"
                      data-testid="chat-timeline-loading"
                    >
                      <SlowLoadingNotice key={chatId} label="Loading task…" />
                    </div>
                  ) : (
                    <Messages
                      key={chatId}
                      chatId={chatId}
                      scrollRef={scrollRef}
                      contentRef={contentRef}
                      messages={messages}
                      setMessages={setMessages}
                      onRegenerate={handleRegenerate}
                      onRetry={handleRetry}
                      onContinue={handleContinue}
                      onReconnect={resumeStream}
                      onEditMessage={handleEditMessage}
                      onBranchMessage={handleBranchMessage}
                      status={status}
                      error={error || null}
                      paginationStatus={paginatedMessages.status}
                      loadMore={paginatedMessages.loadMore}
                      isMobile={isMobile}
                      tempChatFileDetails={tempChatFileDetails}
                      finishReason={chatDataForCurrentChat?.finish_reason}
                      agentRunSpendCapWarning={agentRunSpendCapWarning}
                      uploadStatus={uploadStatus}
                      summarizationStatus={summarizationStatus}
                      mode={
                        chatMode ??
                        (chatDataForCurrentChat as any)?.default_model_slug
                      }
                      chatTitle={chatTitle}
                      branchedFromChatId={branchedFromChatId}
                      branchedFromChatTitle={branchedFromChatTitle}
                      anchorMessageId={timelineAnchorMessageId}
                      contentInsetEndAdjustment={composerOverlayHeight}
                    />
                  )}
                </div>
              ) : (
                <div
                  className={`flex flex-col min-h-0 ${isMobile ? "flex-1" : "shrink-0"}`}
                >
                  <div className="flex-1 flex flex-col items-center justify-center px-4 py-4 min-h-0">
                    <div className="w-full max-w-[768px] flex flex-col items-center">
                      <HackingSuggestions />
                    </div>
                  </div>
                </div>
              )}

              {/* Keep one composer mounted across folding and the first message.
                  Remounting can restore an older saved draft over live input. */}
              {!isChatNotFound ? (
                <ComposerOverlay
                  active={showChatLayout}
                  onHeightChange={setComposerOverlayHeight}
                >
                  {/* Anchor above the entire composer, including browser notices. */}
                  <div className="absolute bottom-full left-1/2 mb-4 -translate-x-1/2 z-40">
                    {!scrollButtonInGoal && (
                      <ScrollToBottomButton
                        onClick={handleScrollToBottom}
                        hasMessages={hasMessages}
                        isAtBottom={isAtBottom}
                      />
                    )}
                  </div>
                  <ChatInput
                    completedPredictionTurn={completedPredictionTurn}
                    predictionModeReady={
                      !isExistingChat ||
                      initializedPredictionModeChatId === chatId
                    }
                    interruptedPredictionTurn={interruptedPredictionTurn}
                    latestMessageId={messages.at(-1)?.id}
                    latestMessageIsAssistant={
                      messages.at(-1)?.role === "assistant"
                    }
                    goalPanel={goalPanel}
                    hasActiveGoalRun={hasActiveGoalRun}
                    pauseGoalOnSend={pauseGoalOnSend}
                    topNotice={
                      showChatLayout ? (
                        <BrowserHandoffEntry
                          chatId={chatId}
                          messages={messages}
                        />
                      ) : undefined
                    }

                    onSubmit={handleSubmit}
                    onStop={handleStop}
                    onReconnect={resumeStream}
                    onSendNow={handleSendNow}
                    status={status}
                    hideStop={isAgentRunUiTerminal && !hasActiveGoalRun}
                    isCentered={isComposerCentered}
                    hasMessages={hasMessages}
                    isNewChat={!isExistingChat}
                    chatId={chatId}
                    sendDisabledReason={computerSendDisabledReason}
                    isResolvingInitialState={isApprovalPresentationLoading}
                    rateLimitWarning={
                      rateLimitWarning ? rateLimitWarning : undefined
                    }
                    onDismissRateLimitWarning={handleDismissRateLimitWarning}
                    storedApprovalRequest={storedAgentApprovalRequest}
                  />
                </ComposerOverlay>
              ) : null}
              {!showChatLayout && !isChatNotFound && <Footer />}
            </div>
          </div>

          {/* Keep the controller mounted when switching between split and overlay. */}
          <div
            ref={computerDialogRef}
            className={
              computerSidebarOverlay
                ? sidebarOpen
                  ? "fixed inset-0 z-50 flex items-center justify-center bg-background p-4"
                  : "hidden"
                : `min-w-0 transition-[width] duration-300 ${sidebarOpen ? "w-1/2 flex-shrink-0" : "w-0 overflow-hidden"}`
            }
            role={computerSidebarOverlay && sidebarOpen ? "dialog" : undefined}
            aria-modal={
              computerSidebarOverlay && sidebarOpen ? true : undefined
            }
            aria-label={
              computerSidebarOverlay && sidebarOpen
                ? sidebarContent &&
                  "kind" in sidebarContent &&
                  sidebarContent.kind === "goal"
                  ? "Edit goal"
                  : "HackerAI’s Computer"
                : undefined
            }
            tabIndex={computerSidebarOverlay ? -1 : undefined}
            data-layout={computerSidebarOverlay ? "overlay" : "split"}
            data-testid="computer-sidebar-container"
          >
            <div
              className={
                computerSidebarOverlay ? "w-full max-w-4xl h-full" : "h-full"
              }
            >
              {sidebarOpen && (
                <ComputerSidebar
                  key={chatId}
                  stopGoalRunBeforeControl={stopGoalRunBeforeControl}
                  continueGoal={async (goal) => {
                    if (computerSendDisabledReason)
                      throw new Error(computerSendDisabledReason);
                    hasManuallyStoppedRef.current = false;
                    resetAutoContinueCount();
                    await sendGoalMessage(
                      { text: goalResumeMessage(goal) },
                      {
                        body: {
                          sandboxPreference: goal.sandboxPreference,
                          agentPermissionMode: goal.permissionMode,
                          selectedModel: goal.selectedModel,
                          mode: "agent",
                          goal: {
                            action: "resume",
                            expectedGeneration: goal.generation,
                          },
                        },
                      },
                    );
                  }}
                  onBrowserContinue={continueBrowserHandoff}
                  chatId={chatId}
                  messages={messages}
                  status={status}
                />
              )}
            </div>
          </div>

          {/* Drag and Drop Overlay - covers main content area only (excludes sidebars) */}
          <DragDropOverlay
            isVisible={showDragOverlay}
            isDragOver={isDragOver}
          />
        </div>
      </div>
    </CloudRecoveryAdmissionContext.Provider>
  );
};
