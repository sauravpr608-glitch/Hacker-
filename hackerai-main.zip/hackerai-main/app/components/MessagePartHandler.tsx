import { memo } from "react";
import { UIMessage } from "@ai-sdk/react";
import { MemoizedMarkdown } from "./MemoizedMarkdown";
import { FileToolsHandler } from "./tools/FileToolsHandler";
import { FileHandler } from "./tools/FileHandler";
import { TerminalToolHandler } from "./tools/TerminalToolHandler";
import { HttpRequestToolHandler } from "./tools/HttpRequestToolHandler";
import { WebToolHandler } from "./tools/WebToolHandler";
import { TodoToolHandler } from "./tools/TodoToolHandler";
import { NotesToolHandler } from "./tools/NotesToolHandler";
import { ReportToolHandler } from "./tools/ReportToolHandler";
import { FindingToolHandler } from "./tools/FindingToolHandler";
import { ToolValidationErrorHandler } from "./tools/ToolErrorHandler";
import { FindingCard } from "./findings/FindingCard";
import { ProxyToolHandler } from "./tools/ProxyToolHandler";
import { GetTerminalFilesHandler } from "./tools/GetTerminalFilesHandler";
import { SummarizationHandler } from "./tools/SummarizationHandler";
import type { ChatStatus } from "@/types";
import type { FileDetails } from "@/types/file";
import { ReasoningHandler } from "./ReasoningHandler";
import { isToolInputValidationError } from "@/lib/chat/tool-error-display";
import { SubagentToolHandler } from "./tools/SubagentToolHandler";
import { SubagentSkillToolHandler } from "./tools/SubagentSkillToolHandler";

interface MessagePartHandlerProps {
  message: UIMessage;
  part: any;
  partIndex: number;
  status: ChatStatus;
  isLastMessage?: boolean;
  keepLatestReasoningOpenDuringStreaming?: boolean;
  suppressReasoningAutoOpen?: boolean;
  deferReasoningCollapseUntilParent?: boolean;
  /** Pre-computed terminal output by toolCallId (from message level) to avoid per-handler filtering */
  terminalOutputByToolCallId?: Map<string, string>;
  /** File details from get_terminal_files tool (streamed progressively) */
  sharedFileDetails?: FileDetails[];
}

const SUBAGENT_TOOL_PART_TYPES = new Set([
  "tool-delegate_task",
  "tool-create_agent",
  "tool-continue_agent",
  "tool-list_agents",
  "tool-send_message_to_agent",
  "tool-wait_for_agents",
  "tool-cancel_agent",
]);

const subagentLifecycleSignature = (
  message: UIMessage,
  toolCallId: unknown,
): string => {
  if (typeof toolCallId !== "string") return "";
  return (message.parts as any[])
    .filter(
      (candidate) =>
        candidate?.type === "data-subagent-lifecycle" &&
        candidate?.data?.parent_tool_call_id === toolCallId,
    )
    .map((candidate) => {
      const data = candidate.data ?? {};
      return [
        data.subagent_id,
        data.parent_message_id,
        data.agent_name,
        data.event,
        data.status,
      ].join(":");
    })
    .join("|");
};

// Memoized user text component - avoids re-renders for unchanged text
const UserTextPart = memo(function UserTextPart({ text }: { text: string }) {
  return <div className="whitespace-pre-wrap">{text}</div>;
});

// Deep equality check for tool inputs — avoids JSON.stringify overhead while
// correctly handling nested objects/arrays (e.g. tool-file edits, todo_write todos).
function deepEqual(a: any, b: any): boolean {
  if (a === b) return true;
  if (!a || !b || typeof a !== typeof b) return false;
  if (typeof a !== "object") return false;

  const isArrayA = Array.isArray(a);
  const isArrayB = Array.isArray(b);
  if (isArrayA !== isArrayB) return false;

  if (isArrayA) {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
      if (!deepEqual(a[i], b[i])) return false;
    }
    return true;
  }

  const keysA = Object.keys(a);
  const keysB = Object.keys(b);
  if (keysA.length !== keysB.length) return false;
  for (let i = 0; i < keysA.length; i++) {
    const key = keysA[i];
    if (!deepEqual(a[key], b[key])) return false;
  }
  return true;
}

// Custom comparison for MessagePartHandler to minimize re-renders
export function areMessagePartHandlerPropsEqual(
  prevProps: MessagePartHandlerProps,
  nextProps: MessagePartHandlerProps,
): boolean {
  // Always re-render if status changes (streaming state)
  if (prevProps.status !== nextProps.status) return false;

  // Always re-render if isLastMessage changes
  if (prevProps.isLastMessage !== nextProps.isLastMessage) return false;
  if (
    prevProps.keepLatestReasoningOpenDuringStreaming !==
    nextProps.keepLatestReasoningOpenDuringStreaming
  )
    return false;
  if (
    prevProps.suppressReasoningAutoOpen !== nextProps.suppressReasoningAutoOpen
  )
    return false;
  if (
    prevProps.deferReasoningCollapseUntilParent !==
    nextProps.deferReasoningCollapseUntilParent
  )
    return false;

  if (prevProps.part?.type !== nextProps.part?.type) return false;

  // Shared file details change for get_terminal_files during streaming
  // Must be checked before the part reference check below, because the part
  // reference may be stable while new file metadata arrives via the stream.
  if (
    prevProps.part?.type === "tool-get_terminal_files" &&
    prevProps.sharedFileDetails !== nextProps.sharedFileDetails
  )
    return false;

  if (SUBAGENT_TOOL_PART_TYPES.has(prevProps.part?.type)) {
    const previousLifecycle = subagentLifecycleSignature(
      prevProps.message,
      prevProps.part?.toolCallId,
    );
    const nextLifecycle = subagentLifecycleSignature(
      nextProps.message,
      nextProps.part?.toolCallId,
    );
    if (previousLifecycle !== nextLifecycle) return false;
  }

  // Auto review metadata arrives immediately before the approval request. Keep
  // approval rows responsive if React commits between those two stream parts.
  if (
    nextProps.part?.state === "approval-requested" &&
    prevProps.message.parts.length !== nextProps.message.parts.length
  )
    return false;

  // Check part reference - if same reference, no changes
  if (prevProps.part === nextProps.part) return true;

  // Pre-computed terminal map reference change should re-render
  if (
    prevProps.terminalOutputByToolCallId !==
    nextProps.terminalOutputByToolCallId
  )
    return false;

  if (prevProps.part?.type === "data-shared-finding") {
    return deepEqual(prevProps.part.data, nextProps.part.data);
  }

  // For tool parts, compare state and output which change during streaming
  if (
    prevProps.part?.type?.startsWith("tool-") ||
    prevProps.part?.type?.startsWith("data-")
  ) {
    return (
      prevProps.part.state === nextProps.part.state &&
      prevProps.part.toolCallId === nextProps.part.toolCallId &&
      prevProps.part.toolName === nextProps.part.toolName &&
      prevProps.part.output === nextProps.part.output &&
      prevProps.part.errorText === nextProps.part.errorText &&
      deepEqual(prevProps.part.approval, nextProps.part.approval) &&
      // Tool input is an object — reference check first (fast path), then
      // deep comparison so new objects with identical content don't re-render.
      (prevProps.part.input === nextProps.part.input ||
        deepEqual(prevProps.part.input, nextProps.part.input))
    );
  }

  // For text parts, compare text content
  if (prevProps.part?.type === "text") {
    return prevProps.part.text === nextProps.part.text;
  }

  // For reasoning, compare text
  if (prevProps.part?.type === "reasoning") {
    return (
      prevProps.part.text === nextProps.part.text &&
      prevProps.message.parts.length === nextProps.message.parts.length
    );
  }

  // Default: shallow compare part object
  return prevProps.part === nextProps.part;
}

export const MessagePartHandler = memo(function MessagePartHandler({
  message,
  part,
  partIndex,
  status,
  isLastMessage,
  keepLatestReasoningOpenDuringStreaming,
  suppressReasoningAutoOpen,
  deferReasoningCollapseUntilParent,
  terminalOutputByToolCallId,
  sharedFileDetails,
}: MessagePartHandlerProps) {
  const validationToolType =
    typeof part.type === "string" && part.type.startsWith("tool-")
      ? part.type
      : part.type === "dynamic-tool" && typeof part.toolName === "string"
        ? `tool-${part.toolName}`
        : null;
  if (
    validationToolType &&
    part.state === "output-error" &&
    isToolInputValidationError(part.errorText)
  ) {
    return (
      <ToolValidationErrorHandler
        toolType={validationToolType}
        toolCallId={part.toolCallId || ""}
        errorText={part.errorText}
      />
    );
  }

  // Main switch for different part types
  switch (part.type) {
    case "text": {
      const isUser = message.role === "user";
      const text = part.text ?? "";

      // For user messages, use memoized plain text component
      if (isUser) {
        return <UserTextPart text={text} />;
      }

      // For assistant messages, use memoized markdown rendering
      return (
        <div
          data-performance-message-id={message.id}
          data-performance-text-length={text.length}
        >
          <MemoizedMarkdown
            content={text}
            isAnimating={status === "streaming" && isLastMessage === true}
          />
        </div>
      );
    }

    case "reasoning":
      return (
        <ReasoningHandler
          message={message}
          partIndex={partIndex}
          status={status}
          isLastMessage={isLastMessage}
          keepLatestOpenDuringStreaming={keepLatestReasoningOpenDuringStreaming}
          suppressAutoOpenDuringStreaming={suppressReasoningAutoOpen}
          deferCollapseUntilParent={deferReasoningCollapseUntilParent}
        />
      );

    case "data-summarization":
      return (
        <SummarizationHandler
          message={message}
          part={part}
          partIndex={partIndex}
        />
      );

    // Legacy file tools
    case "tool-read_file":
    case "tool-write_file":
    case "tool-delete_file":
    case "tool-search_replace":
    case "tool-multi_edit":
      return <FileToolsHandler message={message} part={part} status={status} />;

    case "tool-file":
    case "tool-file_edit":
    case "tool-file_write":
      return (
        <FileHandler
          message={message}
          part={part}
          status={status}
          canRequestApproval={isLastMessage === true && status !== "ready"}
        />
      );

    case "tool-web_search":
    case "tool-open_url":
    case "tool-web": // Legacy tool
      return <WebToolHandler part={part} status={status} />;

    case "data-terminal":
    case "tool-shell":
    case "tool-run_terminal_cmd":
    case "tool-interact_terminal_session": {
      const effectiveToolCallId =
        (part as any).data?.toolCallId ?? part.toolCallId;
      const precomputedStreamingOutput = effectiveToolCallId
        ? terminalOutputByToolCallId?.get(effectiveToolCallId)
        : undefined;
      return (
        <TerminalToolHandler
          canRequestApproval={isLastMessage === true && status !== "ready"}
          message={message}
          part={part}
          status={status}
          precomputedStreamingOutput={precomputedStreamingOutput}
        />
      );
    }

    // Legacy tool
    case "tool-http_request":
      return (
        <HttpRequestToolHandler message={message} part={part} status={status} />
      );

    case "tool-get_terminal_files":
      return (
        <GetTerminalFilesHandler
          part={part}
          status={status}
          sharedFileDetails={sharedFileDetails}
        />
      );

    case "tool-todo_write":
      return <TodoToolHandler message={message} part={part} status={status} />;

    case "tool-delegate_task":
    case "tool-create_agent":
    case "tool-continue_agent":
    case "tool-list_agents":
    case "tool-send_message_to_agent":
    case "tool-wait_for_agents":
    case "tool-cancel_agent":
      return (
        <SubagentToolHandler message={message} part={part} status={status} />
      );

    case "tool-search_skills":
      return (
        <SubagentSkillToolHandler
          part={part}
          status={status}
          toolName="search_skills"
        />
      );

    case "tool-load_skill":
      return (
        <SubagentSkillToolHandler
          part={part}
          status={status}
          toolName="load_skill"
        />
      );

    case "tool-create_note":
      return (
        <NotesToolHandler part={part} status={status} toolName="create_note" />
      );

    case "tool-list_notes":
      return (
        <NotesToolHandler part={part} status={status} toolName="list_notes" />
      );

    case "tool-update_note":
      return (
        <NotesToolHandler part={part} status={status} toolName="update_note" />
      );

    case "tool-delete_note":
      return (
        <NotesToolHandler part={part} status={status} toolName="delete_note" />
      );

    case "tool-list_reports":
      return (
        <ReportToolHandler
          part={part}
          status={status}
          toolName="list_reports"
        />
      );
    case "tool-get_report":
      return (
        <ReportToolHandler part={part} status={status} toolName="get_report" />
      );
    case "tool-update_vulnerability_report":
      return (
        <ReportToolHandler
          part={part}
          status={status}
          toolName="update_vulnerability_report"
        />
      );
    case "tool-create_vulnerability_report":
      return <FindingToolHandler part={part} status={status} />;

    case "data-shared-finding":
      return part.data ? (
        <FindingCard
          title={part.data.title}
          target={part.data.target}
          severity={part.data.severity}
          cvssScore={part.data.cvss_score}
        />
      ) : null;

    case "tool-list_requests":
      return (
        <ProxyToolHandler
          part={part}
          status={status}
          toolName="list_requests"
        />
      );
    case "tool-view_request":
      return (
        <ProxyToolHandler part={part} status={status} toolName="view_request" />
      );
    case "tool-send_request":
      return (
        <ProxyToolHandler part={part} status={status} toolName="send_request" />
      );
    case "tool-scope_rules":
      return (
        <ProxyToolHandler part={part} status={status} toolName="scope_rules" />
      );
    case "tool-list_sitemap":
      return (
        <ProxyToolHandler part={part} status={status} toolName="list_sitemap" />
      );
    case "tool-view_sitemap_entry":
      return (
        <ProxyToolHandler
          part={part}
          status={status}
          toolName="view_sitemap_entry"
        />
      );

    default:
      return null;
  }
}, areMessagePartHandlerPropsEqual);
