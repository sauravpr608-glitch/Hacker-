"use client";

import { FC, useEffect, useRef } from "react";
import { useGlobalStateActions } from "../contexts/GlobalState";
import { useIsMobile } from "@/hooks/use-mobile";
import { useChats } from "../hooks/useChats";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarRail,
  useSidebar,
} from "@/components/ui/sidebar";
import SidebarUserNav from "./SidebarUserNav";
import SidebarHeaderContent from "./SidebarHeader";
import { SidebarChatSections } from "./SidebarChatSections";
import { useProjects } from "../hooks/useProjects";
import { SidebarProjectListProvider } from "../contexts/SidebarProjectList";

/** Chat list data lifted from parent so the subscription stays active when sidebar closes. */
export type ChatListData = ReturnType<typeof useChats>;
/** Project list data lifted for the same reason, including an already-resolved empty list. */
export type ProjectListData = ReturnType<typeof useProjects>;

// List content receives live data from its owner so mobile overlay remounts do not refetch.
const ChatListContent: FC<{
  chatListData: ChatListData;
  projectListData: ProjectListData;
  isVisible?: boolean;
}> = ({ chatListData, projectListData, isVisible = true }) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    let idleTimeout: ReturnType<typeof setTimeout> | undefined;
    const handleScroll = () => {
      // Keep transient scrollbar activity out of the chat list's render cycle.
      container.dataset.scrolling = "true";
      clearTimeout(idleTimeout);
      idleTimeout = setTimeout(() => {
        delete container.dataset.scrolling;
      }, 800);
    };

    container.addEventListener("scroll", handleScroll, { passive: true });
    return () => {
      container.removeEventListener("scroll", handleScroll);
      clearTimeout(idleTimeout);
      delete container.dataset.scrolling;
    };
  }, []);

  return (
    <div
      className="sidebar-chat-scroll h-full min-w-0 overflow-y-auto overflow-x-hidden"
      ref={scrollContainerRef}
      data-testid="sidebar-chat-list-scroll-container"
    >
      <SidebarProjectListProvider
        projects={projectListData.results}
        paginationStatus={projectListData.status}
        loadMoreProjects={projectListData.loadMore}
      >
        <SidebarChatSections
          chats={chatListData.results || []}
          projects={projectListData.results}
          projectPaginationStatus={projectListData.status}
          loadMoreProjects={projectListData.loadMore}
          paginationStatus={chatListData.status}
          loadMore={isVisible ? chatListData.loadMore : undefined}
          containerRef={scrollContainerRef}
        />
      </SidebarProjectListProvider>
    </div>
  );
};

// Desktop-only sidebar content (requires SidebarProvider context)
const DesktopSidebarContent: FC<{
  isMobile: boolean;
  handleCloseSidebar: () => void;
  chatListData: ChatListData;
  projectListData: ProjectListData;
}> = ({ isMobile, handleCloseSidebar, chatListData, projectListData }) => {
  const { state } = useSidebar();
  const isCollapsed = state === "collapsed";

  return (
    <Sidebar
      side="left"
      collapsible="icon"
      className={`${isMobile ? "w-full" : "w-[300px]"}`}
    >
      <SidebarHeader>
        <SidebarHeaderContent
          handleCloseSidebar={handleCloseSidebar}
          isCollapsed={isCollapsed}
        />
      </SidebarHeader>

      {/* Keep the observer root bounded and make it the only scrolling element. */}
      <SidebarContent className="overflow-hidden">
        <SidebarGroup className="min-h-0 flex-1">
          <SidebarGroupContent className="min-h-0 flex-1">
            <div
              className={`h-full transition-opacity duration-100 ease-out motion-reduce:transition-none ${
                isCollapsed
                  ? "pointer-events-none invisible opacity-0"
                  : "visible opacity-100 delay-200 motion-reduce:delay-0"
              }`}
              aria-hidden={isCollapsed}
              inert={isCollapsed}
              data-testid="sidebar-chat-list-visibility"
            >
              {/* Keep project subscriptions and section state alive across collapse. */}
              <ChatListContent
                chatListData={chatListData}
                projectListData={projectListData}
                isVisible={!isCollapsed}
              />
            </div>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <SidebarUserNav isCollapsed={isCollapsed} />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
};

const MainSidebar: FC<{
  isMobileOverlay?: boolean;
  onClose?: () => void;
  /** When provided (e.g. from ChatLayout), avoids refetching when sidebar opens/closes */
  chatListData?: ChatListData;
  /** Keeps the resolved project list alive too, especially the empty state on mobile. */
  projectListData?: ProjectListData;
}> = ({
  isMobileOverlay = false,
  onClose,
  chatListData: chatListDataProp,
  projectListData: projectListDataProp,
}) => {
  const isMobile = useIsMobile();
  const { setChatSidebarOpen } = useGlobalStateActions();
  // Use lifted data when provided; otherwise subscribe here (e.g. SharedChatView)
  const chatListDataFromHook = useChats(chatListDataProp === undefined);
  const chatListData = chatListDataProp ?? chatListDataFromHook;
  const projectListDataFromHook = useProjects(
    10,
    projectListDataProp === undefined,
  );
  const projectListData = projectListDataProp ?? projectListDataFromHook;

  const handleCloseSidebar = () => {
    if (onClose) {
      onClose();
      return;
    }
    setChatSidebarOpen(false);
  };

  // Mobile overlay version - simplified without Sidebar wrapper
  if (isMobileOverlay) {
    return (
      <>
        <div className="flex flex-col h-full w-full bg-sidebar border-r">
          {/* Header with Actions */}
          <SidebarHeaderContent
            handleCloseSidebar={handleCloseSidebar}
            isCollapsed={false}
            isMobileOverlay={true}
          />

          {/* Chat List */}
          <div
            className="flex-1 overflow-hidden px-2"
            data-testid="mobile-sidebar-chat-content"
          >
            <ChatListContent
              chatListData={chatListData}
              projectListData={projectListData}
            />
          </div>

          {/* Footer */}
          <div className="p-2">
            <SidebarUserNav isCollapsed={false} />
          </div>
        </div>
      </>
    );
  }

  return (
    <DesktopSidebarContent
      isMobile={isMobile ?? false}
      handleCloseSidebar={handleCloseSidebar}
      chatListData={chatListData}
      projectListData={projectListData}
    />
  );
};

export default MainSidebar;
