import { BlockedChatBillingRecovery } from "./BlockedChatBillingRecovery";
import { X } from "lucide-react";
import { useEffect, useRef } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Button } from "@/components/ui/button";
import { redirectToPricing } from "../hooks/usePricingDialog";
import { openSettingsDialog } from "@/lib/utils/settings-dialog";
import type { ChatMode, SubscriptionTier } from "@/types";
import type { LimitCapReason } from "@/lib/limit-pressure";
import type { AgentRunSpendCapBasis } from "@/lib/chat/agent-run-spend-cap";
import {
  getExtraUsageLimitCta,
  getLimitTypeForCapReason,
  shouldShowUpgradeCta,
} from "@/lib/limit-pressure";
import {
  captureAddCreditCtaClick,
  captureAddCreditCtaImpression,
  captureUpgradeCtaImpression,
} from "@/lib/analytics/client";

// Discriminated union for warning data
export type RateLimitWarningData =
  | {
      warningType: "sliding-window";
      remaining: number;
      resetTime: Date;
      mode: ChatMode;
      subscription: SubscriptionTier;
    }
  | {
      warningType: "token-bucket";
      bucketType: "monthly" | "daily";
      remainingPercent: number;
      resetTime: Date;
      subscription: SubscriptionTier;
      severity?: "info" | "warning";
      usedDollars?: number;
      limitDollars?: number;
      capReason?: LimitCapReason;
      midStream?: boolean;
      cutOff?: boolean;
    }
  | {
      warningType: "extra-usage-active";
      bucketType: "monthly";
      resetTime: Date;
      subscription: SubscriptionTier;
      capReason?: LimitCapReason;
      midStream?: boolean;
    }
  | {
      warningType: "paid-daily-free-allowance";
      resetTime: Date;
      subscription: SubscriptionTier;
      mode: ChatMode;
      costLimitDollars: number;
    }
  | {
      warningType: "agent-run-spend-cap";
      resetTime: Date;
      subscription: "pro";
      mode: "agent";
      runCostDollars: number;
      runCapDollars: number;
      monthlyRemainingDollars: number;
      capBasis: AgentRunSpendCapBasis;
      premiumContinuationAllowed: boolean;
      midStream?: boolean;
    };

interface RateLimitWarningProps {
  data: RateLimitWarningData;
  onDismiss: () => void;
  compact?: boolean;
}

const formatTimeUntil = (resetTime: Date): string => {
  const now = new Date();
  const timeDiff = resetTime.getTime() - now.getTime();

  if (timeDiff <= 0) {
    return "now";
  }

  const daysUntil = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
  const hoursUntil = Math.floor(
    (timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60),
  );
  const minutesUntil = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));

  if (daysUntil === 0 && hoursUntil === 0 && minutesUntil === 0) {
    return "in less than a minute";
  }
  if (daysUntil >= 1 && hoursUntil === 0) {
    return `in ${daysUntil} ${daysUntil === 1 ? "day" : "days"}`;
  }
  if (daysUntil >= 1) {
    return `in ${daysUntil}d ${hoursUntil}h`;
  }
  if (hoursUntil === 0) {
    return `in ${minutesUntil} ${minutesUntil === 1 ? "minute" : "minutes"}`;
  }
  if (minutesUntil === 0) {
    return `in ${hoursUntil} ${hoursUntil === 1 ? "hour" : "hours"}`;
  }
  return `in ${hoursUntil}h ${minutesUntil}m`;
};

const getMessage = (data: RateLimitWarningData, timeString: string): string => {
  if (data.warningType === "sliding-window") {
    if (data.remaining === 0) {
      return data.mode === "agent"
        ? "You've used today's free Agent requests. Upgrade to keep running Agent today, or wait for the reset at midnight UTC."
        : "You've used all your daily free requests. Upgrade to keep going today, or wait for the reset at midnight UTC.";
    }

    return `You have ${data.remaining} daily ${data.remaining === 1 ? "request" : "requests"} remaining today.`;
  }

  if (data.warningType === "extra-usage-active") {
    return `You're now using extra usage credits. Your monthly limit resets ${timeString}.`;
  }

  if (data.warningType === "paid-daily-free-allowance") {
    return `Your paid-plan limit is used up, so this ${data.mode === "agent" ? "Agent" : "Ask"} response is using today's free $${data.costLimitDollars.toFixed(2)} allowance with our low-cost model. It resets ${timeString} and the response will stop if the allowance runs out.`;
  }

  if (data.warningType === "agent-run-spend-cap") {
    return `This Pro Agent run paused after using $${data.runCostDollars.toFixed(2)} of the $${data.runCapDollars.toFixed(2)} legacy per-run safety cap. Continue to keep working.`;
  }

  if (data.subscription === "free" && data.bucketType === "daily") {
    if (data.remainingPercent === 0) {
      return `You've used today's free Agent allowance${data.cutOff ? " and this response was cut off" : ""}. Upgrade to continue. Resets ${timeString} at midnight UTC.`;
    }
    return `You've used $${(data.usedDollars ?? 0).toFixed(2)} of today's $${(data.limitDollars ?? 0.1).toFixed(2)} free Agent allowance. Resets ${timeString} at midnight UTC.`;
  }

  // Token bucket warning — show dollar amounts when available
  if (data.remainingPercent === 0) {
    if (data.cutOff) {
      if (data.subscription === "free") {
        return `You've reached your free monthly usage limit and this response was cut off. Upgrade for higher limits. Resets ${timeString}.`;
      }
      if (data.capReason === "extra_usage_cap") {
        return `You've reached your extra usage spending limit and this response was cut off. Increase your limit to continue. Resets ${timeString}.`;
      }
      if (data.capReason === "paid_daily_free_allowance_cut_off") {
        return `Today's free allowance was used up and this response was cut off. Add credits to continue. Resets ${timeString}.`;
      }
      return `You've reached your monthly limit and this response was cut off. Add credits or upgrade to continue. Resets ${timeString}.`;
    }
    if (data.subscription === "free") {
      return `You've reached your free monthly usage limit. Upgrade for higher limits. Resets ${timeString}.`;
    }

    return `You've reached your monthly usage limit. It resets ${timeString}.`;
  }

  const usedPercent = 100 - data.remainingPercent;
  if (data.usedDollars !== undefined && data.limitDollars !== undefined) {
    return `You've used $${data.usedDollars.toFixed(2)} of $${data.limitDollars.toFixed(2)} (${usedPercent}%). Resets ${timeString}.`;
  }

  return `You have ${data.remainingPercent}% of your monthly usage remaining. It resets ${timeString}.`;
};

const getUpgradeCtaText = (
  data: RateLimitWarningData,
  limitType: string,
): string => {
  if (
    data.subscription === "free" &&
    (limitType === "daily_requests" ||
      limitType === "free_monthly" ||
      limitType === "free_daily_cost")
  ) {
    return "Keep going";
  }

  return "Upgrade plan";
};

const WARNING_STYLES = "bg-input-chat border-black/8 dark:border-border";

export const RateLimitWarning = (props: RateLimitWarningProps) => {
  const isBlocked =
    props.data.warningType === "token-bucket" &&
    props.data.remainingPercent === 0;
  return isBlocked ? (
    <BlockedChatBillingRecovery>
      <RateLimitWarningContent {...props} />
    </BlockedChatBillingRecovery>
  ) : (
    <RateLimitWarningContent {...props} />
  );
};

const RateLimitWarningContent = ({
  data,
  onDismiss,
  compact = false,
}: RateLimitWarningProps) => {
  const isPersonalMonthlyWarning =
    data.warningType === "token-bucket" &&
    ["pro", "pro-plus", "ultra"].includes(data.subscription) &&
    !data.cutOff &&
    (data.capReason === "monthly_near_limit" ||
      (!data.capReason && data.remainingPercent > 0));
  // Reuse the live personal-wallet entitlement so an already visible warning
  // reacts to purchases, the Extra Usage toggle, and spending-cap changes.
  const extraUsage = useQuery(
    api.extraUsage.getMaxModelExtraUsageEntitlement,
    isPersonalMonthlyWarning ? {} : "skip",
  );
  const hideMonthlyWarning =
    isPersonalMonthlyWarning &&
    (extraUsage === undefined ||
      (extraUsage?.extraUsageAvailable === true && extraUsage.hasBalance));
  const capturedUpgradeImpressionRef = useRef(false);
  const capturedAddCreditImpressionRef = useRef(false);
  const timeString = formatTimeUntil(data.resetTime);
  const message = getMessage(data, timeString);
  const capReason =
    data.warningType === "sliding-window" ||
    data.warningType === "agent-run-spend-cap" ||
    data.warningType === "paid-daily-free-allowance"
      ? undefined
      : data.capReason;
  const extraUsageCta =
    data.warningType === "token-bucket" && !hideMonthlyWarning
      ? getExtraUsageLimitCta({
          subscription: data.subscription,
          capReason,
        })
      : null;
  const showUsageCta =
    data.warningType === "extra-usage-active" ||
    data.warningType === "paid-daily-free-allowance";
  const showUpgrade =
    !hideMonthlyWarning &&
    data.warningType !== "agent-run-spend-cap" &&
    data.warningType !== "extra-usage-active" &&
    data.warningType !== "paid-daily-free-allowance" &&
    shouldShowUpgradeCta({
      subscription: data.subscription,
      capReason,
    });
  const limitType =
    data.warningType === "sliding-window"
      ? "daily_requests"
      : data.warningType === "agent-run-spend-cap"
        ? "monthly"
        : data.warningType === "paid-daily-free-allowance"
          ? "paid_daily_free_allowance"
          : data.warningType === "token-bucket"
            ? getLimitTypeForCapReason(capReason)
            : getLimitTypeForCapReason(data.capReason ?? "extra_usage_active");
  const limitSeverity =
    data.warningType === "token-bucket" && data.remainingPercent === 0
      ? "hit"
      : "warning";
  const upgradeCtaText = getUpgradeCtaText(data, limitType);
  const ctaClassName = `h-7 text-xs font-medium border-black/8 dark:border-border ${compact ? "px-2.5" : "px-3"}`;

  useEffect(() => {
    if (!showUpgrade || capturedUpgradeImpressionRef.current) return;
    capturedUpgradeImpressionRef.current = true;
    captureUpgradeCtaImpression({
      surface: "rate_limit_warning",
      source: "limit_pressure",
      from_tier: data.subscription,
      limit_type: limitType,
      limit_severity: limitSeverity,
      cap_reason: capReason,
      cta_text: upgradeCtaText,
    });
  }, [
    capReason,
    data.subscription,
    limitSeverity,
    limitType,
    showUpgrade,
    upgradeCtaText,
  ]);

  useEffect(() => {
    if (!extraUsageCta || capturedAddCreditImpressionRef.current) return;
    capturedAddCreditImpressionRef.current = true;
    captureAddCreditCtaImpression({
      surface: "rate_limit_warning",
      source: "limit_pressure",
      from_tier: data.subscription,
      limit_type: limitType,
      limit_severity: limitSeverity,
      cap_reason: capReason,
      cta_text: extraUsageCta.analyticsText,
    });
  }, [capReason, data.subscription, extraUsageCta, limitSeverity, limitType]);

  if (hideMonthlyWarning) return null;

  return (
    <div
      data-testid="rate-limit-warning"
      className={`mb-2 flex items-center justify-between gap-2 rounded-[22px] border px-3 ${compact ? "mx-4 min-w-0 py-1.5" : "py-2.5"} ${WARNING_STYLES}`}
    >
      <div className="flex-1 flex items-center gap-2 flex-wrap">
        <span
          className={`text-foreground text-sm ${compact ? "leading-5" : ""}`}
        >
          {message}
        </span>
        {extraUsageCta && (
          <Button
            onClick={() => {
              captureAddCreditCtaClick({
                surface: "rate_limit_warning",
                source: "limit_pressure",
                from_tier: data.subscription,
                limit_type: limitType,
                limit_severity: limitSeverity,
                cap_reason: capReason,
                cta_text: extraUsageCta.analyticsText,
              });
              openSettingsDialog(extraUsageCta.settingsTab);
            }}
            size="sm"
            variant={
              extraUsageCta.analyticsText === "Add Credits"
                ? "default"
                : "outline"
            }
            className={ctaClassName}
          >
            {extraUsageCta.label}
          </Button>
        )}
        {showUsageCta && (
          <Button
            onClick={() => openSettingsDialog("Usage")}
            size="sm"
            variant="outline"
            className={ctaClassName}
          >
            View Usage
          </Button>
        )}
        {showUpgrade && (
          <Button
            onClick={() =>
              redirectToPricing({
                surface: "rate_limit_warning",
                source: "limit_pressure",
                from_tier: data.subscription,
                limit_type: limitType,
                reason: capReason,
                cta_text: upgradeCtaText,
              })
            }
            size="sm"
            variant="outline"
            className={ctaClassName}
          >
            {upgradeCtaText}
          </Button>
        )}
      </div>
      <button
        onClick={onDismiss}
        className={
          compact
            ? "flex h-7 w-7 flex-shrink-0 cursor-pointer items-center justify-center rounded-md text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            : "flex-shrink-0 text-muted-foreground hover:text-foreground cursor-pointer transition-colors"
        }
        aria-label="Dismiss warning"
      >
        <X className={compact ? "h-4 w-4" : "h-5 w-5"} />
      </button>
    </div>
  );
};
