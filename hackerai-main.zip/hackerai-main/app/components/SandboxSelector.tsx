"use client";

import {
  Check,
  Cloud,
  Laptop,
  LoaderCircle,
  Monitor,
  ChevronDown,
  ChevronRight,
  Plus,
} from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { useState, useEffect, useMemo } from "react";
import { toast } from "sonner";
import { openSettingsDialog } from "@/lib/utils/settings-dialog";
import { useTauri } from "@/app/hooks/useTauri";
import { detectPlatform } from "@/app/download/DownloadSection";
import { useGlobalState } from "@/app/contexts/GlobalState";
import { useInitialConnectionPending } from "@/app/hooks/useInitialConnectionPending";
import { useIsMobile } from "@/hooks/use-mobile";

import type { SetSandboxPreference } from "@/app/hooks/useSandboxPreference";
import {
  connectionMatchesPreference,
  environmentPreference,
  isDesktopPreference,
} from "@/lib/sandbox/environment";

interface SandboxSelectorProps {
  value: string;
  onChange?: SetSandboxPreference;
  disabled?: boolean;
  size?: "sm" | "toolbar" | "md";
  triggerLabel?: string;
  compact?: boolean;
  menuAlign?: "start" | "center" | "end";
  className?: string;
}

interface ConnectionOption {
  id: string;
  label: string;
  shortLabel: string;
  icon: typeof Cloud;
  disabled?: boolean;
}

export function SandboxSelector({
  value,
  onChange,
  disabled = false,
  size = "sm",
  triggerLabel,
  compact = false,
  menuAlign = "start",
  className,
}: SandboxSelectorProps) {
  const [open, setOpen] = useState(false);
  const [connectHovered, setConnectHovered] = useState(false);
  const isMobile = useIsMobile();
  useEffect(() => {
    // The composer swaps selector triggers at this breakpoint. Close the old
    // trigger's portals before they can remain anchored to a hidden element.
    setOpen(false);
    setConnectHovered(false);
  }, [isMobile]);
  const { isTauri } = useTauri();
  const {
    subscription,
    localConnections: connections,
    desktopBridgeStatus,
    desktopEnvironmentId,
  } = useGlobalState();
  const isFreeUser = subscription === "free";

  const selectedConnectionKnown = Boolean(
    connections?.some((connection) =>
      connectionMatchesPreference(connection, value),
    ),
  );
  const initialConnectionPending = useInitialConnectionPending({
    connected: selectedConnectionKnown,
    connectionCount: connections?.length,
    preference: value,
  });
  const selectedNativeDesktop =
    isTauri &&
    (value === "desktop" ||
      (desktopEnvironmentId !== undefined &&
        value === `desktop-environment:${desktopEnvironmentId}`));
  const computerConnectionPending = selectedNativeDesktop
    ? desktopBridgeStatus === "idle" || desktopBridgeStatus === "connecting"
    : initialConnectionPending;

  const detectedPlatform = useMemo(() => {
    if (typeof window === "undefined") return null;
    return detectPlatform();
  }, []);

  const cloudOption: ConnectionOption = {
    id: "e2b",
    label: "Cloud",
    shortLabel: "Cloud",
    icon: Cloud,
  };
  const desktopLabel =
    isTauri && desktopBridgeStatus !== "connected"
      ? desktopBridgeStatus === "connecting"
        ? "This computer reconnecting"
        : computerConnectionPending
          ? "This computer"
          : "This computer unavailable"
      : "This computer";
  const desktopConnection = connections?.find(
    (conn) =>
      conn.isDesktop &&
      (!isTauri ||
        !desktopEnvironmentId ||
        conn.environmentId === desktopEnvironmentId),
  );
  const desktopIsSelectable = !isTauri || desktopBridgeStatus === "connected";
  const desktopOptions: ConnectionOption[] = (connections ?? [])
    .filter(
      (conn, index, all) =>
        conn.isDesktop &&
        all.findIndex(
          (candidate) =>
            environmentPreference(candidate) === environmentPreference(conn),
        ) === index,
    )
    .map((conn) => {
      const isCurrentDesktop = isTauri && conn === desktopConnection;
      const label =
        isCurrentDesktop || !conn.environmentId
          ? desktopLabel
          : conn.osInfo?.hostname || conn.name;
      return {
        id:
          value === "desktop" && conn === desktopConnection
            ? "desktop"
            : environmentPreference(conn),
        label,
        shortLabel: label,
        icon: Monitor,
        disabled: isCurrentDesktop && !desktopIsSelectable,
      };
    });
  const remoteConnections = useMemo(
    () => connections?.filter((conn) => !conn.isDesktop) ?? [],
    [connections],
  );
  const remoteConnectionIds = useMemo(
    () =>
      remoteConnections
        .map((connection) => connection.connectionId)
        .sort()
        .join(","),
    [remoteConnections],
  );
  const shouldVerifyRemotePresence =
    isTauri &&
    desktopBridgeStatus !== "connected" &&
    remoteConnections.length > 0;
  const remotePresenceRequest = useMemo(
    () => ({
      enabled: shouldVerifyRemotePresence,
      connectionIds: remoteConnectionIds,
    }),
    [remoteConnectionIds, shouldVerifyRemotePresence],
  );
  const [remotePresence, setRemotePresence] = useState<{
    request: typeof remotePresenceRequest;
    onlineConnectionIds: Set<string>;
  } | null>(null);
  const onlineRemoteConnectionIds =
    remotePresence?.request === remotePresenceRequest
      ? remotePresence.onlineConnectionIds
      : null;
  const liveRemoteConnections = useMemo(
    () =>
      shouldVerifyRemotePresence && onlineRemoteConnectionIds
        ? remoteConnections.filter((connection) =>
            onlineRemoteConnectionIds.has(connection.connectionId),
          )
        : remoteConnections,
    [onlineRemoteConnectionIds, remoteConnections, shouldVerifyRemotePresence],
  );
  const remoteOptions: ConnectionOption[] = liveRemoteConnections
    .filter(
      (conn, index, all) =>
        all.findIndex(
          (candidate) =>
            environmentPreference(candidate) === environmentPreference(conn),
        ) === index,
    )
    .map((conn) => ({
      id: value === conn.connectionId ? value : environmentPreference(conn),
      label: conn.osInfo?.hostname || conn.name,
      shortLabel: conn.osInfo?.hostname || conn.name,
      icon: Laptop,
    }));
  const options = [cloudOption, ...desktopOptions, ...remoteOptions];

  // A connected Convex row can briefly exist before the command relay has
  // subscribed. Confirm live Centrifugo presence before automatically choosing
  // a remote runner over a reconnecting embedded bridge.
  useEffect(() => {
    if (!remotePresenceRequest.enabled) return;

    let cancelled = false;
    fetch("/api/sandbox/presence")
      .then((response) => {
        if (!response.ok) throw new Error("Presence check failed");
        return response.json() as Promise<{
          connections?: Array<{ connectionId?: string; online?: boolean }>;
        }>;
      })
      .then((presence) => {
        if (cancelled) return;
        setRemotePresence({
          request: remotePresenceRequest,
          onlineConnectionIds: new Set(
            (presence.connections ?? [])
              .filter(
                (connection) =>
                  connection.online &&
                  typeof connection.connectionId === "string",
              )
              .map((connection) => connection.connectionId as string),
          ),
        });
      })
      .catch(() => {
        // Keep the remote options visible for manual selection, but do not
        // auto-select one without authoritative presence.
      });

    return () => {
      cancelled = true;
    };
  }, [remotePresenceRequest]);

  // Trigger presence cleanup when dropdown opens
  useEffect(() => {
    if (open) {
      fetch("/api/sandbox/presence").catch(() => {});
    }
  }, [open]);

  // Availability must never replace the user's selected computer.
  const valueMatchesOption = options.some((opt) => opt.id === value);
  // Choose an initial local default for free users, without replacing a
  // previously selected computer when it disconnects.
  useEffect(() => {
    if (!isFreeUser || !connections?.length) return;

    const firstRemote = shouldVerifyRemotePresence
      ? onlineRemoteConnectionIds
        ? liveRemoteConnections[0]
        : undefined
      : remoteConnections[0];
    const preferredLocal =
      desktopConnection && desktopIsSelectable
        ? environmentPreference(desktopConnection)
        : firstRemote
          ? environmentPreference(firstRemote)
          : undefined;
    if (!preferredLocal) return;

    if (value === "e2b") {
      onChange?.(preferredLocal, { remember: false });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    isFreeUser,
    value,
    connections,
    desktopConnection,
    desktopIsSelectable,
    isTauri,
    shouldVerifyRemotePresence,
    onlineRemoteConnectionIds,
    liveRemoteConnections,
    remoteConnections,
  ]);

  const selectedComputerLabel =
    selectedNativeDesktop || value === "desktop"
      ? "This computer"
      : "Selected computer";
  const unavailableLocalOption: ConnectionOption | null =
    value !== "e2b" && !valueMatchesOption
      ? {
          id: value,
          label:
            selectedNativeDesktop && desktopBridgeStatus === "connecting"
              ? `${selectedComputerLabel} reconnecting`
              : computerConnectionPending
                ? selectedComputerLabel
                : `${selectedComputerLabel} unavailable`,
          shortLabel:
            selectedNativeDesktop && desktopBridgeStatus === "connecting"
              ? `${selectedComputerLabel} reconnecting`
              : computerConnectionPending
                ? selectedComputerLabel
                : selectedNativeDesktop && desktopBridgeStatus === "connected"
                  ? selectedComputerLabel
                  : `${selectedComputerLabel} unavailable`,
          icon: isDesktopPreference(value) ? Monitor : Laptop,
        }
      : null;
  const selectedOption =
    options.find((option) => option.id === value) ??
    unavailableLocalOption ??
    cloudOption;
  const showReconnecting =
    compact &&
    !triggerLabel &&
    selectedNativeDesktop &&
    desktopBridgeStatus === "connecting";
  const Icon = showReconnecting ? LoaderCircle : selectedOption.icon;
  const compactLabel =
    selectedNativeDesktop || value === "desktop" || unavailableLocalOption
      ? selectedComputerLabel
      : selectedOption.shortLabel;

  const buttonClassName =
    size === "md"
      ? "h-9 max-w-full px-3 gap-2 text-sm font-medium rounded-md bg-transparent hover:bg-muted/30 focus-visible:ring-1 min-w-0 shrink"
      : size === "toolbar"
        ? "h-7 max-w-full px-2 gap-1 text-sm font-medium rounded-md bg-transparent hover:bg-muted/30 focus-visible:ring-1 min-w-0 shrink sm:max-w-[min(100%,16rem)]"
        : "h-7 max-w-full px-2 gap-1 text-xs font-medium rounded-md bg-transparent hover:bg-muted/30 focus-visible:ring-1 min-w-0 shrink";

  const iconClassName = size === "md" ? "h-4 w-4 shrink-0" : "h-3 w-3 shrink-0";

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size={size === "md" ? "default" : "sm"}
          disabled={disabled}
          className={`${buttonClassName} ${className ?? ""}`}
          title={triggerLabel ?? selectedOption?.label}
          aria-label={triggerLabel ?? selectedOption.label}
        >
          <Icon
            aria-hidden="true"
            className={`${iconClassName}${showReconnecting ? " animate-spin motion-reduce:animate-none" : ""}`}
          />
          <span className="min-w-0 flex-1 truncate text-left">
            {triggerLabel ??
              (compact ? compactLabel : selectedOption.shortLabel)}
          </span>
          <ChevronDown
            className={
              size === "md" ? "h-4 w-4 ml-1 shrink-0" : "h-3 w-3 ml-1 shrink-0"
            }
          />
        </Button>
      </PopoverTrigger>
      <PopoverContent
        data-chat-input-agent-menu
        className="w-[240px] p-1 data-[state=closed]:hidden"
        align={menuAlign}
      >
        <div className="space-y-0.5">
          <button
            key={cloudOption.id}
            onClick={() => {
              if (isFreeUser) {
                toast.info("Cloud sandbox requires a Pro plan", {
                  description:
                    "Use this computer or connect another computer for free, or upgrade to Pro for cloud access.",
                });
                return;
              }
              onChange?.(cloudOption.id);
              setOpen(false);
            }}
            className={`w-full flex items-center gap-2.5 p-2 rounded-md text-left transition-colors ${
              isFreeUser
                ? "opacity-60 cursor-not-allowed"
                : value === cloudOption.id
                  ? "bg-accent text-accent-foreground"
                  : "hover:bg-muted"
            }`}
          >
            <Cloud className="h-4 w-4 shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">
                {cloudOption.label}
              </div>
            </div>
            {isFreeUser ? (
              <span className="text-[10px] font-semibold bg-primary/10 text-primary px-1.5 py-0.5 rounded">
                Pro
              </span>
            ) : (
              value === cloudOption.id && <Check className="h-4 w-4 shrink-0" />
            )}
          </button>

          {desktopOptions.map((option) => {
            const OptionIcon = option.icon;
            return (
              <button
                key={option.id}
                disabled={option.disabled}
                onClick={() => {
                  if (option.disabled) return;
                  onChange?.(
                    option.id === "desktop" && desktopConnection
                      ? environmentPreference(desktopConnection)
                      : option.id,
                  );
                  setOpen(false);
                }}
                className={`w-full flex items-center gap-2.5 p-2 rounded-md text-left transition-colors ${
                  option.disabled
                    ? "opacity-60 cursor-not-allowed"
                    : value === option.id
                      ? "bg-accent text-accent-foreground"
                      : "hover:bg-muted"
                }`}
              >
                <OptionIcon className="h-4 w-4 shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">
                    {option.label}
                  </div>
                </div>
                {value === option.id && <Check className="h-4 w-4 shrink-0" />}
              </button>
            );
          })}

          {!isTauri && desktopOptions.length === 0 && (
            <Popover open={connectHovered} onOpenChange={setConnectHovered}>
              <PopoverTrigger asChild>
                <button
                  onMouseEnter={() => setConnectHovered(true)}
                  onMouseLeave={() => setConnectHovered(false)}
                  className="w-full flex items-center gap-2.5 p-2 rounded-md text-left transition-colors hover:bg-muted"
                >
                  <Monitor className="h-4 w-4 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">
                      Connect My Computer
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                </button>
              </PopoverTrigger>
              <PopoverContent
                data-chat-input-agent-menu
                side="top"
                sideOffset={8}
                className="w-[240px] p-4"
                onMouseEnter={() => setConnectHovered(true)}
                onMouseLeave={() => setConnectHovered(false)}
              >
                <div className="flex items-center justify-center rounded-md border bg-gradient-to-b from-muted/50 to-muted py-5 mb-3">
                  <Monitor className="h-10 w-10 text-muted-foreground/70" />
                </div>
                <h4 className="text-sm font-semibold mb-1">My Computer</h4>
                <p className="text-xs text-muted-foreground mb-3">
                  Download the desktop app to grant HackerAI access to your
                  computer.
                </p>
                <Button asChild size="sm" className="w-full">
                  <a
                    href={
                      detectedPlatform?.platform === "unknown"
                        ? "/download"
                        : detectedPlatform?.downloadUrl || "/download"
                    }
                  >
                    {detectedPlatform && detectedPlatform.platform !== "unknown"
                      ? `Download for ${detectedPlatform.displayName}`
                      : "Download desktop"}
                  </a>
                </Button>
              </PopoverContent>
            </Popover>
          )}

          <div className="border-t mt-1 pt-1">
            <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground">
              Remote control
            </div>
            {remoteOptions.map((option) => {
              const OptionIcon = option.icon;
              return (
                <button
                  key={option.id}
                  onClick={() => {
                    onChange?.(option.id);
                    setOpen(false);
                  }}
                  className={`w-full flex items-center gap-2.5 p-2 rounded-md text-left transition-colors ${
                    value === option.id
                      ? "bg-accent text-accent-foreground"
                      : "hover:bg-muted"
                  }`}
                >
                  <OptionIcon className="h-4 w-4 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">
                      {option.label}
                    </div>
                  </div>
                  {value === option.id && (
                    <Check className="h-4 w-4 shrink-0" />
                  )}
                </button>
              );
            })}
            <button
              onClick={() => {
                setOpen(false);
                openSettingsDialog("Remote Control");
              }}
              className="w-full flex items-center gap-2.5 p-2 rounded-md text-left text-sm hover:bg-muted transition-colors"
            >
              <Plus className="h-4 w-4 shrink-0 text-muted-foreground" />
              <span className="flex-1">Add remote control</span>
            </button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
