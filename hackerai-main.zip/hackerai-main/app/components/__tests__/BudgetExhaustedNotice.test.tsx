jest.mock("../BlockedChatBillingRecovery", () => ({
  BlockedChatBillingRecovery: ({
    children,
  }: {
    children: import("react").ReactNode;
  }) => children,
}));
import "@testing-library/jest-dom";
import { beforeEach, describe, expect, it, jest } from "@jest/globals";
import { fireEvent, render, screen } from "@testing-library/react";
import type { SubscriptionTier } from "@/types";

let mockSubscription: SubscriptionTier = "pro";
let mockCheckingPlan = false;
let mockIncludedUsageRemaining = 0;
let mockMonthlyStatusConfirmed = true;
let mockIncludedUsageLoading = false;
let mockIncludedUsageError = false;
let mockDailyAllowance:
  { available: boolean; costRemainingDollars?: number } | undefined;
const mockUseQuery = jest.fn();
jest.mock("@/app/contexts/GlobalState", () => ({
  useGlobalState: () => ({
    subscription: mockSubscription,
    isCheckingProPlan: mockCheckingPlan,
  }),
}));
jest.mock("convex/react", () => ({
  useQuery: (...args: unknown[]) => mockUseQuery(...args),
  useAction: () => jest.fn(),
}));
jest.mock("@workos-inc/authkit-nextjs/components", () => ({
  useAuth: () => ({ user: { id: "test-user" } }),
}));
jest.mock("swr", () => ({
  __esModule: true,
  default: (key: string[] | null) =>
    key?.[0] === "stopped-agent-daily-allowance"
      ? { data: mockDailyAllowance }
      : {
          data: mockIncludedUsageError
            ? undefined
            : {
                monthlyStatusConfirmed: mockMonthlyStatusConfirmed,
                monthly: { remaining: mockIncludedUsageRemaining },
              },
          isLoading: mockIncludedUsageLoading,
          error: mockIncludedUsageError
            ? new Error("usage unavailable")
            : undefined,
        },
}));
jest.mock("@/app/hooks/usePricingDialog", () => ({
  redirectToPricing: jest.fn(),
}));
jest.mock("@/lib/utils/settings-dialog", () => ({
  openSettingsDialog: jest.fn(),
}));

const { BudgetExhaustedNotice } = require("../BudgetExhaustedNotice");
const { openSettingsDialog } = require("@/lib/utils/settings-dialog");
const { redirectToPricing } = require("@/app/hooks/usePricingDialog");

const emptyEntitlement = {
  extraUsageAvailable: false,
  reason: "empty",
  hasBalance: false,
  autoReloadEnabled: false,
};
const availableEntitlement = {
  ...emptyEntitlement,
  extraUsageAvailable: true,
  reason: "available",
  hasBalance: true,
};

describe("BudgetExhaustedNotice", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockSubscription = "pro";
    mockDailyAllowance = undefined;
    mockCheckingPlan = false;
    mockIncludedUsageRemaining = 0;
    mockMonthlyStatusConfirmed = true;
    mockIncludedUsageLoading = false;
    mockIncludedUsageError = false;
    mockUseQuery.mockReturnValue(emptyEntitlement);
  });

  it("offers Continue when a new paid plan has included usage without Extra Usage", () => {
    mockUseQuery.mockReturnValue({
      ...emptyEntitlement,
      reason: "disabled",
    });
    mockIncludedUsageRemaining = 100;
    const onContinue = jest.fn();
    render(<BudgetExhaustedNotice onContinue={onContinue} />);

    expect(screen.getByText(/Usage is available now/)).toBeInTheDocument();
    expect(
      screen.queryByRole("button", { name: "Enable Extra Usage" }),
    ).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Manage usage" }));
    expect(openSettingsDialog).toHaveBeenCalledWith("Usage");
    fireEvent.click(screen.getByRole("button", { name: "Continue" }));
    expect(onContinue).toHaveBeenCalledTimes(1);
  });

  it("waits for the included allowance check before recommending Extra Usage", () => {
    mockIncludedUsageLoading = true;
    mockUseQuery.mockReturnValue({
      ...emptyEntitlement,
      reason: "disabled",
    });
    render(<BudgetExhaustedNotice onContinue={jest.fn()} />);

    expect(
      screen.getByRole("button", { name: "Checking usage…" }),
    ).toBeDisabled();
    expect(screen.getByRole("button", { name: "Try again" })).toBeDisabled();
    expect(
      screen.queryByRole("button", { name: "Enable Extra Usage" }),
    ).not.toBeInTheDocument();
  });

  it("uses neutral recovery copy when the included allowance check fails", () => {
    mockIncludedUsageError = true;
    mockUseQuery.mockReturnValue({
      ...emptyEntitlement,
      reason: "disabled",
    });
    render(<BudgetExhaustedNotice onContinue={jest.fn()} />);

    expect(
      screen.getByText(/couldn't check your current allowance/),
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Manage usage" })).toBeEnabled();
    expect(
      screen.queryByRole("button", { name: "Enable Extra Usage" }),
    ).not.toBeInTheDocument();
  });

  it("does not treat fallback allowance as confirmed available usage", () => {
    mockIncludedUsageRemaining = 100;
    mockMonthlyStatusConfirmed = false;
    mockUseQuery.mockReturnValue({ ...emptyEntitlement, reason: "disabled" });
    render(<BudgetExhaustedNotice onContinue={jest.fn()} />);

    expect(
      screen.getByText(/couldn't check your current allowance/),
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Manage usage" })).toBeEnabled();
    expect(
      screen.queryByRole("button", { name: "Continue" }),
    ).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Try again" })).toBeEnabled();
  });

  it("opens Extra Usage from the empty-balance notice without starting a run", () => {
    const onContinue = jest.fn();
    render(<BudgetExhaustedNotice onContinue={onContinue} />);

    fireEvent.click(screen.getByRole("button", { name: "Add credits" }));

    expect(openSettingsDialog).toHaveBeenCalledWith("Extra Usage");
    expect(onContinue).not.toHaveBeenCalled();
  });

  it("reacts to a credited purchase and continues only when clicked", () => {
    const onContinue = jest.fn();
    const { rerender } = render(
      <BudgetExhaustedNotice onContinue={onContinue} />,
    );
    expect(screen.getByRole("button", { name: "Add credits" })).toBeEnabled();

    mockUseQuery.mockReturnValue(availableEntitlement);
    rerender(<BudgetExhaustedNotice onContinue={onContinue} />);

    expect(
      screen.queryByRole("button", { name: "Add credits" }),
    ).not.toBeInTheDocument();
    expect(
      screen.getByText(/Continue to resume where it stopped/),
    ).toBeInTheDocument();
    expect(onContinue).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole("button", { name: "Continue" }));
    expect(onContinue).toHaveBeenCalledTimes(1);
    expect(onContinue).toHaveBeenCalledWith();
  });

  it("shows Continue when reopening a stopped chat after topping up", () => {
    mockUseQuery.mockReturnValue(availableEntitlement);
    render(<BudgetExhaustedNotice onContinue={jest.fn()} />);

    expect(screen.getByRole("button", { name: "Continue" })).toBeEnabled();
  });

  it("offers spending-limit recovery despite having credits and updates after the cap changes", () => {
    mockUseQuery.mockReturnValue({
      ...availableEntitlement,
      extraUsageAvailable: false,
      reason: "monthly_cap_exhausted",
      monthlyRemainingDollars: 0,
    });
    const { rerender } = render(
      <BudgetExhaustedNotice onContinue={jest.fn()} />,
    );

    expect(
      screen.queryByRole("button", { name: "Continue" }),
    ).not.toBeInTheDocument();
    fireEvent.click(
      screen.getByRole("button", { name: "Manage spending limit" }),
    );
    expect(openSettingsDialog).toHaveBeenCalledWith("Extra Usage");
    expect(screen.getByText(/Extra Usage spending limit/)).toBeInTheDocument();

    mockUseQuery.mockReturnValue(availableEntitlement);
    rerender(<BudgetExhaustedNotice onContinue={jest.fn()} />);
    expect(screen.getByRole("button", { name: "Continue" })).toBeEnabled();
  });

  it("directs funded but disabled Extra Usage to settings", () => {
    mockUseQuery.mockReturnValue({
      ...availableEntitlement,
      extraUsageAvailable: false,
      reason: "disabled",
    });
    render(<BudgetExhaustedNotice onContinue={jest.fn()} />);

    fireEvent.click(screen.getByRole("button", { name: "Enable Extra Usage" }));
    expect(openSettingsDialog).toHaveBeenCalledWith("Extra Usage");
    expect(
      screen.queryByRole("button", { name: "Continue" }),
    ).not.toBeInTheDocument();
  });

  it("does not treat auto-reload with an empty wallet as a completed top-up", () => {
    mockUseQuery.mockReturnValue({
      ...availableEntitlement,
      hasBalance: false,
      autoReloadEnabled: true,
    });
    render(<BudgetExhaustedNotice onContinue={jest.fn()} />);

    expect(screen.getByRole("button", { name: "Add credits" })).toBeEnabled();
    expect(
      screen.queryByRole("button", { name: "Continue" }),
    ).not.toBeInTheDocument();
  });

  it("allows a manual server recheck for resets or recovered billing failures", () => {
    const onContinue = jest.fn();
    render(<BudgetExhaustedNotice onContinue={onContinue} />);

    fireEvent.click(screen.getByRole("button", { name: "Try again" }));
    expect(onContinue).toHaveBeenCalledTimes(1);
  });

  it("does not offer a retry when there is no continuation handler", () => {
    render(<BudgetExhaustedNotice />);

    expect(screen.getByRole("button", { name: "Add credits" })).toBeEnabled();
    expect(
      screen.queryByRole("button", { name: "Try again" }),
    ).not.toBeInTheDocument();
  });

  it("waits for live wallet data before recommending a purchase", () => {
    mockUseQuery.mockReturnValue(undefined);
    const onContinue = jest.fn();
    render(<BudgetExhaustedNotice onContinue={onContinue} />);

    expect(
      screen.getByRole("button", { name: "Checking usage…" }),
    ).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: "Try again" }));
    expect(onContinue).not.toHaveBeenCalled();
  });

  it("keeps an unknown entitlement recoverable without claiming that credits are empty", () => {
    mockUseQuery.mockReturnValue(null);
    render(<BudgetExhaustedNotice onContinue={jest.fn()} />);

    expect(screen.getByRole("button", { name: "Manage usage" })).toBeEnabled();
    expect(screen.getByRole("button", { name: "Try again" })).toBeEnabled();
  });

  it("offers an upgrade for free users without consulting a personal wallet", () => {
    mockSubscription = "free";
    mockUseQuery.mockReturnValue(undefined);
    render(<BudgetExhaustedNotice onContinue={jest.fn()} />);

    expect(mockUseQuery).toHaveBeenCalledWith(expect.anything(), "skip");
    fireEvent.click(screen.getByRole("button", { name: "Upgrade plan" }));
    expect(redirectToPricing).toHaveBeenCalledWith(
      expect.objectContaining({
        from_tier: "free",
        surface: "budget_exhausted_notice",
      }),
    );
    expect(screen.getByRole("button", { name: "Try again" })).toBeEnabled();
  });

  it("routes team members to usage without offering a personal wallet purchase", () => {
    mockSubscription = "team";
    mockUseQuery.mockReturnValue(undefined);
    render(<BudgetExhaustedNotice onContinue={jest.fn()} />);

    expect(mockUseQuery).toHaveBeenCalledWith(expect.anything(), "skip");
    fireEvent.click(screen.getByRole("button", { name: "Manage usage" }));
    expect(openSettingsDialog).toHaveBeenCalledWith("Usage");
    expect(
      screen.queryByRole("button", { name: "Add credits" }),
    ).not.toBeInTheDocument();
  });
});

describe("stopped Agent daily allowance", () => {
  beforeEach(() => {
    mockSubscription = "pro";
    mockCheckingPlan = false;
    mockIncludedUsageRemaining = 0;
    mockMonthlyStatusConfirmed = true;
    mockIncludedUsageLoading = false;
    mockIncludedUsageError = false;
    mockUseQuery.mockReturnValue(emptyEntitlement);
  });
  it("resumes saved progress with explicit Auto and rescue consent", () => {
    mockDailyAllowance = { available: true, costRemainingDollars: 0.12 };
    const onContinue = jest.fn();
    render(<BudgetExhaustedNotice mode="agent" onContinue={onContinue} />);
    expect(screen.getByText(/0.12 remaining/)).toBeVisible();
    fireEvent.click(
      screen.getByRole("button", { name: "Continue with daily allowance" }),
    );
    expect(onContinue).toHaveBeenCalledWith("auto", {
      type: "paid_daily_free_allowance",
    });
  });
  it.each([false, undefined])(
    "does not offer unavailable or unknown allowance (%s)",
    (available) => {
      mockDailyAllowance = available === undefined ? undefined : { available };
      render(<BudgetExhaustedNotice mode="agent" onContinue={jest.fn()} />);
      expect(
        screen.queryByRole("button", { name: "Continue with daily allowance" }),
      ).not.toBeInTheDocument();
    },
  );
  it("disables the fallback while continuation is pending", () => {
    mockDailyAllowance = { available: true };
    render(
      <BudgetExhaustedNotice mode="agent" pending onContinue={jest.fn()} />,
    );
    screen
      .getAllByRole("button", { name: "Resuming…" })
      .forEach((button) => expect(button).toBeDisabled());
  });
  it("does not show the Agent fallback for Ask", () => {
    mockDailyAllowance = { available: true };
    render(<BudgetExhaustedNotice mode="ask" onContinue={jest.fn()} />);
    expect(
      screen.queryByRole("button", { name: "Continue with daily allowance" }),
    ).not.toBeInTheDocument();
  });
});
