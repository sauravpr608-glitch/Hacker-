jest.mock("../BlockedChatBillingRecovery", () => ({
  BlockedChatBillingRecovery: ({
    children,
  }: {
    children: import("react").ReactNode;
  }) => children,
}));
import "@testing-library/jest-dom";
import { describe, expect, it, jest, beforeEach } from "@jest/globals";
import { render, screen } from "@testing-library/react";
import { setMockQueryResult } from "@/__mocks__/convex-react";

const monthlyWarning = {
  warningType: "token-bucket" as const,
  bucketType: "monthly" as const,
  remainingPercent: 3,
  resetTime: new Date(Date.now() + 9 * 24 * 60 * 60_000),
  subscription: "pro-plus" as const,
  capReason: "monthly_near_limit",
  usedDollars: 57.99,
  limitDollars: 60,
};

jest.mock("@/lib/analytics/client", () => ({
  captureAddCreditCtaClick: jest.fn(),
  captureAddCreditCtaImpression: jest.fn(),
  captureUpgradeCtaImpression: jest.fn(),
}));

jest.mock("@/lib/utils/settings-dialog", () => ({
  openSettingsDialog: jest.fn(),
}));

const { RateLimitWarning } = require("../RateLimitWarning");
const {
  captureAddCreditCtaImpression,
  captureUpgradeCtaImpression,
} = require("@/lib/analytics/client");

describe("RateLimitWarning", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    setMockQueryResult(null);
  });

  it("removes an existing monthly warning as soon as purchased credit becomes usable", () => {
    const { rerender } = render(
      <RateLimitWarning data={monthlyWarning} onDismiss={jest.fn()} />,
    );
    expect(screen.getByRole("button", { name: "Add Credits" })).toBeVisible();

    setMockQueryResult({ extraUsageAvailable: true, hasBalance: true });
    rerender(<RateLimitWarning data={monthlyWarning} onDismiss={jest.fn()} />);
    expect(screen.queryByTestId("rate-limit-warning")).not.toBeInTheDocument();

    setMockQueryResult({ extraUsageAvailable: false, hasBalance: false });
    rerender(<RateLimitWarning data={monthlyWarning} onDismiss={jest.fn()} />);
    expect(screen.getByRole("button", { name: "Add Credits" })).toBeVisible();
  });

  it.each(["pro", "pro-plus", "ultra"] as const)(
    "hides the near-limit banner and purchase impressions for %s with usable credit",
    (subscription) => {
      setMockQueryResult({ extraUsageAvailable: true, hasBalance: true });
      render(
        <RateLimitWarning
          data={{ ...monthlyWarning, subscription }}
          onDismiss={jest.fn()}
        />,
      );
      expect(
        screen.queryByTestId("rate-limit-warning"),
      ).not.toBeInTheDocument();
      expect(captureAddCreditCtaImpression).not.toHaveBeenCalled();
      expect(captureUpgradeCtaImpression).not.toHaveBeenCalled();
    },
  );

  it("waits for the wallet query without flashing a purchase CTA", () => {
    setMockQueryResult(undefined);
    const { rerender } = render(
      <RateLimitWarning data={monthlyWarning} onDismiss={jest.fn()} />,
    );
    expect(screen.queryByTestId("rate-limit-warning")).not.toBeInTheDocument();
    expect(captureAddCreditCtaImpression).not.toHaveBeenCalled();
    setMockQueryResult({ extraUsageAvailable: false, hasBalance: false });
    rerender(<RateLimitWarning data={monthlyWarning} onDismiss={jest.fn()} />);
    expect(screen.getByRole("button", { name: "Add Credits" })).toBeVisible();
    expect(captureAddCreditCtaImpression).toHaveBeenCalledTimes(1);
  });

  it.each([
    { reason: "disabled", extraUsageAvailable: false, hasBalance: true },
    {
      reason: "monthly_cap_exhausted",
      extraUsageAvailable: false,
      hasBalance: true,
    },
    { reason: "empty", extraUsageAvailable: false, hasBalance: false },
    { reason: "available", extraUsageAvailable: true, hasBalance: false },
  ])(
    "keeps the warning without usable prepaid credit: $reason / balance $hasBalance",
    (wallet) => {
      setMockQueryResult(wallet);
      render(<RateLimitWarning data={monthlyWarning} onDismiss={jest.fn()} />);
      expect(screen.getByTestId("rate-limit-warning")).toBeVisible();
    },
  );

  it("hides mid-stream near-limit warnings without a cap reason", () => {
    setMockQueryResult({ extraUsageAvailable: true, hasBalance: true });
    render(
      <RateLimitWarning
        data={{ ...monthlyWarning, capReason: undefined, midStream: true }}
        onDismiss={jest.fn()}
      />,
    );
    expect(screen.queryByTestId("rate-limit-warning")).not.toBeInTheDocument();
  });

  it.each(["monthly_exhausted", "extra_usage_cap", "team_member_cap"])(
    "preserves actual cutoff warnings even with personal credit: %s",
    (capReason) => {
      setMockQueryResult({ extraUsageAvailable: true, hasBalance: true });
      render(
        <RateLimitWarning
          data={{
            ...monthlyWarning,
            remainingPercent: 0,
            capReason,
            cutOff: true,
          }}
          onDismiss={jest.fn()}
        />,
      );
      expect(screen.getByText(/this response was cut off/i)).toBeVisible();
    },
  );

  it.each(["free", "team"] as const)(
    "preserves %s warnings regardless of personal credit",
    (subscription) => {
      setMockQueryResult({ extraUsageAvailable: true, hasBalance: true });
      render(
        <RateLimitWarning
          data={{ ...monthlyWarning, subscription }}
          onDismiss={jest.fn()}
        />,
      );
      expect(screen.getByTestId("rate-limit-warning")).toBeVisible();
    },
  );

  it("uses generic copy for free monthly exhaustion", () => {
    render(
      <RateLimitWarning
        data={{
          warningType: "token-bucket",
          bucketType: "monthly",
          remainingPercent: 0,
          resetTime: new Date(Date.now() + 60_000),
          subscription: "free",
          capReason: "free_monthly_exhausted",
        }}
        onDismiss={jest.fn()}
      />,
    );

    expect(
      screen.getByText(/You've reached your free monthly usage limit/i),
    ).toHaveTextContent("Upgrade for higher limits");
    expect(screen.queryByText(/Agent/i)).not.toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /keep going/i }),
    ).toBeInTheDocument();
  });

  it("keeps Agent-specific copy for exhausted Agent daily requests", () => {
    render(
      <RateLimitWarning
        data={{
          warningType: "sliding-window",
          remaining: 0,
          resetTime: new Date(Date.now() + 60_000),
          mode: "agent",
          subscription: "free",
        }}
        onDismiss={jest.fn()}
      />,
    );

    expect(screen.getByText(/free Agent requests/i)).toBeInTheDocument();
  });

  it("explains when a paid Agent run uses the daily free allowance", () => {
    render(
      <RateLimitWarning
        data={{
          warningType: "paid-daily-free-allowance",
          resetTime: new Date(Date.now() + 60_000),
          subscription: "pro",
          mode: "agent",
          costLimitDollars: 0.25,
        }}
        onDismiss={jest.fn()}
      />,
    );

    expect(screen.getByText(/this Agent response/i)).toHaveTextContent(
      "today's free $0.25 allowance",
    );
    expect(screen.getByText(/this Agent response/i)).toHaveTextContent(
      "low-cost model",
    );
    expect(
      screen.getByRole("button", { name: /view usage/i }),
    ).toBeInTheDocument();
    expect(
      screen.queryByRole("button", { name: /upgrade plan/i }),
    ).not.toBeInTheDocument();
  });

  it("renders legacy Pro Agent run cap copy without upgrade or add-credit CTAs", () => {
    render(
      <RateLimitWarning
        data={{
          warningType: "agent-run-spend-cap",
          resetTime: new Date(Date.now() + 60_000),
          subscription: "pro",
          mode: "agent",
          runCostDollars: 5.24,
          runCapDollars: 5,
          monthlyRemainingDollars: 20,
          capBasis: "fixed_5_dollars",
          premiumContinuationAllowed: true,
        }}
        onDismiss={jest.fn()}
      />,
    );

    expect(screen.getByText(/Pro Agent run paused/i)).toHaveTextContent(
      "$5.24",
    );
    expect(screen.getByText(/legacy per-run safety cap/i)).toHaveTextContent(
      "Continue to keep working",
    );
    expect(
      screen.queryByRole("button", { name: /upgrade plan/i }),
    ).not.toBeInTheDocument();
    expect(
      screen.queryByRole("button", { name: /add credits/i }),
    ).not.toBeInTheDocument();
  });

  it("uses current-model continuation copy when premium continuation is unavailable", () => {
    render(
      <RateLimitWarning
        data={{
          warningType: "agent-run-spend-cap",
          resetTime: new Date(Date.now() + 60_000),
          subscription: "pro",
          mode: "agent",
          runCostDollars: 5.24,
          runCapDollars: 5,
          monthlyRemainingDollars: 20,
          capBasis: "fixed_5_dollars",
          premiumContinuationAllowed: false,
        }}
        onDismiss={jest.fn()}
      />,
    );

    expect(screen.getByText(/Pro Agent run paused/i)).toHaveTextContent(
      "Continue to keep working",
    );
  });

  it("uses extra usage copy when paid overflow credits are active", () => {
    render(
      <RateLimitWarning
        data={{
          warningType: "extra-usage-active",
          bucketType: "monthly",
          resetTime: new Date(Date.now() + 60_000),
          subscription: "pro",
          capReason: "extra_usage_active",
        }}
        onDismiss={jest.fn()}
      />,
    );

    expect(
      screen.getByText(/You're now using extra usage credits/i),
    ).toHaveTextContent("Your monthly limit resets");
    expect(
      screen.queryByText(/You've reached your monthly usage limit/i),
    ).not.toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /view usage/i }),
    ).toBeInTheDocument();
  });

  it("names the spending limit when extra usage balance exists but the monthly cap is hit", () => {
    render(
      <RateLimitWarning
        data={{
          warningType: "token-bucket",
          bucketType: "monthly",
          remainingPercent: 0,
          resetTime: new Date(Date.now() + 60_000),
          subscription: "ultra",
          capReason: "extra_usage_cap",
          cutOff: true,
        }}
        onDismiss={jest.fn()}
      />,
    );

    expect(screen.getByText(/extra usage spending limit/i)).toHaveTextContent(
      "Increase your limit to continue",
    );
    expect(
      screen.queryByText(/extra usage balance is empty/i),
    ).not.toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /increase limit/i }),
    ).toBeInTheDocument();
  });
});

it("shows the daily Free Agent allowance and reset on a mid-stream cutoff", () => {
  render(
    <RateLimitWarning
      onDismiss={jest.fn()}
      data={{
        warningType: "token-bucket",
        bucketType: "daily",
        subscription: "free",
        remainingPercent: 0,
        usedDollars: 0.1,
        limitDollars: 0.1,
        capReason: "free_daily_cost_exhausted",
        midStream: true,
        cutOff: true,
        resetTime: new Date(Date.now() + 3600000),
      }}
    />,
  );
  expect(
    screen.getByText(
      /today's free Agent allowance and this response was cut off/,
    ),
  ).toBeVisible();
  expect(screen.getByText(/midnight UTC/)).toBeVisible();
  expect(screen.getByRole("button", { name: "Keep going" })).toBeVisible();
  expect(screen.queryByText(/monthly usage/)).not.toBeInTheDocument();
});
