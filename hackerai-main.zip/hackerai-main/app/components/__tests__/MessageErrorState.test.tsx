jest.mock("../BlockedChatBillingRecovery", () => ({
  BlockedChatBillingRecovery: ({
    children,
  }: {
    children: import("react").ReactNode;
  }) => children,
}));
import "@testing-library/jest-dom";
import {
  afterEach,
  beforeEach,
  describe,
  expect,
  it,
  jest,
} from "@jest/globals";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import type { ReactNode } from "react";
import { ChatSDKError, serializeChatSDKErrorForStream } from "@/lib/errors";
import { getPaidDailyFreeAllowanceCtaText } from "@/lib/limit-pressure";
import { resetExtraUsageResumeRetryGuardForTests } from "@/lib/chat/extra-usage-resume-retry";

let mockSubscription: "free" | "pro" = "pro";
const mockSetSelectedModel = jest.fn();

jest.mock("@/app/contexts/GlobalState", () => ({
  GlobalStateProvider: ({ children }: { children: ReactNode }) => children,
  useGlobalState: () => ({
    subscription: mockSubscription,
    setSelectedModel: mockSetSelectedModel,
  }),
}));

jest.mock("@/lib/utils/settings-dialog", () => ({
  openSettingsDialog: jest.fn(),
}));

jest.mock("@/app/hooks/usePricingDialog", () => ({
  redirectToPricing: jest.fn(),
}));

jest.mock("@/lib/analytics/client", () => ({
  captureAddCreditCtaClick: jest.fn(),
  captureAddCreditCtaImpression: jest.fn(),
  captureAuthenticatedEvent: jest.fn(),
  newCheckoutAttemptId: jest.fn(() => "ca_test"),
  capturePaidDailyFreeAllowanceClick: jest.fn(),
  capturePaidDailyFreeAllowanceImpression: jest.fn(),
  captureUpgradeCtaImpression: jest.fn(),
}));

const mockConvexAction = jest.fn();
jest.mock("convex/react", () => ({
  useAction: () => mockConvexAction,
  useQuery: () => ({ monthlySpentDollars: 66 }),
}));

const { TestWrapper } = require("../testUtils");
const { MessageErrorState } = require("../MessageErrorState");
const {
  captureAuthenticatedEvent,
  capturePaidDailyFreeAllowanceClick,
  capturePaidDailyFreeAllowanceImpression,
} = require("@/lib/analytics/client");
const { openSettingsDialog } = require("@/lib/utils/settings-dialog");

describe("MessageErrorState", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    window.sessionStorage.clear();
    resetExtraUsageResumeRetryGuardForTests();
    mockSubscription = "pro";
    mockConvexAction.mockResolvedValue({
      hasPaymentMethod: true,
      paymentMethodLast4: "4242",
      paymentMethodBrand: "visa",
      url: null,
    });
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it.each([false, true])(
    "renders a region conflict (serialized=%s) as an explicit choice without replaying the prompt",
    async (serialized) => {
      const originalFetch = global.fetch;
      global.fetch = jest.fn().mockResolvedValue({
        ok: true,
        json: async () => ({
          status: "selection_required",
          token: "a".repeat(64),
          choices: [
            { id: "us-existing", region: "us-east-1", lastStartedAt: null },
            { id: "eu-existing", region: "eu-central-1", lastStartedAt: null },
          ],
        }),
      }) as typeof fetch;
      const onRetry = jest.fn();
      try {
        const error = new ChatSDKError(
          "bad_request:sandbox",
          "Choose your workspace",
          { cloud_workspace_region_selection_required: true },
        );
        render(
          <MessageErrorState
            error={
              serialized
                ? new Error(serializeChatSDKErrorForStream(error))
                : error
            }
            onRetry={onRetry}
            onReconnect={jest.fn()}
          />,
        );
        expect(
          await screen.findByRole("radio", { name: /Europe workspace/ }),
        ).toBeEnabled();
        expect(
          screen.queryByRole("button", { name: "Retry" }),
        ).not.toBeInTheDocument();
        expect(onRetry).not.toHaveBeenCalled();
      } finally {
        global.fetch = originalFetch;
      }
    },
  );
  it("does not offer same-payload retry for provider content blocks", () => {
    const error = new ChatSDKError(
      "forbidden:stream",
      "The model provider blocked this request because the conversation content was flagged by its safety system. Edit your last message or remove sensitive or raw tool output, then try again.",
      {
        providerErrorCategory: "content_blocked",
        providerStatusCode: 403,
        providerErrorRetriable: false,
      },
    );

    render(
      <TestWrapper>
        <MessageErrorState
          error={error}
          onRetry={jest.fn()}
          onReconnect={jest.fn()}
        />
      </TestWrapper>,
    );

    expect(
      screen.getByText(/flagged by its safety system/i),
    ).toBeInTheDocument();
    expect(
      screen.getByText(/Retrying with the same conversation/i),
    ).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /^retry$/i })).toBeNull();
    expect(
      screen.getByRole("button", { name: /new task/i }),
    ).toBeInTheDocument();
  });

  it("offers a fresh retry for a serialized offline computer error without resuming its finished stream", () => {
    const onRetry = jest.fn();
    const onReconnect = jest.fn();
    const cause =
      "The selected computer is disconnected. Reconnect that computer to continue this task.";
    render(
      <TestWrapper>
        <MessageErrorState
          error={
            new Error(
              serializeChatSDKErrorForStream(
                new ChatSDKError("offline:sandbox", cause),
              ),
            )
          }
          onRetry={onRetry}
          onReconnect={onReconnect}
          mode="agent"
        />
      </TestWrapper>,
    );
    expect(screen.getByText(cause)).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /^reconnect$/i })).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: /^retry$/i }));
    expect(onRetry).toHaveBeenCalledTimes(1);
    expect(onReconnect).not.toHaveBeenCalled();
  });

  it("keeps retry available for ordinary errors", () => {
    const onRetry = jest.fn();

    render(
      <TestWrapper>
        <MessageErrorState
          error={new Error("Network broke")}
          onRetry={onRetry}
        />
      </TestWrapper>,
    );

    fireEvent.click(screen.getByRole("button", { name: /^retry$/i }));
    expect(onRetry).toHaveBeenCalledTimes(1);
  });

  it("shows a concurrency retry without usage or upgrade actions", () => {
    mockSubscription = "free";
    const error = new ChatSDKError(
      "rate_limit:chat",
      "You already have a free request running. Please wait for it to finish before starting another one.",
      {
        subscription: "free",
        capReason: "free_concurrency",
        limitType: "concurrency",
      },
    );

    render(
      <TestWrapper>
        <MessageErrorState error={error} onRetry={jest.fn()} />
      </TestWrapper>,
    );

    expect(
      screen.getByText(/already have a free request running/i),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Try Again" }),
    ).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "View Usage" })).toBeNull();
    expect(screen.queryByRole("button", { name: "Upgrade Plan" })).toBeNull();
  });

  it("shows a focused Add Credits plus free Ask CTA when allowance is available", async () => {
    const user = userEvent.setup();
    const onRetry = jest.fn();
    const error = new ChatSDKError(
      "rate_limit:chat",
      "You've hit your monthly usage limit.",
      {
        capReason: "monthly_exhausted",
        paidDailyFreeAllowance: {
          type: "paid_daily_free_allowance",
          available: true,
          requestsUsed: 0,
          costRemainingDollars: 0.25,
        },
      },
    );

    render(
      <TestWrapper>
        <MessageErrorState error={error} onRetry={onRetry} mode="ask" />
      </TestWrapper>,
    );

    expect(
      screen.getByRole("button", { name: "Add $15 and continue" }),
    ).toBeVisible();
    expect(screen.queryByRole("button", { name: "Try Again" })).toBeNull();
    expect(screen.queryByRole("button", { name: "View Usage" })).toBeNull();
    expect(screen.queryByRole("button", { name: "Upgrade Plan" })).toBeNull();

    const freeRequestButton = screen.getByRole("button", {
      name: getPaidDailyFreeAllowanceCtaText("ask"),
    });
    expect(freeRequestButton).toBeVisible();
    expect(capturePaidDailyFreeAllowanceImpression).toHaveBeenCalledWith(
      expect.objectContaining({
        surface: "message_error_state",
        cta_text: getPaidDailyFreeAllowanceCtaText("ask"),
        allowance_requests_today: 0,
        allowance_cost_remaining_dollars: 0.25,
      }),
    );

    await user.click(freeRequestButton);

    expect(capturePaidDailyFreeAllowanceClick).toHaveBeenCalledWith(
      expect.objectContaining({
        surface: "message_error_state",
        cta_text: getPaidDailyFreeAllowanceCtaText("ask"),
      }),
    );
    expect(onRetry).toHaveBeenCalledWith({
      limitRescue: { type: "paid_daily_free_allowance" },
    });
  });

  it("opens Checkout directly and marks the stopped task for resume", async () => {
    jest.spyOn(Date, "now").mockReturnValue(Date.UTC(2026, 7, 22));
    const user = userEvent.setup();
    const error = new ChatSDKError(
      "rate_limit:chat",
      "You've hit your monthly usage limit.",
      { capReason: "monthly_exhausted" },
    );

    render(
      <TestWrapper>
        <MessageErrorState error={error} onRetry={jest.fn()} />
      </TestWrapper>,
    );

    await user.click(
      screen.getByRole("button", { name: "Add $15 and continue" }),
    );
    expect(screen.getByRole("dialog")).toBeVisible();
    await user.click(
      screen.getByRole("button", { name: /^\$30(?: Recommended)?$/ }),
    );

    await user.click(screen.getByRole("button", { name: "Purchase" }));

    await waitFor(() =>
      expect(mockConvexAction).toHaveBeenCalledWith(
        expect.objectContaining({
          amountDollars: 30,
          returnPath: expect.stringMatching(/^\//),
          resumeAfterPurchase: true,
          enableExtraUsageAfterPurchase: true,
        }),
      ),
    );
    expect(openSettingsDialog).not.toHaveBeenCalled();
  });

  it("opens payment-method recovery directly for auto-reload failures", async () => {
    const user = userEvent.setup();
    const error = new ChatSDKError(
      "rate_limit:chat",
      "Your automatic reload failed.",
      { capReason: "auto_reload_failed" },
    );

    render(
      <TestWrapper>
        <MessageErrorState error={error} onRetry={jest.fn()} />
      </TestWrapper>,
    );

    await user.click(
      screen.getByRole("button", { name: "Update card and retry" }),
    );

    await waitFor(() =>
      expect(mockConvexAction).toHaveBeenCalledWith({
        flow: "payment_method",
        baseUrl: expect.stringContaining("extra-usage-payment-retry=true"),
      }),
    );
    expect(openSettingsDialog).not.toHaveBeenCalled();
  });

  it("uses a bounded return path when the current pathname is too long", async () => {
    const user = userEvent.setup();
    window.history.replaceState(
      window.history.state,
      "",
      `/${"a".repeat(401)}`,
    );

    render(
      <TestWrapper>
        <MessageErrorState
          error={
            new ChatSDKError("rate_limit:chat", "Limit reached", {
              capReason: "monthly_exhausted",
            })
          }
          onRetry={jest.fn()}
        />
      </TestWrapper>,
    );

    await user.click(
      screen.getByRole("button", { name: "Add $15 and continue" }),
    );
    await user.click(screen.getByRole("button", { name: "Purchase" }));

    await waitFor(() =>
      expect(mockConvexAction).toHaveBeenCalledWith(
        expect.objectContaining({ returnPath: "/" }),
      ),
    );
    window.history.replaceState(window.history.state, "", "/");
  });

  it("retries once after a successful purchase returns to the task", () => {
    const onRetry = jest.fn();
    window.history.replaceState(
      window.history.state,
      "",
      "/?extra-usage-resume=true",
    );

    render(
      <TestWrapper>
        <MessageErrorState
          error={
            new ChatSDKError("rate_limit:chat", "Limit reached", {
              capReason: "monthly_exhausted",
            })
          }
          onRetry={onRetry}
        />
      </TestWrapper>,
    );

    expect(onRetry).toHaveBeenCalledTimes(1);
    expect(window.location.search).not.toContain("extra-usage-resume");
    expect(captureAuthenticatedEvent).toHaveBeenCalledWith(
      "extra_usage_resume_retry",
      expect.objectContaining({ source: "extra-usage-resume", retried: true }),
    );
  });

  it("does not retry again when the resume flag reappears after a failed retry", () => {
    const onRetry = jest.fn();
    const renderWithFlag = () => {
      window.history.replaceState(
        window.history.state,
        "",
        "/c/chat_1?extra-usage-resume=true",
      );
      return render(
        <TestWrapper>
          <MessageErrorState
            error={
              new ChatSDKError("rate_limit:chat", "Limit reached", {
                capReason: "monthly_exhausted",
              })
            }
            onRetry={onRetry}
          />
        </TestWrapper>,
      );
    };

    renderWithFlag().unmount();
    expect(onRetry).toHaveBeenCalledTimes(1);

    renderWithFlag();
    expect(onRetry).toHaveBeenCalledTimes(1);
    expect(window.location.search).not.toContain("extra-usage-resume");
    expect(captureAuthenticatedEvent).toHaveBeenLastCalledWith(
      "extra_usage_resume_retry",
      expect.objectContaining({
        retried: false,
        skipped_reason: "already_retried",
      }),
    );
  });

  it("offers the daily allowance for a structured Agent stream error", () => {
    const error = new ChatSDKError(
      "rate_limit:chat",
      "You've hit your monthly usage limit.",
      {
        capReason: "monthly_exhausted",
        paidDailyFreeAllowance: {
          type: "paid_daily_free_allowance",
          available: true,
          requestsUsed: 0,
          costRemainingDollars: 0.25,
        },
      },
    );

    render(
      <TestWrapper>
        <MessageErrorState
          error={new Error(serializeChatSDKErrorForStream(error))}
          onRetry={jest.fn()}
          mode="agent"
        />
      </TestWrapper>,
    );

    expect(
      screen.getByRole("button", {
        name: getPaidDailyFreeAllowanceCtaText("agent"),
      }),
    ).toBeVisible();
    expect(
      screen.getByText(/up to \$0\.25 of free usage today/i),
    ).toHaveTextContent(
      "Continue this request in Agent mode with our low-cost model",
    );
  });

  it("keeps the allowance explanation grammatical without cost metadata", () => {
    const error = new ChatSDKError(
      "rate_limit:chat",
      "You've hit your monthly usage limit.",
      {
        capReason: "monthly_exhausted",
        paidDailyFreeAllowance: {
          type: "paid_daily_free_allowance",
          available: true,
          requestsUsed: 0,
        },
      },
    );

    render(
      <TestWrapper>
        <MessageErrorState error={error} onRetry={jest.fn()} mode="agent" />
      </TestWrapper>,
    );

    expect(screen.getByText(/some of free usage today/i)).toBeVisible();
  });

  it("does not show the free-request CTA when allowance is unavailable", () => {
    const error = new ChatSDKError(
      "rate_limit:chat",
      "You've hit your monthly usage limit.",
      {
        capReason: "monthly_exhausted",
        paidDailyFreeAllowance: {
          type: "paid_daily_free_allowance",
          available: false,
          unavailableReason: "cost_limit_reached",
        },
      },
    );

    render(
      <TestWrapper>
        <MessageErrorState error={error} onRetry={jest.fn()} />
      </TestWrapper>,
    );

    expect(
      screen.queryByRole("button", {
        name: getPaidDailyFreeAllowanceCtaText("ask"),
      }),
    ).toBeNull();
  });

  it("tells the user to switch to Auto when a specific model blocks the allowance, without an amount", async () => {
    const user = userEvent.setup();
    const onRetry = jest.fn();
    const error = new ChatSDKError(
      "rate_limit:chat",
      "You've hit your monthly usage limit.",
      {
        capReason: "monthly_exhausted",
        paidDailyFreeAllowance: {
          type: "paid_daily_free_allowance",
          available: false,
          unavailableReason: "unsupported_model",
          costRemainingDollars: 0.25,
        },
      },
    );

    render(
      <TestWrapper>
        <MessageErrorState error={error} onRetry={onRetry} mode="agent" />
      </TestWrapper>,
    );

    const hint = screen.getByText(/still get some free usage today on Auto/i);
    expect(hint).toBeVisible();
    expect(screen.queryByRole("button", { name: "Try Again" })).toBeNull();
    expect(screen.queryByRole("button", { name: "View Usage" })).toBeNull();
    expect(screen.queryByRole("button", { name: "Upgrade Plan" })).toBeNull();
    expect(
      screen.getByRole("button", { name: "Add $15 and continue" }),
    ).toBeVisible();
    expect(hint.textContent).not.toContain("$");
    expect(
      screen.queryByRole("button", {
        name: getPaidDailyFreeAllowanceCtaText("agent"),
      }),
    ).toBeNull();
    expect(capturePaidDailyFreeAllowanceImpression).toHaveBeenCalledWith(
      expect.objectContaining({
        cta_text: "Switch to Auto and continue",
        allowance_unavailable_reason: "unsupported_model",
      }),
    );

    await user.click(
      screen.getByRole("button", { name: "Switch to Auto and continue" }),
    );

    expect(mockSetSelectedModel).toHaveBeenCalledWith("auto");
    expect(capturePaidDailyFreeAllowanceClick).toHaveBeenCalledWith(
      expect.objectContaining({ cta_text: "Switch to Auto and continue" }),
    );
    expect(onRetry).toHaveBeenCalledWith({
      limitRescue: { type: "paid_daily_free_allowance" },
      selectedModel: "auto",
    });
  });
});
