jest.mock("../BlockedChatBillingRecovery", () => ({
  BlockedChatBillingRecovery: ({
    children,
  }: {
    children: import("react").ReactNode;
  }) => children,
}));
import "@testing-library/jest-dom";
import { describe, it, expect, jest } from "@jest/globals";
import React from "react";
import {
  act,
  render,
  screen,
  fireEvent,
  waitFor,
} from "@testing-library/react";

import { DataStreamProvider, useDataStream } from "../DataStreamProvider";
import { MAX_AUTO_CONTINUES } from "@/app/hooks/useAutoContinue";
import { POST_SUMMARIZATION_INCOMPLETE_FINISH_REASON } from "@/lib/chat/stop-conditions";
import type { ChatMode, SelectedModel } from "@/types/chat";

jest.mock("@/app/contexts/GlobalState", () => ({
  useGlobalState: () => ({ subscription: "pro", isCheckingProPlan: false }),
}));
jest.mock("convex/react", () => ({
  useQuery: () => ({
    extraUsageAvailable: false,
    reason: "empty",
    hasBalance: false,
    autoReloadEnabled: false,
  }),
  useAction: () => jest.fn(),
}));
jest.mock("@workos-inc/authkit-nextjs/components", () => ({
  useAuth: () => ({ user: { id: "test-user" } }),
}));
jest.mock("swr", () => ({
  __esModule: true,
  default: () => ({
    data: { monthly: { remaining: 0 } },
    isLoading: false,
  }),
}));
jest.mock("@/app/hooks/usePricingDialog", () => ({
  redirectToPricing: jest.fn(),
}));
jest.mock("@/lib/utils/settings-dialog", () => ({
  openSettingsDialog: jest.fn(),
}));

const { FinishReasonNotice } = require("../FinishReasonNotice");

function DataStreamSetter({
  isAutoResuming,
  isAutoContinuing,
  autoContinueCount,
  children,
}: {
  isAutoResuming?: boolean;
  isAutoContinuing?: boolean;
  autoContinueCount?: number;
  children: React.ReactNode;
}) {
  const { setIsAutoResuming, setIsAutoContinuing, setAutoContinueCount } =
    useDataStream();

  React.useEffect(() => {
    if (isAutoResuming !== undefined) setIsAutoResuming(isAutoResuming);
    if (isAutoContinuing !== undefined) setIsAutoContinuing(isAutoContinuing);
    if (autoContinueCount !== undefined)
      setAutoContinueCount(autoContinueCount);
  }, [
    isAutoResuming,
    isAutoContinuing,
    autoContinueCount,
    setIsAutoResuming,
    setIsAutoContinuing,
    setAutoContinueCount,
  ]);

  return <>{children}</>;
}

interface RenderNoticeProps {
  finishReason?: string;
  mode?: ChatMode;
  agentRunSpendCapPremiumContinuationAllowed?: boolean;
  onContinue?: (selectedModelOverride?: SelectedModel) => void;
}

function renderNotice(
  props: RenderNoticeProps,
  contextOverrides?: {
    isAutoResuming?: boolean;
    isAutoContinuing?: boolean;
    autoContinueCount?: number;
  },
) {
  return render(
    <DataStreamProvider>
      <DataStreamSetter {...contextOverrides}>
        <FinishReasonNotice {...props} />
      </DataStreamSetter>
    </DataStreamProvider>,
  );
}

describe("FinishReasonNotice", () => {
  it("explains a repetition halt without offering to repeat the same work", () => {
    const onContinue = jest.fn();
    renderNotice({ finishReason: "doom-loop", mode: "agent", onContinue });

    expect(screen.getByRole("status")).toHaveTextContent(
      /repeating work without progress.*new instruction.*change the approach/i,
    );
    expect(screen.queryByRole("button")).not.toBeInTheDocument();
    expect(onContinue).not.toHaveBeenCalled();
  });

  it("shows automatic continuation status without a manual Continue button", () => {
    const onContinue = jest.fn();
    renderNotice(
      { finishReason: "length", mode: "agent", onContinue },
      { isAutoResuming: false, isAutoContinuing: true },
    );

    expect(screen.getByRole("status")).toHaveTextContent(
      "Continuing automatically…",
    );
    expect(
      screen.queryByRole("button", { name: /continue/i }),
    ).not.toBeInTheDocument();
  });

  describe("suppression cases (should render nothing)", () => {
    it.each([
      { finishReason: "length", mode: "agent" as ChatMode },
      { finishReason: "context-limit", mode: "agent" as ChatMode },
      { finishReason: "tool-calls", mode: "agent" as ChatMode },
      { finishReason: "timeout", mode: "ask" as ChatMode },
    ])(
      "returns null when isAutoResuming is true (finishReason=$finishReason, mode=$mode)",
      ({ finishReason, mode }) => {
        const { container } = renderNotice(
          { finishReason, mode },
          { isAutoResuming: true, autoContinueCount: 0 },
        );
        expect(container.innerHTML).toBe("");
      },
    );

    it("returns null when finishReason is undefined", () => {
      const { container } = renderNotice(
        { finishReason: undefined, mode: "agent" },
        { isAutoResuming: false, autoContinueCount: MAX_AUTO_CONTINUES },
      );
      expect(container.innerHTML).toBe("");
    });

    it("returns null for an unknown finishReason", () => {
      const { container } = renderNotice(
        { finishReason: "unknown-reason", mode: "agent" },
        { isAutoResuming: false, autoContinueCount: MAX_AUTO_CONTINUES },
      );
      expect(container.innerHTML).toBe("");
    });
  });

  describe("rendering cases (should show notice)", () => {
    it.each([
      {
        finishReason: "tool-calls",
        expectedText: "Reached the step limit for this turn",
      },
      {
        finishReason: "timeout",
        expectedText: "Reached the time limit for this turn",
      },
      {
        finishReason: "length",
        expectedText: "The response reached its output limit before finishing",
      },
      {
        finishReason: "context-limit",
        expectedText: "Reached the context limit for this conversation",
      },
      {
        finishReason: "budget-exhausted",
        expectedText: "This run stopped when your usage limit was reached",
      },
      {
        finishReason: POST_SUMMARIZATION_INCOMPLETE_FINISH_REASON,
        expectedText: "Paused after compacting the conversation",
      },
    ])(
      "renders notice for finishReason=$finishReason when no auto-continuation is pending",
      ({ finishReason, expectedText }) => {
        renderNotice(
          { finishReason, mode: "agent" },
          { isAutoResuming: false, autoContinueCount: 0 },
        );
        expect(screen.getByText(new RegExp(expectedText))).toBeInTheDocument();
      },
    );

    it("renders an output-limit fallback in agent mode when the auto-continue signal is absent", () => {
      renderNotice(
        { finishReason: "length", mode: "agent" },
        { isAutoResuming: false },
      );

      expect(
        screen.getByText(
          /The response reached its output limit before finishing.*Continue to resume where it stopped/i,
        ),
      ).toBeInTheDocument();
    });

    it("confirms that completed work was preserved at the step limit", () => {
      renderNotice({ finishReason: "tool-calls", mode: "agent" });

      expect(screen.getByText(/Completed work was saved/i)).toBeInTheDocument();
    });

    it.each([
      {
        finishReason: "context-limit",
        mode: "ask" as ChatMode,
        expectedText: "Reached the context limit for this conversation",
      },
      {
        finishReason: "length",
        mode: "ask" as ChatMode,
        expectedText: "The response reached its output limit before finishing",
      },
    ])(
      "renders notice for finishReason=$finishReason in $mode mode with autoContinueCount=0 (auto-continue only applies to agent mode)",
      ({ finishReason, mode, expectedText }) => {
        const { container } = renderNotice(
          { finishReason, mode },
          { isAutoResuming: false, autoContinueCount: 0 },
        );
        expect(container.innerHTML).not.toBe("");
        expect(screen.getByText(new RegExp(expectedText))).toBeInTheDocument();
      },
    );

    it("renders timeout notice in agent mode even with autoContinueCount=0 (timeout is not auto-continuable)", () => {
      renderNotice(
        { finishReason: "timeout", mode: "agent" },
        { isAutoResuming: false, autoContinueCount: 0 },
      );
      expect(
        screen.getByText(/Reached the time limit for this turn/),
      ).toBeInTheDocument();
    });
  });

  describe("Continue button", () => {
    it("does not render the Continue button when onContinue is not provided", () => {
      renderNotice(
        { finishReason: "tool-calls", mode: "agent" },
        { isAutoResuming: false, autoContinueCount: MAX_AUTO_CONTINUES },
      );
      expect(
        screen.queryByRole("button", { name: /continue/i }),
      ).not.toBeInTheDocument();
    });

    it("renders the Continue button when onContinue is provided", () => {
      const onContinue = jest.fn();
      renderNotice(
        { finishReason: "tool-calls", mode: "agent", onContinue },
        { isAutoResuming: false, autoContinueCount: MAX_AUTO_CONTINUES },
      );
      expect(
        screen.getByRole("button", { name: /continue/i }),
      ).toBeInTheDocument();
    });

    it("invokes onContinue when the button is clicked", () => {
      const onContinue = jest.fn();
      renderNotice(
        { finishReason: "tool-calls", mode: "agent", onContinue },
        { isAutoResuming: false, autoContinueCount: MAX_AUTO_CONTINUES },
      );
      fireEvent.click(screen.getByRole("button", { name: /continue/i }));
      expect(onContinue).toHaveBeenCalledTimes(1);
    });

    it.each([
      "tool-calls",
      "timeout",
      "length",
      "context-limit",
      "preemptive-timeout",
      "agent-run-spend-cap",
      POST_SUMMARIZATION_INCOMPLETE_FINISH_REASON,
    ])("renders the Continue button for finishReason=%s", (finishReason) => {
      const onContinue = jest.fn();
      renderNotice(
        { finishReason, mode: "agent", onContinue },
        { isAutoResuming: false, autoContinueCount: MAX_AUTO_CONTINUES },
      );
      expect(
        screen.getByRole("button", { name: /continue/i }),
      ).toBeInTheDocument();
    });

    it("renders the legacy Pro Agent run cap notice and keeps the current model when premium continuation is unavailable", () => {
      const onContinue = jest.fn();
      renderNotice(
        {
          finishReason: "agent-run-spend-cap",
          mode: "agent",
          agentRunSpendCapPremiumContinuationAllowed: false,
          onContinue,
        },
        { isAutoResuming: false, autoContinueCount: 0 },
      );

      expect(
        screen.getByText(/Paused at a legacy Pro Agent per-run safety cap/i),
      ).toBeInTheDocument();
      fireEvent.click(screen.getByRole("button", { name: /^continue$/i }));

      expect(onContinue).toHaveBeenCalledWith(undefined);
    });

    it("keeps the current selected model when spend-cap continuation eligibility is unknown", () => {
      const onContinue = jest.fn();
      renderNotice(
        {
          finishReason: "agent-run-spend-cap",
          mode: "agent",
          onContinue,
        },
        { isAutoResuming: false, autoContinueCount: 0 },
      );

      fireEvent.click(screen.getByRole("button", { name: /^continue$/i }));

      expect(onContinue).toHaveBeenCalledWith(undefined);
    });

    it("continues the current premium model when spend-cap continuation is backed by extra usage", () => {
      const onContinue = jest.fn();
      renderNotice(
        {
          finishReason: "agent-run-spend-cap",
          mode: "agent",
          agentRunSpendCapPremiumContinuationAllowed: true,
          onContinue,
        },
        { isAutoResuming: false, autoContinueCount: 0 },
      );

      fireEvent.click(screen.getByRole("button", { name: /^continue$/i }));

      expect(onContinue).toHaveBeenCalledWith(undefined);
    });

    it("offers recovery and resumes through the normal continuation handler after budget exhaustion", () => {
      const onContinue = jest.fn();
      renderNotice(
        {
          finishReason: "budget-exhausted",
          mode: "agent",
          onContinue,
        },
        { isAutoResuming: false, autoContinueCount: MAX_AUTO_CONTINUES },
      );

      expect(
        screen.getByText(/This run stopped when your usage limit was reached/i),
      ).toBeInTheDocument();
      expect(
        screen.queryByRole("button", { name: /continue/i }),
      ).not.toBeInTheDocument();
      expect(screen.getByRole("button", { name: "Add credits" })).toBeEnabled();
      fireEvent.click(screen.getByRole("button", { name: "Try again" }));
      expect(onContinue).toHaveBeenCalledTimes(1);
      expect(onContinue).toHaveBeenCalledWith(undefined);
      // A rejected attempt must not permanently hide the recovery actions.
      expect(screen.getByRole("button", { name: "Add credits" })).toBeEnabled();
    });
  });

  describe("correct styling", () => {
    it("renders with the expected CSS classes on the outer and inner divs", () => {
      renderNotice(
        { finishReason: "length", mode: "agent" },
        { isAutoResuming: false, autoContinueCount: MAX_AUTO_CONTINUES },
      );

      const innerDiv = screen
        .getByText(/The response reached its output limit before finishing/)
        .closest("div.bg-muted");
      expect(innerDiv).toBeInTheDocument();
      expect(innerDiv).toHaveClass(
        "bg-muted",
        "text-muted-foreground",
        "rounded-lg",
        "px-3",
        "py-2",
        "border",
        "border-border",
      );

      const outerDiv = innerDiv?.parentElement;
      expect(outerDiv).toHaveClass("mt-2", "w-full");
    });
  });
});

it.each(["step-limit", "trigger_crashed_client_saved"])(
  "offers recovery for %s",
  (finishReason) => {
    renderNotice({ finishReason, onContinue: jest.fn() });
    expect(
      screen.getByRole("button", { name: /Continue|Resume task/ }),
    ).toBeEnabled();
  },
);

it("keeps recovery available after a rejected continuation and prevents double clicks", async () => {
  let reject!: (error: Error) => void;
  const onContinue = jest.fn(
    () =>
      new Promise<void>((_, fail) => {
        reject = fail;
      }),
  );
  renderNotice({ finishReason: "step-limit", onContinue });
  fireEvent.click(screen.getByRole("button", { name: "Continue" }));
  const pending = screen.getByRole("button", { name: "Resuming…" });
  expect(pending).toBeDisabled();
  fireEvent.click(pending);
  expect(onContinue).toHaveBeenCalledTimes(1);
  await act(async () => {
    reject(new Error("offline"));
  });
  await waitFor(() =>
    expect(screen.getByRole("button", { name: "Continue" })).toBeEnabled(),
  );
});
