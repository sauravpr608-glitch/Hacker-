import "@testing-library/jest-dom";
import { describe, expect, it, jest, beforeEach } from "@jest/globals";
import { act, render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

const mockGetSubscriptionCancellationStatus = jest.fn();
const mockKeepSubscription = jest.fn();
const mockRedirectToBillingPortal = jest.fn();
const mockSetMigrateFromPentestgptDialogOpen = jest.fn();
const mockToastSuccess = jest.fn();
const mockToastError = jest.fn();
const mockCaptureAuthenticatedEvent = jest.fn();
let mockOnCancellationCompleted:
  | ((result: {
      cancelAtPeriodEnd: boolean;
      currentPeriodEnd?: number;
    }) => void)
  | undefined;

jest.mock("@/app/contexts/GlobalState", () => ({
  useGlobalState: () => ({
    subscription: "pro",
    setMigrateFromPentestgptDialogOpen: mockSetMigrateFromPentestgptDialogOpen,
  }),
}));

jest.mock("@/app/hooks/usePentestgptMigration", () => ({
  usePentestgptMigration: () => ({ isMigrating: false }),
}));

jest.mock("@/app/hooks/usePricingDialog", () => ({
  redirectToPricing: jest.fn(),
}));

jest.mock("@/lib/billing/client", () => ({
  getSubscriptionCancellationStatus: mockGetSubscriptionCancellationStatus,
  keepSubscription: mockKeepSubscription,
  redirectToBillingPortal: mockRedirectToBillingPortal,
  resumeSubscription: jest.fn(),
}));

jest.mock("@/lib/analytics/client", () => ({
  captureAuthenticatedEvent: mockCaptureAuthenticatedEvent,
}));

jest.mock("sonner", () => ({
  toast: {
    success: mockToastSuccess,
    error: mockToastError,
  },
}));

jest.mock("../DeleteAccountDialog", () => ({
  __esModule: true,
  default: () => null,
}));

jest.mock("../CancelSubscriptionDialog", () => ({
  __esModule: true,
  default: (props: {
    onCancellationCompleted?: (result: {
      cancelAtPeriodEnd: boolean;
      currentPeriodEnd?: number;
    }) => void;
  }) => {
    mockOnCancellationCompleted = props.onCancellationCompleted;
    return null;
  },
}));

const AccountTab = require("../AccountTab")
  .AccountTab as typeof import("../AccountTab").AccountTab;

describe("AccountTab", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockOnCancellationCompleted = undefined;
    window.history.replaceState(null, "", "/");
  });

  it("shows the actual Stripe renewal amount and interval", async () => {
    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: false,
      renewalAmountDollars: 29,
      renewalCurrency: "usd",
      renewalInterval: "month",
      renewalIntervalCount: 1,
    } as never);

    render(<AccountTab />);

    expect(await screen.findByText("Renews at $29 every month")).toBeVisible();
  });

  it("shows scheduled cancellation state instead of the cancel action", async () => {
    const currentPeriodEnd = Date.UTC(2026, 6, 31, 12);
    const expectedPeriodEnd = new Intl.DateTimeFormat(undefined, {
      month: "long",
      day: "numeric",
      year: "numeric",
    }).format(new Date(currentPeriodEnd));

    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: true,
      currentPeriodEnd,
      renewalAmountDollars: 29,
      renewalCurrency: "usd",
      renewalInterval: "month",
      renewalIntervalCount: 1,
    } as never);

    render(<AccountTab />);

    expect(await screen.findByText("Cancellation scheduled.")).toBeVisible();
    expect(
      screen.getByText(`Your plan stays active until ${expectedPeriodEnd}.`),
    ).toBeVisible();
    expect(screen.queryByText(/renews at/i)).not.toBeInTheDocument();

    const user = userEvent.setup();
    await user.click(screen.getAllByRole("button", { name: /manage/i })[0]);

    await waitFor(() => {
      expect(screen.getByText("Cancellation scheduled")).toBeVisible();
    });
    expect(screen.getByText("Keep plan")).toBeVisible();
    expect(screen.queryByText("Cancel subscription")).not.toBeInTheDocument();
  });

  it("keeps the cancel action when cancellation is not scheduled", async () => {
    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: false,
    } as never);

    render(<AccountTab />);

    await waitFor(() => {
      expect(mockGetSubscriptionCancellationStatus).toHaveBeenCalledTimes(1);
    });

    const user = userEvent.setup();
    await user.click(screen.getAllByRole("button", { name: /manage/i })[0]);

    expect(screen.getByText("Cancel subscription")).toBeVisible();
    expect(
      screen.queryByText("Cancellation scheduled."),
    ).not.toBeInTheDocument();
  });

  it("opens the billing portal from the payment manage action", async () => {
    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: false,
    } as never);
    mockRedirectToBillingPortal.mockResolvedValue("#billing" as never);

    render(<AccountTab />);

    await waitFor(() => {
      expect(mockGetSubscriptionCancellationStatus).toHaveBeenCalledTimes(1);
    });

    const user = userEvent.setup();
    await user.click(screen.getAllByRole("button", { name: /^manage$/i })[1]);

    await waitFor(() => {
      expect(mockRedirectToBillingPortal).toHaveBeenCalledTimes(1);
    });
    expect(window.location.hash).toBe("#billing");
  });

  it("does not open the payment portal before billing status resolves", async () => {
    mockGetSubscriptionCancellationStatus.mockReturnValue(
      new Promise((resolve) => {
        void resolve;
      }) as never,
    );

    render(<AccountTab />);

    const paymentButton = screen.getAllByRole("button", {
      name: /^manage$/i,
    })[1];
    expect(paymentButton).toBeDisabled();

    const user = userEvent.setup();
    await user.click(paymentButton);
    expect(mockRedirectToBillingPortal).not.toHaveBeenCalled();
  });

  it("shows a past-due warning and opens payment method update directly", async () => {
    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: false,
      subscriptionStatus: "past_due",
      latestInvoiceId: "in_past_due",
      renewalPaymentRequired: true,
      renewalPaymentFailure: "insufficient_funds",
    } as never);
    mockRedirectToBillingPortal.mockResolvedValue("#payment-method" as never);

    render(<AccountTab />);

    const alert = await screen.findByRole("region", {
      name: "Subscription payment recovery",
    });
    expect(alert).toHaveTextContent("Your renewal payment didn’t go through");
    expect(mockCaptureAuthenticatedEvent).toHaveBeenCalledWith(
      "recovery_prompt_impressed",
      expect.objectContaining({
        surface: "account_settings",
        subscription_tier: "pro",
        subscription_status: "past_due",
        stripe_invoice_id: "in_past_due",
      }),
    );

    const user = userEvent.setup();
    await user.click(
      within(alert).getByRole("button", { name: "Update card" }),
    );

    await waitFor(() => {
      expect(mockRedirectToBillingPortal).toHaveBeenCalledWith(
        "payment_method",
        { surface: "account_settings", returnPath: "/" },
      );
    });
    expect(mockCaptureAuthenticatedEvent).toHaveBeenCalledWith(
      "billing_past_due_payment_update_clicked",
      expect.objectContaining({
        surface: "account_settings",
        stripe_invoice_id: "in_past_due",
      }),
    );
    expect(window.location.hash).toBe("#payment-method");
  });

  it("does not offer the direct payment update flow after retries are exhausted", async () => {
    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: false,
      subscriptionStatus: "unpaid",
      latestInvoiceId: "in_unpaid",
    } as never);
    mockRedirectToBillingPortal.mockResolvedValue("#billing" as never);

    render(<AccountTab />);

    await waitFor(() => {
      expect(mockGetSubscriptionCancellationStatus).toHaveBeenCalledTimes(1);
    });
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();

    const user = userEvent.setup();
    await user.click(screen.getAllByRole("button", { name: /^manage$/i })[1]);

    await waitFor(() => {
      expect(mockRedirectToBillingPortal).toHaveBeenCalledWith(undefined);
    });
    expect(mockCaptureAuthenticatedEvent).not.toHaveBeenCalledWith(
      "billing_past_due_banner_impressed",
      expect.anything(),
    );
  });

  it("offers access refresh after a status recheck confirms the renewal is paid", async () => {
    mockGetSubscriptionCancellationStatus.mockResolvedValueOnce({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: false,
      subscriptionStatus: "past_due",
      latestInvoiceId: "in_renewal",
      renewalPaymentRequired: true,
    } as never);
    render(<AccountTab />);
    const check = await screen.findByRole("button", {
      name: "Check payment status",
    });
    mockGetSubscriptionCancellationStatus.mockResolvedValueOnce({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: false,
      subscriptionStatus: "active",
      latestInvoiceId: "in_renewal",
      renewalInvoicePaid: true,
    } as never);
    await userEvent.click(check);
    await waitFor(() =>
      expect(mockToastSuccess).toHaveBeenCalledWith(
        "Your renewal invoice is paid. Refresh to update your access.",
        expect.objectContaining({
          action: expect.objectContaining({ label: "Refresh" }),
        }),
      ),
    );
    expect(
      screen.queryByRole("region", { name: "Subscription payment recovery" }),
    ).not.toBeInTheDocument();
  });

  it("updates the tab when cancellation is scheduled from the dialog", async () => {
    const currentPeriodEnd = Date.UTC(2026, 6, 31, 12);
    const expectedPeriodEnd = new Intl.DateTimeFormat(undefined, {
      month: "long",
      day: "numeric",
      year: "numeric",
    }).format(new Date(currentPeriodEnd));

    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: false,
    } as never);

    render(<AccountTab />);

    await waitFor(() => {
      expect(mockGetSubscriptionCancellationStatus).toHaveBeenCalledTimes(1);
    });

    act(() => {
      mockOnCancellationCompleted?.({
        cancelAtPeriodEnd: true,
        currentPeriodEnd,
      });
    });

    expect(await screen.findByText("Cancellation scheduled.")).toBeVisible();
    expect(
      screen.getByText(`Your plan stays active until ${expectedPeriodEnd}.`),
    ).toBeVisible();

    const user = userEvent.setup();
    await user.click(screen.getAllByRole("button", { name: /manage/i })[0]);

    expect(screen.getByText("Cancellation scheduled")).toBeVisible();
    expect(screen.getByText("Keep plan")).toBeVisible();
    expect(screen.queryByText("Cancel subscription")).not.toBeInTheDocument();
  });

  it("shows no active subscription after an overdue subscription is canceled", async () => {
    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: false,
    } as never);

    render(<AccountTab />);

    await waitFor(() => {
      expect(mockGetSubscriptionCancellationStatus).toHaveBeenCalledTimes(1);
    });

    act(() => {
      mockOnCancellationCompleted?.({ cancelAtPeriodEnd: false });
    });

    const user = userEvent.setup();
    await user.click(screen.getAllByRole("button", { name: /manage/i })[0]);

    expect(screen.getByText("No active subscription")).toBeVisible();
    expect(screen.queryByText("Keep plan")).not.toBeInTheDocument();
    expect(screen.queryByText("Cancel subscription")).not.toBeInTheDocument();
  });

  it("keeps the plan and restores the cancel action from the manage menu", async () => {
    const currentPeriodEnd = Date.UTC(2026, 6, 31, 12);

    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: true,
      currentPeriodEnd,
    } as never);
    mockKeepSubscription.mockResolvedValue({
      kept: true,
      cancelAtPeriodEnd: false,
      currentPeriodEnd,
      alreadyKept: false,
    } as never);

    render(<AccountTab />);

    expect(await screen.findByText("Cancellation scheduled.")).toBeVisible();

    const user = userEvent.setup();
    await user.click(screen.getAllByRole("button", { name: /manage/i })[0]);
    await user.click(screen.getByText("Keep plan"));

    await waitFor(() => {
      expect(mockKeepSubscription).toHaveBeenCalledTimes(1);
      expect(mockToastSuccess).toHaveBeenCalledWith(
        "Cancellation removed. Your plan will renew as usual.",
      );
    });

    expect(
      screen.queryByText("Cancellation scheduled."),
    ).not.toBeInTheDocument();

    await user.click(screen.getAllByRole("button", { name: /manage/i })[0]);

    expect(screen.getByText("Cancel subscription")).toBeVisible();
    expect(screen.queryByText("Keep plan")).not.toBeInTheDocument();
  });

  it("leaves scheduled cancellation visible when keeping the plan fails", async () => {
    const currentPeriodEnd = Date.UTC(2026, 6, 31, 12);
    let rejectKeepPlan: (error: Error) => void = () => {};

    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: true,
      currentPeriodEnd,
    } as never);
    mockKeepSubscription.mockReturnValue(
      new Promise((_, reject) => {
        rejectKeepPlan = reject;
      }) as never,
    );

    render(<AccountTab />);

    expect(await screen.findByText("Cancellation scheduled.")).toBeVisible();

    const user = userEvent.setup();
    await user.click(screen.getAllByRole("button", { name: /manage/i })[0]);
    await user.click(screen.getByText("Keep plan"));

    expect(screen.getByRole("button", { name: /keeping/i })).toBeVisible();

    act(() => {
      rejectKeepPlan(new Error("Stripe update failed"));
    });

    await waitFor(() => {
      expect(mockToastError).toHaveBeenCalledWith("Stripe update failed");
    });

    expect(screen.getByText("Cancellation scheduled.")).toBeVisible();
    expect(screen.getAllByRole("button", { name: /manage/i })[0]).toBeVisible();

    await user.click(screen.getAllByRole("button", { name: /manage/i })[0]);

    expect(screen.getByText("Keep plan")).toBeVisible();
    expect(screen.queryByText("Cancel subscription")).not.toBeInTheDocument();
  });

  it("does not offer cancellation when no active subscription is found", async () => {
    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: false,
      cancelAtPeriodEnd: false,
    } as never);

    render(<AccountTab />);

    await waitFor(() => {
      expect(mockGetSubscriptionCancellationStatus).toHaveBeenCalledTimes(1);
    });

    const user = userEvent.setup();
    await user.click(screen.getAllByRole("button", { name: /manage/i })[0]);

    expect(screen.getByText("No active subscription")).toBeVisible();
    expect(screen.queryByText("Cancel subscription")).not.toBeInTheDocument();
  });

  it("shows the scheduled pause and lets the user cancel it", async () => {
    const currentPeriodEnd = Date.UTC(2026, 9, 1, 12);
    const resumeAt = Date.UTC(2026, 11, 1, 12);
    const format = (value: number) =>
      new Intl.DateTimeFormat(undefined, {
        month: "long",
        day: "numeric",
        year: "numeric",
      }).format(new Date(value));
    mockGetSubscriptionCancellationStatus.mockResolvedValue({
      hasActiveSubscription: true,
      cancelAtPeriodEnd: true,
      currentPeriodEnd,
      pause: { months: 2, pauseEffectiveAt: currentPeriodEnd, resumeAt },
    } as never);
    mockKeepSubscription.mockResolvedValue({
      kept: true,
      cancelAtPeriodEnd: false,
      currentPeriodEnd,
      alreadyKept: false,
      pauseCanceled: true,
    } as never);

    render(<AccountTab />);

    expect(await screen.findByText("Pause scheduled.")).toBeVisible();
    expect(
      screen.getByText(
        (content) =>
          content.includes(
            `Billing pauses after that and resumes automatically on ${format(resumeAt)}.`,
          ),
        { selector: "div" },
      ),
    ).toBeVisible();
    expect(
      screen.queryByText("Cancellation scheduled."),
    ).not.toBeInTheDocument();

    const user = userEvent.setup();
    await user.click(screen.getAllByRole("button", { name: /manage/i })[0]);
    await waitFor(() => {
      expect(screen.getByText("Cancel pause")).toBeVisible();
    });
    await user.click(screen.getByText("Cancel pause"));

    await waitFor(() => {
      expect(mockKeepSubscription).toHaveBeenCalledTimes(1);
    });
    expect(mockToastSuccess).toHaveBeenCalledWith(
      "Pause canceled. Your plan will renew as usual.",
    );
    await waitFor(() => {
      expect(screen.queryByText("Pause scheduled.")).not.toBeInTheDocument();
    });
  });
});

it("shows billing review instead of choosing a subscription when status is ambiguous", async () => {
  jest.clearAllMocks();
  mockGetSubscriptionCancellationStatus.mockRejectedValue(
    new Error("Unable to determine a single current subscription") as never,
  );
  render(<AccountTab />);
  expect(
    await screen.findByText(/We couldn't determine your current subscription/),
  ).toBeVisible();
  const user = userEvent.setup();
  await user.click(screen.getAllByRole("button", { name: /manage/i })[0]);
  expect(screen.getByText("Subscription status unavailable")).toBeVisible();
  expect(screen.queryByText("Upgrade plan")).not.toBeInTheDocument();
  expect(screen.queryByText("No active subscription")).not.toBeInTheDocument();
  expect(screen.queryByText("Cancel subscription")).not.toBeInTheDocument();
  expect(
    screen.queryByRole("button", { name: "Update payment" }),
  ).not.toBeInTheDocument();
});
