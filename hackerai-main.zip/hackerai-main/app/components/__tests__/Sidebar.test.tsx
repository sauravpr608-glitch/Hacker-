import "@testing-library/jest-dom";
import { describe, expect, it, jest } from "@jest/globals";
import { render, screen } from "@testing-library/react";

let mockSidebarState: "expanded" | "collapsed" = "expanded";
const mockUseProjects = jest.fn(() => ({
  results: [],
  status: "Exhausted" as const,
  loadMore: jest.fn(),
}));

jest.mock("@/components/ui/sidebar", () => {
  const Wrapper = ({ children }: { children: React.ReactNode }) => (
    <div>{children}</div>
  );

  return {
    Sidebar: Wrapper,
    SidebarContent: Wrapper,
    SidebarFooter: Wrapper,
    SidebarGroup: Wrapper,
    SidebarGroupContent: Wrapper,
    SidebarHeader: Wrapper,
    SidebarRail: () => null,
    useSidebar: () => ({ state: mockSidebarState }),
  };
});
jest.mock("@/hooks/use-mobile", () => ({
  useIsMobile: () => false,
}));
jest.mock("@/app/contexts/GlobalState", () => ({
  useGlobalState: () => ({ setChatSidebarOpen: jest.fn() }),
  useGlobalStateActions: () => ({ setChatSidebarOpen: jest.fn() }),
}));
jest.mock("@/app/hooks/useChats", () => ({
  useChats: () => ({
    results: [],
    status: "Exhausted",
    loadMore: jest.fn(),
  }),
}));
jest.mock("@/app/hooks/useProjects", () => ({
  useProjects: mockUseProjects,
}));
jest.mock("../SidebarHeader", () => ({
  __esModule: true,
  default: ({ isMobileOverlay }: { isMobileOverlay?: boolean }) => (
    <div data-testid="sidebar-header" data-mobile={isMobileOverlay}>
      Header
    </div>
  ),
}));
jest.mock("../SidebarUserNav", () => ({
  __esModule: true,
  default: () => <div>Footer</div>,
}));
jest.mock("../SidebarChatSections", () => ({
  SidebarChatSections: ({
    projects,
    loadMore,
  }: {
    projects?: unknown[];
    loadMore?: unknown;
  }) => (
    <div
      data-testid="sidebar-chat-sections"
      data-project-count={projects?.length}
      data-pagination-enabled={typeof loadMore === "function"}
    >
      Task sections
    </div>
  ),
}));

const MainSidebar = require("../Sidebar")
  .default as typeof import("../Sidebar").default;

const chatListData = {
  results: [{ _id: "chat-doc", id: "chat-1", title: "Target notes" }],
  status: "Exhausted" as const,
  loadMore: jest.fn(),
};
const projectListData = {
  results: [],
  status: "Exhausted" as const,
  loadMore: jest.fn(),
};

describe("MainSidebar", () => {
  it("keeps task content mounted but hidden while the sidebar is collapsed", () => {
    mockSidebarState = "expanded";
    const { rerender } = render(<MainSidebar chatListData={chatListData} />);

    const expandedContent = screen.getByTestId("sidebar-chat-list-visibility");
    expect(expandedContent).toHaveClass("visible", "opacity-100", "delay-200");
    expect(expandedContent).toHaveAttribute("aria-hidden", "false");
    expect(screen.getByTestId("sidebar-chat-sections")).toBeInTheDocument();
    expect(screen.getByTestId("sidebar-chat-sections")).toHaveAttribute(
      "data-pagination-enabled",
      "true",
    );

    mockSidebarState = "collapsed";
    rerender(<MainSidebar chatListData={chatListData} />);

    const collapsedContent = screen.getByTestId("sidebar-chat-list-visibility");
    expect(collapsedContent).toHaveClass(
      "pointer-events-none",
      "invisible",
      "opacity-0",
    );
    expect(collapsedContent).toHaveAttribute("aria-hidden", "true");
    expect(collapsedContent).toHaveAttribute("inert");
    expect(screen.getByTestId("sidebar-chat-sections")).toBeInTheDocument();
    expect(screen.getByTestId("sidebar-chat-sections")).toHaveAttribute(
      "data-pagination-enabled",
      "false",
    );

    mockSidebarState = "expanded";
    rerender(<MainSidebar chatListData={chatListData} />);
    expect(screen.getByTestId("sidebar-chat-sections")).toHaveAttribute(
      "data-pagination-enabled",
      "true",
    );
  });

  it("adds consistent side gutters to the mobile sidebar", () => {
    mockUseProjects.mockClear();
    render(
      <MainSidebar
        isMobileOverlay={true}
        chatListData={chatListData}
        projectListData={projectListData}
      />,
    );

    expect(screen.getByTestId("sidebar-header")).toHaveAttribute(
      "data-mobile",
      "true",
    );
    expect(screen.getByTestId("mobile-sidebar-chat-content")).toHaveClass(
      "px-2",
    );
    expect(mockUseProjects).toHaveBeenCalledWith(10, false);
    expect(screen.getByTestId("sidebar-chat-sections")).toHaveAttribute(
      "data-project-count",
      "0",
    );
  });
});
