"use client";

import React, { useEffect, useMemo, useState } from "react";
import { useAuth } from "@workos-inc/authkit-nextjs/components";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Lock, TriangleAlert } from "lucide-react";
import {
  ACCOUNT_CLEANUP_IN_PROGRESS_CODE,
  MAX_ACCOUNT_CLEANUP_REQUESTS,
} from "@/lib/account-deletion";

type DeleteAccountDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

type DeleteAccountResponse = {
  code?: string;
  error?: string;
};

async function requestAccountDeletion() {
  for (let attempt = 0; attempt < MAX_ACCOUNT_CLEANUP_REQUESTS; attempt++) {
    const response = await fetch("/api/delete-account", { method: "POST" });
    const data = (await response
      .json()
      .catch(() => ({}))) as DeleteAccountResponse;

    if (
      response.status === 409 &&
      data.code === ACCOUNT_CLEANUP_IN_PROGRESS_CODE
    ) {
      continue;
    }

    if (!response.ok) {
      throw new Error(data.error || "Failed to delete account");
    }

    return;
  }

  throw new Error(
    "Account cleanup is still in progress after the bounded retry window",
  );
}

export const DeleteAccountDialog = ({
  open,
  onOpenChange,
}: DeleteAccountDialogProps) => {
  const { user } = useAuth();
  const [isDeleting, setIsDeleting] = useState(false);
  const [emailInput, setEmailInput] = useState("");
  const [confirmInput, setConfirmInput] = useState("");

  const lastSignInAtIso: string | null = useMemo(() => {
    if (!user) return null;
    // WorkOS user has lastSignInAt ISO string when available

    const value = (user as any)?.lastSignInAt as string | undefined;
    return value ?? null;
  }, [user]);

  const hasRecentLogin = useMemo(() => {
    if (!lastSignInAtIso) return false;
    const last = new Date(lastSignInAtIso).getTime();
    if (Number.isNaN(last)) return false;
    const tenMinutesMs = 10 * 60 * 1000;
    return Date.now() - last <= tenMinutesMs;
  }, [lastSignInAtIso]);

  const expectedEmail: string = useMemo(() => user?.email ?? "", [user]);

  const emailMatches = useMemo(() => {
    if (!expectedEmail) return false;
    return emailInput.trim().toLowerCase() === expectedEmail.toLowerCase();
  }, [emailInput, expectedEmail]);

  const phraseMatches = useMemo(
    () => confirmInput.trim() === "DELETE",
    [confirmInput],
  );

  const canDelete =
    hasRecentLogin && emailMatches && phraseMatches && !isDeleting;

  useEffect(() => {
    if (open) return;
    setEmailInput("");
    setConfirmInput("");
  }, [open]);

  const handleRefreshLogin = async () => {
    const { clientLogout } = await import("@/lib/utils/logout");
    clientLogout();
  };

  const handleConfirmDelete = async () => {
    if (isDeleting || !canDelete) return;
    setIsDeleting(true);
    try {
      // Delete Convex data, cancel Stripe subs, remove WorkOS org(s), and
      // delete the WorkOS user server-side.
      await requestAccountDeletion();
      // Clear HttpOnly auth cookies on the server, then redirect home
      try {
        await fetch("/api/clear-auth-cookies", { method: "POST" });
      } catch {}
      try {
        sessionStorage.clear();
        localStorage.clear();
      } catch {}
      window.location.replace("/");
    } catch (error) {
      console.error("Failed to delete user data:", error);
      toast.error(
        "Failed to delete account. Please try again or contact support.",
      );
      setIsDeleting(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(nextOpen) => {
        if (!isDeleting) onOpenChange(nextOpen);
      }}
      modal={true}
    >
      <DialogContent
        showCloseButton={!isDeleting}
        data-testid="delete-account-dialog"
        className="sm:max-w-md max-h-[90vh] overflow-y-auto"
      >
        <DialogHeader>
          <DialogTitle>Delete account - are you sure?</DialogTitle>
        </DialogHeader>
        <DialogDescription
          data-testid="delete-account-description"
          className="pt-2 text-sm text-foreground"
        >
          Deleting your account will remove all your data, including tasks,
          settings, and personal information. Deleting and recreating an account
          does not reset usage limits or referral eligibility. This action
          cannot be undone.
        </DialogDescription>

        {!hasRecentLogin && (
          <p className="text-xs pt-4 text-muted-foreground">
            You may only delete your account if you have logged in within the
            last 10 minutes. Please log in again, then return here to continue.
          </p>
        )}

        {hasRecentLogin && (
          <div className="pt-4 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="delete-email">
                Please type your account email.
              </Label>
              <Input
                data-testid="email-confirmation"
                id="delete-email"
                type="email"
                inputMode="email"
                aria-label="Account email"
                placeholder={expectedEmail || "name@example.com"}
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                aria-invalid={Boolean(emailInput) && !emailMatches}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="delete-confirm">
                To proceed, type &quot;DELETE&quot; in the input field below.
              </Label>
              <Input
                data-testid="delete-phrase-input"
                id="delete-confirm"
                aria-label="Type DELETE to confirm"
                placeholder="DELETE"
                value={confirmInput}
                onChange={(e) => setConfirmInput(e.target.value)}
                aria-invalid={
                  Boolean(confirmInput) && confirmInput.trim() !== "DELETE"
                }
              />
            </div>
          </div>
        )}

        <DialogFooter data-testid="delete-account-footer" className="pt-4">
          {!hasRecentLogin ? (
            <Button
              type="button"
              data-testid="refresh-login-button"
              variant="outline"
              onClick={handleRefreshLogin}
              className="w-full"
            >
              Refresh login
            </Button>
          ) : (
            <Button
              type="button"
              data-testid="delete-button"
              variant="destructive"
              onClick={handleConfirmDelete}
              disabled={!canDelete}
              className="w-full"
            >
              {isDeleting ? (
                <Loader2 aria-hidden="true" className="size-4 animate-spin" />
              ) : canDelete ? (
                <TriangleAlert aria-hidden="true" className="size-4" />
              ) : (
                <Lock aria-hidden="true" className="size-4" />
              )}
              {isDeleting ? "Deleting..." : "Permanently delete my account"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default DeleteAccountDialog;
