import type { ReactNode } from "react";
import { memo, useState, useMemo } from "react";
import ShikiHighlighter, { isInlineCode, type Element } from "react-shiki";
import { useIsCodeFenceIncomplete } from "streamdown";
import { CodeActionButtons } from "@/components/ui/code-action-buttons";
import {
  isLanguageSupported as isShikiLanguageSupported,
  ShikiErrorBoundary,
} from "@/lib/utils/shiki";

interface CodeHighlightProps {
  className?: string | undefined;
  children?: ReactNode | undefined;
  node?: unknown;
}

export const MAX_STREAMING_HIGHLIGHT_CHARS = 20_000;
export const MAX_HIGHLIGHT_CHARS = 100_000;
export const MAX_HIGHLIGHT_LINES = 2_000;

const exceedsLineLimit = (code: string, limit: number): boolean => {
  let lines = 1;
  for (let index = 0; index < code.length; index += 1) {
    if (code.charCodeAt(index) === 10 && ++lines > limit) return true;
  }
  return false;
};

const CodeHighlightImpl = ({
  className,
  children,
  node,
  ...props
}: CodeHighlightProps) => {
  const match = className?.match(/language-(\w+)/);
  const language = match ? match[1] : undefined;
  const codeContent = String(children);

  const [isWrapped, setIsWrapped] = useState(false);
  const isIncomplete = useIsCodeFenceIncomplete();

  const isInline: boolean | undefined = node
    ? isInlineCode(node as Element)
    : undefined;

  const isLanguageSupported = useMemo(() => {
    return isShikiLanguageSupported(language);
  }, [language]);

  // Avoid scanning every growing block for newlines. Character length gives us
  // an O(1) streaming guard; the line limit is evaluated once the fence closes.
  const isLargeStreamingBlock =
    isIncomplete && codeContent.length > MAX_STREAMING_HIGHLIGHT_CHARS;
  const isOversizedCompletedBlock = useMemo(
    () =>
      !isIncomplete &&
      (codeContent.length > MAX_HIGHLIGHT_CHARS ||
        exceedsLineLimit(codeContent, MAX_HIGHLIGHT_LINES)),
    [codeContent, isIncomplete],
  );
  const shouldUsePlainText =
    !isLanguageSupported || isLargeStreamingBlock || isOversizedCompletedBlock;
  const highlightMode = shouldUsePlainText
    ? isLargeStreamingBlock
      ? "plain-streaming"
      : isOversizedCompletedBlock
        ? "plain-large"
        : "plain-unsupported"
    : "highlighted";

  const handleToggleWrap = () => {
    setIsWrapped(!isWrapped);
  };

  return !isInline ? (
    <div
      className="shiki not-prose relative rounded-lg bg-card border border-border my-2 overflow-hidden"
      data-highlight-mode={highlightMode}
    >
      {/* Menu bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-muted border-b border-border">
        {/* Left side - Language */}
        <div className="flex-1">
          {language && (
            <span className="text-xs tracking-tighter px-2 py-1 rounded text-secondary-foreground">
              {language}
            </span>
          )}
        </div>

        {/* Right side - Action buttons */}
        <CodeActionButtons
          content={codeContent}
          language={language}
          isWrapped={isWrapped}
          onToggleWrap={handleToggleWrap}
          variant="codeblock"
        />
      </div>

      {/* Code content */}
      <div className="overflow-hidden">
        {shouldUsePlainText ? (
          <pre
            className={`shiki not-prose relative bg-card text-sm font-[450] text-card-foreground px-[1em] py-[1em] rounded-none m-0 ${
              isWrapped
                ? "whitespace-pre-wrap break-words overflow-visible"
                : "overflow-x-auto max-w-full"
            }`}
          >
            <code>{codeContent}</code>
          </pre>
        ) : (
          <ShikiErrorBoundary
            fallback={
              <pre
                className={`shiki not-prose relative bg-card text-sm font-[450] text-card-foreground px-[1em] py-[1em] rounded-none m-0 ${
                  isWrapped
                    ? "whitespace-pre-wrap break-words overflow-visible"
                    : "overflow-x-auto max-w-full"
                }`}
              >
                <code>{codeContent}</code>
              </pre>
            }
          >
            <ShikiHighlighter
              language={language}
              theme="houston"
              delay={150}
              engine="javascript"
              addDefaultStyles={false}
              showLanguage={false}
              className={`shiki not-prose relative bg-card text-sm font-[450] text-card-foreground [&_pre]:!bg-transparent [&_pre]:px-[1em] [&_pre]:py-[1em] [&_pre]:rounded-none [&_pre]:m-0 ${
                isWrapped
                  ? "[&_pre]:whitespace-pre-wrap [&_pre]:break-words [&_pre]:overflow-visible"
                  : "[&_pre]:overflow-x-auto [&_pre]:max-w-full"
              }`}
              {...props}
            >
              {codeContent}
            </ShikiHighlighter>
          </ShikiErrorBoundary>
        )}
      </div>
    </div>
  ) : (
    <code
      className="bg-muted text-muted-foreground px-1.5 py-0.5 rounded text-sm font-mono whitespace-pre-wrap break-words [overflow-wrap:anywhere]"
      {...props}
    >
      {children}
    </code>
  );
};

// Memoize so finished code blocks don't re-highlight when sibling markdown
// re-renders during streaming. Streaming code blocks still update because
// `children` (the text) changes each token; Shiki's `delay={150}` throttles
// the actual tokenization on top of that.
export const CodeHighlight = memo(CodeHighlightImpl);
