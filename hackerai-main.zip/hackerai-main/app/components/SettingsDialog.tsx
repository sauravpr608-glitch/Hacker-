"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import {
  Settings,
  X,
  Shield,
  CircleUserRound,
  Database,
  Users,
  Infinity,
  Server,
  ChartNoAxesCombined,
  Gauge,
} from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { ManageNotesDialog } from "@/app/components/ManageNotesDialog";
import { CustomizeHackerAIDialog } from "@/app/components/CustomizeHackerAIDialog";
import { PersonalizationTab } from "@/app/components/PersonalizationTab";
import { AccountTab } from "@/app/components/AccountTab";
import { DataControlsTab } from "@/app/components/DataControlsTab";
import { TeamTab } from "@/app/components/TeamTab";
import { AgentsTab } from "@/app/components/AgentsTab";
import { RemoteControlTab } from "@/app/components/RemoteControlTab";
import { UsageTab } from "@/app/components/UsageTab";
import { ExtraUsageSection } from "@/app/components/ExtraUsageSection";
import { TeamExtraUsageSection } from "@/app/components/TeamExtraUsageSection";
import { useIsMobile } from "@/hooks/use-mobile";
import { useGlobalState } from "@/app/contexts/GlobalState";

// Keep the widget runtime and its vendor styles out of the initial app bundle.
const SecurityTab = dynamic(
  () => import("./SecurityTab").then((module) => module.SecurityTab),
  {
    ssr: false,
    loading: () => (
      <div role="status" className="text-sm text-muted-foreground">
        Loading security settings…
      </div>
    ),
  },
);

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialTab?: string | null;
}

const SettingsDialog = ({
  open,
  onOpenChange,
  initialTab,
}: SettingsDialogProps) => {
  const [activeTab, setActiveTab] = useState("Personalization");
  const [prevOpen, setPrevOpen] = useState(false);
  const [showCustomizeDialog, setShowCustomizeDialog] = useState(false);
  const [showNotesDialog, setShowNotesDialog] = useState(false);
  const isMobile = useIsMobile();
  const { subscription } = useGlobalState();
  const [isTeamAdmin, setIsTeamAdmin] = useState<boolean | null>(null);

  useEffect(() => {
    // Only consulted when subscription === "team"; tabs() condition gates
    // any other read, so a stale value after switching tier is harmless and
    // will be overwritten the next time the user becomes a team member.
    if (!open || subscription !== "team") return;
    const controller = new AbortController();

    fetch("/api/team/members", { signal: controller.signal })
      .then((res) => res.json())
      .then((data) => {
        if (!controller.signal.aborted) {
          setIsTeamAdmin(data.isAdmin ?? false);
        }
      })
      .catch(() => {
        if (!controller.signal.aborted) setIsTeamAdmin(false);
      });

    return () => controller.abort();
  }, [open, subscription]);

  // Base tabs visible to all users
  const baseTabs = [
    { id: "Personalization", label: "Personalization", icon: Settings },
    { id: "Security", label: "Security", icon: Shield },
    { id: "Data controls", label: "Data controls", icon: Database },
  ];

  // Shared tabs for all users with agent mode access
  const agentsTab = { id: "Agents", label: "Agents", icon: Infinity };
  const localSandboxTab = {
    id: "Remote Control",
    label: "Remote Control",
    icon: Server,
  };
  // Tabs only for paid users
  const usageTab = { id: "Usage", label: "Usage", icon: ChartNoAxesCombined };
  const extraUsageTab = {
    id: "Extra Usage",
    label: "Extra Usage",
    icon: Gauge,
  };
  const membersTab = { id: "Members", label: "Members", icon: Users };
  const accountTab = { id: "Account", label: "Account", icon: CircleUserRound };

  const tabs =
    subscription === "team"
      ? [
          ...baseTabs,
          agentsTab,
          localSandboxTab,
          usageTab,
          ...(isTeamAdmin ? [extraUsageTab] : []),
          membersTab,
          accountTab,
        ]
      : subscription !== "free"
        ? [
            ...baseTabs,
            agentsTab,
            localSandboxTab,
            usageTab,
            extraUsageTab,
            accountTab,
          ]
        : [...baseTabs, agentsTab, localSandboxTab, accountTab];

  const canShowInitialTab = initialTab
    ? tabs.some((t) => t.id === initialTab)
    : false;
  const [prevInitialTab, setPrevInitialTab] = useState<string | null>(null);
  const [prevCanShowInitialTab, setPrevCanShowInitialTab] = useState(false);

  if (
    initialTab &&
    canShowInitialTab &&
    ((open && !prevOpen) ||
      (open && initialTab !== prevInitialTab) ||
      (open && canShowInitialTab !== prevCanShowInitialTab))
  ) {
    setActiveTab(initialTab);
  }
  if (initialTab !== prevInitialTab) {
    setPrevInitialTab(initialTab ?? null);
  }
  if (canShowInitialTab !== prevCanShowInitialTab) {
    setPrevCanShowInitialTab(canShowInitialTab);
  }
  if (open !== prevOpen) {
    setPrevOpen(open);
  }

  const handleCustomInstructions = () => {
    setShowCustomizeDialog(true);
  };

  // const handleManageMemories = () => {
  //   setShowMemoriesDialog(true);
  // };

  const handleManageNotes = () => {
    setShowNotesDialog(true);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent
          data-testid="settings-dialog"
          className="w-[380px] max-w-[98%] md:w-[95vw] md:max-w-[920px] max-h-[95%] md:h-[672px] p-0 overflow-hidden rounded-[20px]"
          showCloseButton={!isMobile}
        >
          {/* Accessibility: Always include DialogTitle */}
          <DialogTitle className="sr-only">Settings</DialogTitle>

          {isMobile && (
            <div className="relative z-10 p-0">
              <div className="flex items-center justify-between px-4 py-3 border-b">
                <h3 className="text-lg font-semibold">Settings</h3>
                <div
                  className="flex h-7 w-7 items-center justify-center cursor-pointer rounded-md hover:bg-muted"
                  onClick={() => onOpenChange(false)}
                >
                  <X className="size-5" />
                </div>
              </div>
            </div>
          )}

          <div
            className={`flex ${isMobile ? "flex-col" : "flex-row"} ${isMobile ? "h-[80dvh]" : "h-[672px]"} max-h-[90vh] min-h-0`}
          >
            {/* Tabs */}
            <div
              className={`${isMobile ? "overflow-x-auto md:overflow-x-visible border-r pb-2 md:pb-0 relative" : "md:w-[221px] border-r"}`}
            >
              {!isMobile && (
                <div className="items-center hidden px-5 pt-5 pb-3 md:flex">
                  <div className="flex">
                    {/* Logo space - not adding logo as requested */}
                  </div>
                </div>
              )}
              <div className="relative flex w-full">
                <div className="flex-1 flex items-start self-stretch px-3 w-full pb-0 border-b md:border-b-0 md:flex-col md:gap-3 md:px-2 max-md:gap-2.5">
                  <div className="flex md:gap-0.5 gap-2.5 md:flex-col items-start self-stretch flex-wrap md:flex-nowrap">
                    {tabs.map((tab) => {
                      const IconComponent = tab.icon;
                      return (
                        <button
                          key={tab.id}
                          data-testid={`settings-tab-${tab.id.toLowerCase().replace(/\s+/g, "-")}`}
                          type="button"
                          onClick={() => setActiveTab(tab.id)}
                          className={`group flex items-center gap-1.5 px-1 py-2 text-sm leading-5 max-md:whitespace-nowrap md:h-12 md:gap-2.5 md:self-stretch md:px-4 md:rounded-lg hover:bg-muted transition-colors ${
                            activeTab === tab.id
                              ? `${isMobile ? "font-medium" : "bg-muted font-medium"}`
                              : ""
                          } ${isMobile && activeTab === tab.id ? "relative" : ""}`}
                        >
                          {!isMobile && (
                            <div className="flex items-center justify-center">
                              <IconComponent className="h-5 w-5" />
                            </div>
                          )}
                          <div className="flex min-w-0 grow items-center">
                            <div className="truncate">{tab.label}</div>
                          </div>
                          {isMobile && activeTab === tab.id && (
                            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-foreground"></div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* Content area */}
            <div className="flex flex-col items-start self-stretch flex-1 overflow-hidden min-h-0">
              {!isMobile && (
                <div className="gap-1 items-center px-6 py-5 hidden md:flex self-stretch border-b">
                  <h3 className="text-lg font-medium">{activeTab}</h3>
                </div>
              )}
              <div className="flex-1 self-stretch items-start overflow-y-auto px-4 pt-4 pb-4 md:px-6 md:pt-4 min-h-0">
                {activeTab === "Personalization" && (
                  <PersonalizationTab
                    onCustomInstructions={handleCustomInstructions}
                    // onManageMemories={handleManageMemories}
                    onManageNotes={handleManageNotes}
                    subscription={subscription}
                  />
                )}

                {activeTab === "Security" && <SecurityTab />}

                {activeTab === "Data controls" && <DataControlsTab />}

                {activeTab === "Agents" && <AgentsTab />}

                {activeTab === "Remote Control" && <RemoteControlTab />}

                {activeTab === "Usage" && <UsageTab />}

                {activeTab === "Extra Usage" && (
                  <div className="space-y-2">
                    {subscription === "team" ? (
                      <TeamExtraUsageSection />
                    ) : (
                      <ExtraUsageSection />
                    )}
                  </div>
                )}

                {activeTab === "Members" && <TeamTab />}

                {activeTab === "Account" && <AccountTab />}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <ManageNotesDialog
        open={showNotesDialog}
        onOpenChange={setShowNotesDialog}
      />

      {/* Customize HackerAI Dialog */}
      <CustomizeHackerAIDialog
        open={showCustomizeDialog}
        onOpenChange={setShowCustomizeDialog}
      />
    </>
  );
};

export { SettingsDialog };
