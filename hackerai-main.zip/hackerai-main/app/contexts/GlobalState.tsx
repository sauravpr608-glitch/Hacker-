"use client";

import React, {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  ReactNode,
} from "react";
import { usePathname } from "next/navigation";
import { useAccessToken, useAuth } from "@workos-inc/authkit-nextjs/components";
import {
  type ChatMode,
  type AgentPermissionMode,
  type SelectedModel,
  type SidebarContent,
  type QueuedMessage,
  type QueueBehavior,
  type SandboxPreference,
  isChatMode,
  isSidebarTerminal,
  normalizeSelectedModelForSubscription,
} from "@/types/chat";
import type { Todo } from "@/types";
import {
  mergeTodos as mergeTodosUtil,
  computeReplaceAssistantTodos,
  type TodoLike,
} from "@/lib/utils/todo-utils";
import type { UploadedFileState } from "@/types/file";
import type { FileMessagePart } from "@/types/file";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  useSandboxPreference,
  type SetSandboxPreference,
  type DesktopBridgeStatus,
} from "@/app/hooks/useSandboxPreference";
import { isTauriEnvironment } from "@/app/hooks/useTauri";
import { resolveSubscriptionTier } from "@/lib/auth/entitlements";
import { clearSharedToken, setSharedToken } from "@/lib/auth/shared-token";
import { chatSidebarStorage } from "@/lib/utils/sidebar-storage";
import { useMutation, useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import type { SubscriptionTier } from "@/types";
import { v4 as uuidv4 } from "uuid";
import { toast } from "sonner";
import {
  readChatMode,
  readAgentPermissionMode,
  writeChatMode,
  writeAgentPermissionMode,
  readSelectedModel,
  writeSelectedModel,
  cleanupExpiredDrafts,
  markHasAuthenticatedBefore,
} from "@/lib/utils/client-storage";
import { captureAuthenticatedEvent } from "@/lib/analytics/client";
import {
  getAgentFirstDefaultDecision,
  normalizeAgentFirstSandboxType,
} from "@/lib/activation/agent-first-default";
import { resolveFreeDesktopSandboxPreference } from "@/lib/activation/free-desktop-sandbox";
import { useAutoSelectNewRemoteConnection } from "@/app/hooks/useAutoSelectNewRemoteConnection";
import { environmentPreference } from "@/lib/sandbox/environment";
import {
  ComposerStateProvider,
  useComposerActions,
} from "@/app/contexts/ComposerState";

const ENTITLEMENT_REFRESH_TIMEOUT_MS = 5_000;
const ENTITLEMENT_REFRESH_RETRY_DELAYS_MS = [1_000, 3_000] as const;

interface GlobalStateType {
  // File upload state
  uploadedFiles: UploadedFileState[];
  getUploadedFiles: () => UploadedFileState[];
  setUploadedFiles: (files: UploadedFileState[]) => void;
  addUploadedFile: (file: UploadedFileState) => void;
  removeUploadedFile: (target: number | UploadedFileState["file"]) => void;
  updateUploadedFile: (
    target: number | UploadedFileState["file"],
    updates: Partial<UploadedFileState>,
  ) => void;

  // Token tracking function
  getTotalTokens: () => number;

  // File upload status tracking
  isUploadingFiles: boolean;

  // Chat mode state
  chatMode: ChatMode;
  setChatMode: (mode: ChatMode) => void;
  chatModeAccessResolved: boolean;
  paidAgentOnlyActive: boolean;
  freeDesktopAgentOnlyActive: boolean;

  // Computer sidebar state (right side)
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  sidebarContent: SidebarContent | null;
  setSidebarContent: (content: SidebarContent | null) => void;

  // Chat sidebar state (left side)
  chatSidebarOpen: boolean;
  setChatSidebarOpen: (open: boolean) => void;
  optimisticChatId: string | null;
  setOptimisticChatId: (chatId: string | null) => void;
  activeProjectId: string | null;
  setActiveProjectId: (projectId: string | null) => void;

  // Todos state
  todos: Todo[];
  setTodos: (todos: Todo[]) => void;
  mergeTodos: (todos: TodoLike[]) => void;
  replaceAssistantTodos: (todos: Todo[], sourceMessageId?: string) => void;

  // UI state
  isTodoPanelExpanded: boolean;
  setIsTodoPanelExpanded: (expanded: boolean) => void;

  // Subscription state
  subscription: SubscriptionTier;
  isCheckingProPlan: boolean;

  // Rate limit warning dismissal state
  hasUserDismissedRateLimitWarning: boolean;
  setHasUserDismissedRateLimitWarning: (dismissed: boolean) => void;

  // Message queue state (for Agent mode)
  messageQueue: QueuedMessage[];
  queueMessage: (text: string, files?: FileMessagePart[]) => string | undefined;
  updateQueuedMessage: (id: string, text: string) => void;
  editingQueuedMessageId: string | null;
  setEditingQueuedMessageId: (messageId: string | null) => void;
  removeQueuedMessage: (id: string) => void;
  setQueuedMessageDelivery: (
    id: string,
    status: NonNullable<QueuedMessage["deliveryStatus"]>,
    firstAttemptAt: number,
  ) => void;
  clearQueue: () => void;

  // Queue behavior preference
  queueBehavior: QueueBehavior;
  setQueueBehavior: (behavior: QueueBehavior) => void;

  // Sandbox preference (for Agent mode)
  sandboxPreference: SandboxPreference;
  setSandboxPreference: SetSandboxPreference;
  resetSandboxPreference: () => void;

  // Agent tool approval behavior
  agentPermissionMode: AgentPermissionMode;
  setAgentPermissionMode: (mode: AgentPermissionMode) => void;

  // Desktop bridge active (Centrifugo-based desktop sandbox)
  desktopBridgeActive: boolean;
  desktopBridgeStatus: DesktopBridgeStatus;
  desktopEnvironmentId?: string;
  retryDesktopBridge: () => void;

  // Whether a local sandbox (desktop or remote) is available
  hasLocalSandbox: boolean;

  // Active local sandbox connections, shared to avoid duplicate Convex subscriptions
  localConnections: LocalSandboxConnection[] | undefined;

  // The sandbox preference to use for free agent mode (desktop or first remote connection ID)
  defaultLocalSandboxPreference: SandboxPreference | null;

  // Model selection
  selectedModel: SelectedModel;
  setSelectedModel: (model: SelectedModel) => void;

  // Utility methods
  getInput: () => string;
  clearInput: () => void;
  clearUploadedFiles: () => void;
  openSidebar: (content: SidebarContent) => void;
  updateSidebarContent: (updates: Partial<SidebarContent>) => void;
  consumeBrowserTakeoverRequest: (requestId: string) => void;
  closeSidebar: () => void;
  toggleChatSidebar: () => void;
  initializeChat: (chatId: string, fromRoute?: boolean) => void;
  initializeNewChat: () => void;

  // Team pricing dialog state
  teamPricingDialogOpen: boolean;
  setTeamPricingDialogOpen: (open: boolean) => void;

  // Team welcome dialog state
  teamWelcomeDialogOpen: boolean;
  setTeamWelcomeDialogOpen: (open: boolean) => void;

  // PentestGPT migration confirm dialog state
  migrateFromPentestgptDialogOpen: boolean;
  setMigrateFromPentestgptDialogOpen: (open: boolean) => void;

  // Register a chat reset function that will be invoked on initializeNewChat
  setChatReset: (fn: (() => void) | null) => void;
  // Register stream cleanup that runs before navigating to another chat
  setChatNavigationHandler: (fn: ((nextChatId: string) => void) | null) => void;
}

type GlobalStateActionsType = Pick<
  GlobalStateType,
  | "closeSidebar"
  | "initializeChat"
  | "initializeNewChat"
  | "setActiveProjectId"
  | "setChatSidebarOpen"
  | "setSandboxPreference"
>;

const GlobalStateContext = createContext<GlobalStateType | undefined>(
  undefined,
);
const GlobalStateActionsContext = createContext<
  GlobalStateActionsType | undefined
>(undefined);

interface GlobalStateProviderProps {
  children: ReactNode;
}

interface LocalSandboxConnection {
  connectionId: string;
  environmentId?: string;
  createdAt?: number;
  name: string;
  osInfo?: {
    platform: string;
    arch: string;
    release: string;
    hostname: string;
  };
  lastSeen: number;
  isDesktop: boolean;
  capabilities: {
    commands: boolean;
    pty: boolean;
    files?: boolean;
  };
}

const GlobalStateProviderInner: React.FC<GlobalStateProviderProps> = ({
  children,
}) => {
  const { clearInput, getInput } = useComposerActions();
  const {
    user,
    entitlements,
    loading: authLoading,
    organizationId,
    refreshAuth,
  } = useAuth();
  const { refresh: refreshAccessToken } = useAccessToken();
  const isMobile = useIsMobile();
  const prevIsMobile = useRef(isMobile);
  const shownReferralRewardNotificationsRef = useRef(new Set<string>());
  const initialSavedChatModeRef = useRef<ChatMode | null>(null);
  const hasUserSelectedModeThisSessionRef = useRef(false);
  const agentFirstDefaultAppliedRef = useRef(false);
  const [uploadedFiles, setUploadedFilesState] = useState<UploadedFileState[]>(
    [],
  );
  const uploadedFilesRef = useRef<UploadedFileState[]>([]);
  const getUploadedFiles = useCallback(() => uploadedFilesRef.current, []);
  // Admission and composer cleanup must observe attachment changes immediately,
  // before React publishes the corresponding render.
  const setUploadedFiles = useCallback(
    (
      update:
        | UploadedFileState[]
        | ((files: UploadedFileState[]) => UploadedFileState[]),
    ) => {
      const next =
        typeof update === "function"
          ? update(uploadedFilesRef.current)
          : update;
      uploadedFilesRef.current = next;
      setUploadedFilesState(next);
    },
    [],
  );
  const [chatMode, setChatModeState] = useState<ChatMode>(() => {
    const saved = readChatMode();
    if (!isChatMode(saved)) return "ask";
    initialSavedChatModeRef.current = saved;
    return saved;
  });
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarContent, setSidebarContent] = useState<SidebarContent | null>(
    null,
  );
  const [subscription, setSubscription] = useState<SubscriptionTier>("free");
  const setSubscriptionWithNormalize = useCallback((tier: SubscriptionTier) => {
    setSubscription(tier);
  }, []);
  const [isCheckingProPlan, setIsCheckingProPlan] = useState(false);
  const [entitlementApiResolvedUserId, setEntitlementApiResolvedUserId] =
    useState<string | null>(null);
  const [entitlementRefreshRetryNonce, setEntitlementRefreshRetryNonce] =
    useState(0);
  const subscriptionFromEntitlements = useMemo<SubscriptionTier | null>(() => {
    if (!Array.isArray(entitlements)) return null;
    return resolveSubscriptionTier(entitlements);
  }, [entitlements]);
  const refreshAuthTokenAfterEntitlementRefresh = useCallback(async () => {
    clearSharedToken();

    try {
      if (refreshAuth) {
        await refreshAuth(organizationId ? { organizationId } : undefined);
      }
    } catch {
      // Keep going: the access-token refresh below may still pick up the
      // sealed session written by /api/entitlements.
    }

    try {
      const token = await refreshAccessToken();
      if (token) {
        setSharedToken(token);
      }
    } catch {
      // Non-fatal. The UI still reflects /api/entitlements, and AuthKit will
      // retry token refresh through its normal path.
    }
  }, [organizationId, refreshAccessToken, refreshAuth]);

  // Persist chat mode preference to localStorage on change
  useEffect(() => {
    if (
      initialSavedChatModeRef.current === null &&
      !agentFirstDefaultAppliedRef.current &&
      !hasUserSelectedModeThisSessionRef.current
    ) {
      return;
    }

    writeChatMode(chatMode);
  }, [chatMode]);

  useEffect(() => {
    if (user) {
      markHasAuthenticatedBefore();
    }
  }, [user]);

  useEffect(() => {
    if (!user) return;

    fetch("/api/referrals/attribution", {
      method: "POST",
      credentials: "include",
    })
      .then(async (response) => {
        if (!response.ok) return;
        const body = (await response.json().catch(() => null)) as {
          status?: string;
          starterBonusUnitsAwarded?: boolean;
          starterBonusUnits?: number;
        } | null;
        const bonusUnits =
          typeof body?.starterBonusUnits === "number"
            ? body.starterBonusUnits
            : 0;

        if (
          body?.status === "attributed" &&
          body.starterBonusUnitsAwarded &&
          bonusUnits > 0
        ) {
          toast.success("Referral bonus added", {
            description: `You got ${bonusUnits} extra free request${bonusUnits === 1 ? "" : "s"}.`,
          });
        }
      })
      .catch(() => {
        // Referral attribution is best-effort and must never block app startup.
      });
  }, [user]);

  const unreadReferralRewardNotifications = useQuery(
    api.referrals.getUnreadRewardNotifications,
    user ? {} : "skip",
  );
  const markReferralRewardNotificationsSeen = useMutation(
    api.referrals.markRewardNotificationsSeen,
  );

  useEffect(() => {
    if (!user || !unreadReferralRewardNotifications?.length) return;

    const notifications = unreadReferralRewardNotifications.filter(
      (notification) =>
        !shownReferralRewardNotificationsRef.current.has(notification.rewardId),
    );
    if (notifications.length === 0) return;

    for (const notification of notifications) {
      shownReferralRewardNotificationsRef.current.add(notification.rewardId);
    }

    const totalDollars = notifications.reduce(
      (sum, notification) => sum + notification.amountDollars,
      0,
    );
    const amountLabel = new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: Number.isInteger(totalDollars) ? 0 : 2,
    }).format(totalDollars);
    const rewardIds = notifications.map(
      (notification) => notification.rewardId,
    );

    const description =
      subscription === "free"
        ? `You earned ${amountLabel} in usage credits. They apply after you upgrade.`
        : `You earned ${amountLabel} in extra usage credits.`;

    toast.success("Referral reward added", { description });
    void markReferralRewardNotificationsSeen({ rewardIds }).catch(() => {
      // The toast is non-critical; the next app load can retry marking it seen.
    });
  }, [
    markReferralRewardNotificationsSeen,
    subscription,
    unreadReferralRewardNotifications,
    user,
  ]);

  // Initialize chat sidebar state
  const [chatSidebarOpen, setChatSidebarOpen] = useState(() =>
    chatSidebarStorage.get(isMobile ?? false),
  );
  const [optimisticChatId, setOptimisticChatId] = useState<string | null>(null);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(() => {
    if (typeof window === "undefined") return null;
    return new URLSearchParams(window.location.search).get("project");
  });

  useEffect(() => {
    const syncActiveProjectFromUrl = () => {
      setActiveProjectId(
        new URLSearchParams(window.location.search).get("project"),
      );
    };

    window.addEventListener("popstate", syncActiveProjectFromUrl);
    return () => {
      window.removeEventListener("popstate", syncActiveProjectFromUrl);
    };
  }, []);
  const [todos, setTodos] = useState<Todo[]>([]);
  const [isTodoPanelExpanded, setIsTodoPanelExpanded] = useState(false);
  const mergeTodos = useCallback((newTodos: TodoLike[]) => {
    setTodos((currentTodos) => mergeTodosUtil(currentTodos, newTodos));
  }, []);
  const replaceAssistantTodos = useCallback(
    (incoming: Todo[], sourceMessageId?: string) => {
      setTodos((current) =>
        computeReplaceAssistantTodos(current, incoming, sourceMessageId),
      );
    },
    [],
  );
  const chatResetRef = useRef<(() => void) | null>(null);
  const chatNavigationHandlerRef = useRef<
    ((nextChatId: string) => void) | null
  >(null);
  const entitlementRefreshUserRef = useRef<string | null>(null);
  const entitlementRefreshFailureRef = useRef<{
    userId: string;
    count: number;
  } | null>(null);
  const [entitlementRefreshFailure, setEntitlementRefreshFailure] = useState<{
    userId: string;
    count: number;
  } | null>(null);

  // Rate limit warning dismissal state (persists across chat switches)
  const [
    hasUserDismissedRateLimitWarning,
    setHasUserDismissedRateLimitWarning,
  ] = useState(false);

  // Message queue state (for Agent mode queueing)
  const [messageQueue, setMessageQueueState] = useState<QueuedMessage[]>([]);
  // Queue admission must be synchronous even when React batches submissions.
  // Every queue mutation updates this snapshot before publishing UI state.
  const messageQueueRef = useRef<QueuedMessage[]>([]);
  const setMessageQueue = useCallback(
    (
      update: QueuedMessage[] | ((queue: QueuedMessage[]) => QueuedMessage[]),
    ) => {
      const next =
        typeof update === "function" ? update(messageQueueRef.current) : update;
      messageQueueRef.current = next;
      setMessageQueueState(next);
    },
    [],
  );
  const [editingQueuedMessageId, setEditingQueuedMessageId] = useState<
    string | null
  >(null);

  // Queue behavior preference (persisted to localStorage)
  const [queueBehavior, setQueueBehaviorState] = useState<QueueBehavior>(() => {
    if (typeof window === "undefined") return "queue";
    const saved = localStorage.getItem("queue-behavior");
    if (saved === "queue" || saved === "stop-and-send") {
      return saved;
    }
    return "queue"; // Default: queue after current message completes
  });

  // Tauri detection + sandbox preference (co-located in a custom hook)
  const {
    sandboxPreference,
    hasExplicitSandboxPreference,
    setSandboxPreference,
    resetSandboxPreference,
    desktopBridgeActive,
    desktopBridgeStatus,
    desktopEnvironmentId,
    retryDesktopBridge,
  } = useSandboxPreference(!!user);

  const [agentPermissionMode, setAgentPermissionMode] =
    useState<AgentPermissionMode>(() => readAgentPermissionMode());

  useEffect(() => {
    writeAgentPermissionMode(agentPermissionMode);
  }, [agentPermissionMode]);

  // Check for available local sandbox connections
  const localConnections = useQuery(
    api.localSandbox.listConnections,
    user ? undefined : "skip",
  );
  const hasLocalSandbox = useMemo(
    () => desktopBridgeActive || (localConnections?.length ?? 0) > 0,
    [desktopBridgeActive, localConnections],
  );

  const defaultLocalSandboxPreference =
    useMemo<SandboxPreference | null>(() => {
      if (desktopBridgeActive)
        return desktopEnvironmentId
          ? `desktop-environment:${desktopEnvironmentId}`
          : "desktop";
      const firstRemote = localConnections?.find((c) => !c.isDesktop);
      if (firstRemote) return environmentPreference(firstRemote);
      const firstDesktop = localConnections?.find((c) => c.isDesktop);
      if (firstDesktop) return environmentPreference(firstDesktop);
      return null;
    }, [desktopBridgeActive, desktopEnvironmentId, localConnections]);

  const entitlementRefreshRequested =
    typeof window !== "undefined" &&
    new URL(window.location.href).searchParams.get("refresh") ===
      "entitlements";
  const automaticEntitlementRefreshNeeded =
    Boolean(user) &&
    !authLoading &&
    (subscriptionFromEntitlements === null ||
      (subscriptionFromEntitlements === "free" && isTauriEnvironment())) &&
    !entitlementRefreshRequested;
  const automaticEntitlementRefreshPending =
    automaticEntitlementRefreshNeeded &&
    subscriptionFromEntitlements === null &&
    entitlementApiResolvedUserId !== user?.id &&
    entitlementRefreshUserRef.current !== user?.id;
  const subscriptionResolved =
    Boolean(user) &&
    !authLoading &&
    (subscriptionFromEntitlements !== null ||
      entitlementApiResolvedUserId === user?.id) &&
    !entitlementRefreshRequested &&
    !automaticEntitlementRefreshPending;
  const tokenFreeAutomaticRefreshExhausted =
    subscriptionFromEntitlements === "free" &&
    entitlementRefreshFailure?.userId === user?.id &&
    (entitlementRefreshFailure?.count ?? 0) >
      ENTITLEMENT_REFRESH_RETRY_DELAYS_MS.length;
  const freeSubscriptionResolved =
    subscriptionResolved &&
    (!automaticEntitlementRefreshNeeded ||
      entitlementApiResolvedUserId === user?.id ||
      tokenFreeAutomaticRefreshExhausted);

  // Persist queue behavior to localStorage
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("queue-behavior", queueBehavior);
    }
  }, [queueBehavior]);

  // Paid Agent tier ids are resolved to providers server-side.
  const [selectedModel, setSelectedModelRaw] = useState<SelectedModel>(() => {
    const saved = readSelectedModel();
    return saved ?? "auto";
  });

  // Persist model preference to localStorage (single key, shared across modes).
  useEffect(() => {
    writeSelectedModel(selectedModel);
  }, [selectedModel]);

  useEffect(() => {
    if (!subscriptionResolved) return;
    if (subscription === "free" && !freeSubscriptionResolved) return;
    const normalizedModel = normalizeSelectedModelForSubscription(
      selectedModel,
      subscription,
    );
    if (normalizedModel !== selectedModel) {
      setSelectedModelRaw(normalizedModel);
    }
  }, [
    freeSubscriptionResolved,
    selectedModel,
    subscription,
    subscriptionResolved,
  ]);

  const setSelectedModelState = useCallback((model: SelectedModel) => {
    setSelectedModelRaw(model);
  }, []);

  const paidAgentSubscription =
    subscriptionFromEntitlements !== null &&
    subscriptionFromEntitlements !== "free"
      ? subscriptionFromEntitlements
      : subscription;
  const agentFirstSubscriptionResolved =
    paidAgentSubscription === "free"
      ? freeSubscriptionResolved
      : subscriptionResolved;

  useEffect(() => {
    if (agentFirstDefaultAppliedRef.current) return;

    const savedModePresent = initialSavedChatModeRef.current !== null;
    const userSelectedModeThisSession =
      hasUserSelectedModeThisSessionRef.current;
    const agentDefaultDecision = getAgentFirstDefaultDecision({
      chatMode,
      defaultLocalSandboxPreference,
      hasLocalSandbox,
      hasSavedChatMode: savedModePresent,
      hasUserSelectedModeThisSession: userSelectedModeThisSession,
      isCheckingProPlan,
      isMobile,
      subscription: paidAgentSubscription,
      subscriptionResolved: agentFirstSubscriptionResolved,
      userPresent: Boolean(user),
    });

    if (!agentDefaultDecision) {
      return;
    }

    const localSandboxPreference =
      agentDefaultDecision.useDefaultLocalSandbox && sandboxPreference === "e2b"
        ? defaultLocalSandboxPreference
        : null;

    if (
      agentDefaultDecision.useDefaultLocalSandbox &&
      sandboxPreference === "e2b" &&
      !localSandboxPreference
    ) {
      return;
    }

    const appliedSandboxPreference =
      localSandboxPreference ?? sandboxPreference;
    const sandboxType = normalizeAgentFirstSandboxType(
      appliedSandboxPreference ?? null,
    );

    agentFirstDefaultAppliedRef.current = true;
    setChatModeState("agent");
    if (localSandboxPreference) {
      setSandboxPreference(localSandboxPreference, { remember: false });
    }
    if (selectedModel !== "auto") {
      setSelectedModelRaw("auto");
    }

    const now = new Date().toISOString();
    const agentFirstProperties = {
      experiment_key: agentDefaultDecision.experimentKey,
      first_experience_event_version: 4,
      variant: "agent_first",
      assignment_type: "deterministic_eligibility",
      assignment_unit: "authenticated_user",
      randomized_assignment: false,
      control_variant_available: false,
      exposure_trigger: "default_applied",
      subscription: paidAgentSubscription,
      eligible_subscription_tier: agentDefaultDecision.eligibleSubscriptionTier,
      selected_subscription_tier: paidAgentSubscription,
      selection_reason: agentDefaultDecision.selectionReason,
      default_applied: true,
      has_local_sandbox: hasLocalSandbox,
      sandbox_type: sandboxType === "e2b" ? "cloud" : sandboxType,
      sandbox_preference: sandboxType,
      surface: "new_chat",
      previous_saved_mode: savedModePresent,
      saved_mode_present: savedModePresent,
      user_selected_mode_this_session: userSelectedModeThisSession,
      is_mobile: isMobile === true,
      current_mode_before: chatMode,
      $set_once: {
        first_experience_variant: "agent_first",
        first_experience_applied_at: now,
      },
    };
    captureAuthenticatedEvent(
      "agent_first_default_applied",
      agentFirstProperties,
    );
  }, [
    chatMode,
    agentFirstSubscriptionResolved,
    defaultLocalSandboxPreference,
    hasLocalSandbox,
    isCheckingProPlan,
    isMobile,
    paidAgentSubscription,
    sandboxPreference,
    selectedModel,
    setSandboxPreference,
    subscriptionResolved,
    user,
  ]);

  const chatModeAccessResolved =
    !authLoading && (!user || (subscriptionResolved && !isCheckingProPlan));
  const paidAgentOnlyActive =
    Boolean(user) &&
    subscriptionResolved &&
    !isCheckingProPlan &&
    paidAgentSubscription !== "free";
  const freeDesktopAgentOnlyActive =
    Boolean(user) &&
    freeSubscriptionResolved &&
    !isCheckingProPlan &&
    paidAgentSubscription === "free" &&
    isTauriEnvironment();
  const agentOnlyActive = paidAgentOnlyActive || freeDesktopAgentOnlyActive;
  const accessibleChatMode: ChatMode = agentOnlyActive ? "agent" : chatMode;
  const freeDesktopSandboxPreference = useMemo(
    () =>
      freeDesktopAgentOnlyActive
        ? resolveFreeDesktopSandboxPreference({
            sandboxPreference,
            desktopBridgeActive,
            localConnections,
          })
        : null,
    [
      desktopBridgeActive,
      freeDesktopAgentOnlyActive,
      localConnections,
      sandboxPreference,
    ],
  );

  const setChatMode = useCallback(
    (mode: ChatMode) => {
      if (agentOnlyActive && mode !== "agent") return;
      hasUserSelectedModeThisSessionRef.current = true;
      setChatModeState(mode);
    },
    [agentOnlyActive],
  );

  const pathname = usePathname();
  useAutoSelectNewRemoteConnection({
    connections: localConnections,
    enabled: Boolean(user),
    isNewChat: pathname === "/",
    hasExplicitSandboxPreference,
    chatMode: accessibleChatMode,
    setChatMode,
    subscription: paidAgentSubscription,
    freeSubscriptionResolved,
    sandboxPreference,
    setSandboxPreference,
    selectedModel,
    setSelectedModel: setSelectedModelState,
  });

  useEffect(() => {
    if (!agentOnlyActive) return;
    if (
      freeDesktopSandboxPreference &&
      sandboxPreference !== freeDesktopSandboxPreference
    ) {
      setSandboxPreference(freeDesktopSandboxPreference, { remember: false });
    }
    if (freeDesktopAgentOnlyActive && selectedModel !== "auto") {
      setSelectedModelRaw("auto");
    }
  }, [
    agentOnlyActive,
    freeDesktopSandboxPreference,
    freeDesktopAgentOnlyActive,
    sandboxPreference,
    selectedModel,
    setSandboxPreference,
  ]);

  // Initialize team pricing dialog from URL hash
  const [teamPricingDialogOpen, setTeamPricingDialogOpen] = useState(() => {
    if (typeof window === "undefined") return false;
    return window.location.hash === "#team-pricing-seat-selection";
  });

  // Initialize team welcome dialog from URL parameter
  const [teamWelcomeDialogOpen, setTeamWelcomeDialogOpen] = useState(() => {
    if (typeof window === "undefined") return false;
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get("team-welcome") === "true";
  });

  // Initialize PentestGPT migration confirm dialog from URL parameter
  const [migrateFromPentestgptDialogOpen, setMigrateFromPentestgptDialogOpen] =
    useState(() => {
      if (typeof window === "undefined") return false;
      const urlParams = new URLSearchParams(window.location.search);
      return urlParams.get("confirm-migrate-pentestgpt") === "true";
    });

  useEffect(() => {
    // Save state on desktop
    chatSidebarStorage.save(chatSidebarOpen, isMobile ?? false);

    // Close sidebar when transitioning from desktop to mobile
    if (!prevIsMobile.current && isMobile && chatSidebarOpen) {
      setChatSidebarOpen(false);
    }

    prevIsMobile.current = isMobile;
  }, [chatSidebarOpen, isMobile]);

  // Cleanup expired drafts on app initialization (once per session)
  useEffect(() => {
    cleanupExpiredDrafts();
  }, []); // Empty dependency array = runs once on mount

  // Derive subscription tier from current token entitlements
  // When user is still loading, set subscription without normalizing chatMode (avoids resetting mode before auth resolves)
  useEffect(() => {
    if (!user) {
      setSubscription("free");
      entitlementRefreshUserRef.current = null;
      entitlementRefreshFailureRef.current = null;
      setEntitlementRefreshFailure(null);
      setEntitlementApiResolvedUserId(null);
      return;
    }

    if (subscriptionFromEntitlements) {
      setSubscriptionWithNormalize(subscriptionFromEntitlements);
    }
  }, [user, subscriptionFromEntitlements, setSubscriptionWithNormalize]);

  // AuthKit can omit entitlements on unscoped sessions, including web preview
  // sessions. Resolve those through the authoritative API before exposing mode
  // access. Desktop sessions also recheck token-free state because their
  // separate OAuth transfer flow may leave paid entitlements stale.
  useEffect(() => {
    let cancelled = false;
    let requestSettled = false;
    let controller: AbortController | null = null;
    let timeoutId: ReturnType<typeof setTimeout> | null = null;
    let retryTimeoutId: ReturnType<typeof setTimeout> | null = null;

    const refreshEntitlements = async () => {
      if (!user || typeof window === "undefined") {
        setIsCheckingProPlan(false);
        return;
      }

      if (
        !automaticEntitlementRefreshNeeded ||
        entitlementApiResolvedUserId === user.id
      ) {
        setIsCheckingProPlan(false);
        return;
      }

      if (entitlementRefreshUserRef.current === user.id) {
        return;
      }
      entitlementRefreshUserRef.current = user.id;

      setIsCheckingProPlan(true);
      controller = new AbortController();
      timeoutId = setTimeout(
        () => controller?.abort(),
        ENTITLEMENT_REFRESH_TIMEOUT_MS,
      );
      try {
        const response = await fetch("/api/entitlements", {
          credentials: "include",
          signal: controller.signal,
        });
        if (!response.ok) {
          throw new Error("Entitlement refresh failed");
        }

        const data = await response.json();
        if (cancelled) return;
        const tier = resolveSubscriptionTier(
          Array.isArray(data.entitlements) ? data.entitlements : [],
        );
        setSubscriptionWithNormalize(tier);
        setEntitlementApiResolvedUserId(user.id);
        entitlementRefreshFailureRef.current = null;
        setEntitlementRefreshFailure(null);
        // The API response is authoritative for the UI. Refresh AuthKit and the
        // shared access token in the background so a slow token refresh cannot
        // keep the free Ask/Agent selector hidden.
        void refreshAuthTokenAfterEntitlementRefresh();
      } catch {
        // Keep access unresolved when AuthKit omitted entitlements. A token-free
        // desktop session can still safely fall back to its token-derived tier.
        if (!cancelled) {
          if (entitlementRefreshUserRef.current === user.id) {
            entitlementRefreshUserRef.current = null;
          }
          const previousFailureCount =
            entitlementRefreshFailureRef.current?.userId === user.id
              ? entitlementRefreshFailureRef.current.count
              : 0;
          const failureCount = previousFailureCount + 1;
          const nextFailure = {
            userId: user.id,
            count: failureCount,
          };
          entitlementRefreshFailureRef.current = nextFailure;
          setEntitlementRefreshFailure(nextFailure);
          const retryDelay =
            ENTITLEMENT_REFRESH_RETRY_DELAYS_MS[failureCount - 1];
          if (retryDelay !== undefined) {
            retryTimeoutId = setTimeout(
              () => setEntitlementRefreshRetryNonce((nonce) => nonce + 1),
              retryDelay,
            );
          }
        }
      } finally {
        requestSettled = true;
        if (timeoutId !== null) clearTimeout(timeoutId);
        if (!cancelled) setIsCheckingProPlan(false);
      }
    };

    refreshEntitlements();

    return () => {
      cancelled = true;
      if (
        controller !== null &&
        !requestSettled &&
        entitlementRefreshUserRef.current === user?.id
      ) {
        entitlementRefreshUserRef.current = null;
      }
      controller?.abort();
      if (timeoutId !== null) clearTimeout(timeoutId);
      if (retryTimeoutId !== null) clearTimeout(retryTimeoutId);
    };
  }, [
    user,
    authLoading,
    entitlementRefreshRequested,
    automaticEntitlementRefreshNeeded,
    entitlementApiResolvedUserId,
    entitlementRefreshRetryNonce,
    refreshAuthTokenAfterEntitlementRefresh,
    setSubscriptionWithNormalize,
  ]);

  // Refresh entitlements only when explicitly requested via URL param
  useEffect(() => {
    const refreshFromUrl = async () => {
      if (!user) {
        setSubscriptionWithNormalize("free");
        setIsCheckingProPlan(false);
        return;
      }

      if (typeof window === "undefined") return;

      const url = new URL(window.location.href);
      const shouldRefresh = url.searchParams.get("refresh") === "entitlements";
      if (!shouldRefresh) return;

      setIsCheckingProPlan(true);
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);

        const response = await fetch("/api/entitlements", {
          credentials: "include",
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (response.ok) {
          const data = await response.json();
          await refreshAuthTokenAfterEntitlementRefresh();
          const tier = data.subscription as SubscriptionTier | undefined;
          setSubscription(
            tier === "ultra" ||
              tier === "team" ||
              tier === "pro-plus" ||
              tier === "pro"
              ? tier
              : "free",
          );
          setEntitlementApiResolvedUserId(user.id);
        } else {
          // Multiple active memberships without a selected session org are
          // ambiguous. Keep the last trustworthy tier instead of displaying a
          // false downgrade while the user selects an organization.
          if (response.status === 409) return;

          if (response.status === 401) {
            if (typeof window !== "undefined") {
              const { clientLogout } = await import("@/lib/utils/logout");
              clientLogout();
              return;
            }
          }
          setSubscriptionWithNormalize("free");
        }
      } catch {
        setSubscriptionWithNormalize("free");
      } finally {
        setIsCheckingProPlan(false);
        // Remove the refresh param to avoid repeated refreshes
        url.searchParams.delete("refresh");
        window.history.replaceState({}, "", url.toString());
      }
    };

    refreshFromUrl();
  }, [
    user,
    refreshAuthTokenAfterEntitlementRefresh,
    setSubscriptionWithNormalize,
  ]);

  // Listen for hash changes to sync team pricing dialog state
  useEffect(() => {
    const handleHashChange = () => {
      if (typeof window === "undefined") return;
      const shouldOpen =
        window.location.hash === "#team-pricing-seat-selection";

      // Only update state if it differs to avoid infinite loops
      if (teamPricingDialogOpen !== shouldOpen) {
        setTeamPricingDialogOpen(shouldOpen);
      }
    };

    // Listen for hash changes
    window.addEventListener("hashchange", handleHashChange);
    window.addEventListener("popstate", handleHashChange);

    return () => {
      window.removeEventListener("hashchange", handleHashChange);
      window.removeEventListener("popstate", handleHashChange);
    };
  }, [teamPricingDialogOpen]);

  // Listen for URL changes to sync team welcome dialog state
  useEffect(() => {
    const handleUrlChange = () => {
      if (typeof window === "undefined") return;
      const urlParams = new URLSearchParams(window.location.search);
      const shouldOpen = urlParams.get("team-welcome") === "true";

      // Only update state if it differs to avoid infinite loops
      if (teamWelcomeDialogOpen !== shouldOpen) {
        setTeamWelcomeDialogOpen(shouldOpen);
      }
    };

    // Listen for popstate events (browser back/forward)
    window.addEventListener("popstate", handleUrlChange);

    return () => {
      window.removeEventListener("popstate", handleUrlChange);
    };
  }, [teamWelcomeDialogOpen]);

  // Listen for URL changes to sync PentestGPT migration confirm dialog state
  useEffect(() => {
    const handleUrlChange = () => {
      if (typeof window === "undefined") return;
      const urlParams = new URLSearchParams(window.location.search);
      const shouldOpen = urlParams.get("confirm-migrate-pentestgpt") === "true";

      if (migrateFromPentestgptDialogOpen !== shouldOpen) {
        setMigrateFromPentestgptDialogOpen(shouldOpen);
      }
    };

    window.addEventListener("popstate", handleUrlChange);

    return () => {
      window.removeEventListener("popstate", handleUrlChange);
    };
  }, [migrateFromPentestgptDialogOpen]);

  const clearUploadedFiles = () => {
    setUploadedFiles([]);
  };

  // Calculate total tokens from all files that have tokens
  const getTotalTokens = useCallback((): number => {
    return uploadedFiles.reduce((total, file) => {
      return file.tokens ? total + file.tokens : total;
    }, 0);
  }, [uploadedFiles]);

  // Check if any files are currently uploading or have errors
  const isUploadingFiles = uploadedFiles.some(
    (file) => file.uploading || file.error,
  );

  const addUploadedFile = useCallback(
    (file: UploadedFileState) => {
      setUploadedFiles((prev) => [...prev, file]);
    },
    [setUploadedFiles],
  );

  const removeUploadedFile = useCallback(
    (target: number | UploadedFileState["file"]) => {
      setUploadedFiles((prev) =>
        prev.filter((file, i) =>
          typeof target === "number" ? i !== target : file.file !== target,
        ),
      );
    },
    [setUploadedFiles],
  );

  const updateUploadedFile = useCallback(
    (
      target: number | UploadedFileState["file"],
      updates: Partial<UploadedFileState>,
    ) => {
      setUploadedFiles((prev) =>
        prev.map((file, i) =>
          (typeof target === "number" ? i === target : file.file === target)
            ? { ...file, ...updates }
            : file,
        ),
      );
    },
    [setUploadedFiles],
  );

  // Message queue handlers
  const queueMessage = useCallback(
    (text: string, files?: FileMessagePart[]) => {
      if (messageQueueRef.current.length >= 10) {
        toast.error("Queue is full", {
          description:
            "Please wait for queued messages to send before adding more.",
        });
        return undefined;
      }
      const id = uuidv4();
      const newMessage: QueuedMessage = {
        id,
        text,
        files,
        timestamp: Date.now(),
      };
      setMessageQueue((prev) => [...prev, newMessage]);
      return id;
    },
    [setMessageQueue],
  );

  const removeQueuedMessage = useCallback(
    (id: string) => {
      setMessageQueue((prev) => prev.filter((msg) => msg.id !== id));
      setEditingQueuedMessageId((currentId) =>
        currentId === id ? null : currentId,
      );
    },
    [setMessageQueue],
  );

  const setQueuedMessageDelivery = useCallback(
    (
      id: string,
      deliveryStatus: NonNullable<QueuedMessage["deliveryStatus"]>,
      firstAttemptAt: number,
    ) => {
      setMessageQueue((prev) =>
        prev.map((message) =>
          message.id === id
            ? { ...message, deliveryStatus, firstAttemptAt }
            : message,
        ),
      );
    },
    [setMessageQueue],
  );

  const updateQueuedMessage = useCallback(
    (id: string, text: string) => {
      setMessageQueue((prev) =>
        prev.map((message) =>
          message.id === id && !message.deliveryStatus
            ? { ...message, text }
            : message,
        ),
      );
    },
    [setMessageQueue],
  );

  const clearQueue = useCallback(() => {
    setMessageQueue([]);
    setEditingQueuedMessageId(null);
  }, [setMessageQueue]);

  const initializeChat = useCallback((chatId: string, _fromRoute?: boolean) => {
    chatNavigationHandlerRef.current?.(chatId);
    // Don't clear input here - let ChatInput restore draft automatically
    // setInput("");  // Removed - ChatInput will handle draft restoration
    setTodos([]);
    setIsTodoPanelExpanded(false);
    setActiveProjectId(null);
  }, []);

  const initializeNewChat = useCallback(() => {
    // Allow chat component to reset its local state immediately
    if (chatResetRef.current) {
      chatResetRef.current();
    }
    setTodos([]);
    setIsTodoPanelExpanded(false);
    setActiveProjectId(null);
    resetSandboxPreference();
  }, [resetSandboxPreference]);

  const setChatReset = useCallback((fn: (() => void) | null) => {
    chatResetRef.current = fn;
  }, []);

  const setChatNavigationHandler = useCallback(
    (fn: ((nextChatId: string) => void) | null) => {
      chatNavigationHandlerRef.current = fn;
    },
    [],
  );

  const openSidebar = useCallback((content: SidebarContent) => {
    setSidebarContent(content);
    setSidebarOpen(true);
  }, []);

  const updateSidebarContent = useCallback(
    (updates: Partial<SidebarContent>) => {
      setSidebarContent((current) => {
        if (current) {
          return { ...current, ...updates } as SidebarContent;
        }
        return current;
      });
    },
    [],
  );

  const consumeBrowserTakeoverRequest = useCallback((requestId: string) => {
    setSidebarContent((current) => {
      if (
        !current ||
        !isSidebarTerminal(current) ||
        current.browserTakeoverRequest?.requestId !== requestId
      )
        return current;
      return { ...current, browserTakeoverRequest: undefined };
    });
  }, []);

  const closeSidebar = useCallback(() => {
    setSidebarOpen(false);
    setSidebarContent(null);
  }, []);

  const toggleChatSidebar = () => {
    setChatSidebarOpen((prev: boolean) => !prev);
  };

  // Custom setter for team welcome dialog that also updates URL
  const setTeamWelcomeDialogOpenWithUrl = useCallback((open: boolean) => {
    setTeamWelcomeDialogOpen(open);

    if (typeof window !== "undefined") {
      const url = new URL(window.location.href);
      if (!open) {
        // Remove the param when dialog is closed
        url.searchParams.delete("team-welcome");
        window.history.replaceState({}, "", url.toString());
      }
    }
  }, []);

  // Custom setter for PentestGPT migration confirm dialog that also updates URL
  const setMigrateFromPentestgptDialogOpenWithUrl = useCallback(
    (open: boolean) => {
      setMigrateFromPentestgptDialogOpen(open);

      if (typeof window !== "undefined") {
        const url = new URL(window.location.href);
        if (open) {
          url.searchParams.set("confirm-migrate-pentestgpt", "true");
        } else {
          url.searchParams.delete("confirm-migrate-pentestgpt");
        }
        window.history.replaceState({}, "", url.toString());
      }
    },
    [],
  );

  const actionsValue = useMemo<GlobalStateActionsType>(
    () => ({
      closeSidebar,
      initializeChat,
      initializeNewChat,
      setActiveProjectId,
      setChatSidebarOpen,
      setSandboxPreference,
    }),
    [
      closeSidebar,
      initializeChat,
      initializeNewChat,
      setActiveProjectId,
      setChatSidebarOpen,
      setSandboxPreference,
    ],
  );

  const value: GlobalStateType = {
    uploadedFiles,
    getUploadedFiles,
    setUploadedFiles,
    addUploadedFile,
    removeUploadedFile,
    updateUploadedFile,
    getTotalTokens,
    isUploadingFiles,
    chatMode: accessibleChatMode,
    setChatMode,
    chatModeAccessResolved,
    paidAgentOnlyActive,
    freeDesktopAgentOnlyActive,
    sidebarOpen,
    setSidebarOpen,
    sidebarContent,
    setSidebarContent,
    chatSidebarOpen,
    setChatSidebarOpen,
    optimisticChatId,
    setOptimisticChatId,
    activeProjectId,
    setActiveProjectId,
    todos,
    setTodos,
    mergeTodos,
    replaceAssistantTodos,

    isTodoPanelExpanded,
    setIsTodoPanelExpanded,

    subscription,
    isCheckingProPlan,

    getInput,
    clearInput,
    clearUploadedFiles,
    openSidebar,
    updateSidebarContent,
    consumeBrowserTakeoverRequest,
    closeSidebar,
    toggleChatSidebar,
    initializeChat,
    initializeNewChat,

    teamPricingDialogOpen,
    setTeamPricingDialogOpen,

    teamWelcomeDialogOpen,
    setTeamWelcomeDialogOpen: setTeamWelcomeDialogOpenWithUrl,

    migrateFromPentestgptDialogOpen,
    setMigrateFromPentestgptDialogOpen:
      setMigrateFromPentestgptDialogOpenWithUrl,

    setChatReset,
    setChatNavigationHandler,

    hasUserDismissedRateLimitWarning,
    setHasUserDismissedRateLimitWarning,

    messageQueue,
    queueMessage,
    updateQueuedMessage,
    editingQueuedMessageId,
    setEditingQueuedMessageId,
    removeQueuedMessage,
    setQueuedMessageDelivery,
    clearQueue,

    queueBehavior,
    setQueueBehavior: setQueueBehaviorState,

    sandboxPreference,
    setSandboxPreference,
    resetSandboxPreference,
    agentPermissionMode,
    setAgentPermissionMode,
    desktopBridgeActive,
    desktopBridgeStatus,
    desktopEnvironmentId,
    retryDesktopBridge,
    hasLocalSandbox,
    localConnections,
    defaultLocalSandboxPreference,

    selectedModel,
    setSelectedModel: setSelectedModelState,
  };

  return (
    <GlobalStateActionsContext.Provider value={actionsValue}>
      <GlobalStateContext.Provider value={value}>
        {children}
      </GlobalStateContext.Provider>
    </GlobalStateActionsContext.Provider>
  );
};

export const GlobalStateProvider: React.FC<GlobalStateProviderProps> = ({
  children,
}) => (
  <ComposerStateProvider>
    <GlobalStateProviderInner>{children}</GlobalStateProviderInner>
  </ComposerStateProvider>
);

export const useGlobalState = (): GlobalStateType => {
  const context = useContext(GlobalStateContext);
  if (context === undefined) {
    throw new Error("useGlobalState must be used within a GlobalStateProvider");
  }
  return context;
};

export const useGlobalStateActions = (): GlobalStateActionsType => {
  const context = useContext(GlobalStateActionsContext);
  if (context === undefined) {
    throw new Error(
      "useGlobalStateActions must be used within a GlobalStateProvider",
    );
  }
  return context;
};
